<?php

return [
    'name' => 'City',
    'icon' => 'map',
    'group_icon' => 'box',
    'group' => 'Site management',
    'route_is' => 'admin:city.*',
    'route' => route('admin:city.index'),
    'permission' => ['view cities','edit city'],
];
