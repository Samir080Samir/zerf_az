<?php

namespace Modules\City\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\File;
use Modules\City\app\Http\Requests\CityStoreRequest;
use Modules\City\app\Http\Requests\CityUpdateRequest;
use Modules\City\app\Models\City;
use Modules\Core\app\Traits\Files\ImageCompressor;
use Nwidart\Modules\Facades\Module;

class CityController extends Controller
{
    use ImageCompressor;

    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view cities')->only('index');
            $this->middleware('permission:create city')->only('create');
            $this->middleware('permission:store city')->only('store');
            $this->middleware('permission:edit city')->only('edit');
            $this->middleware('permission:update city')->only('update');
            $this->middleware('permission:destroy city')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $cities = City::when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('title', 'LIKE', "%{$search}%");
            });
        })->paginate($pageCount)->withQueryString();

        return view('city::index', compact([
            'cities'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('city::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CityStoreRequest $request)
    {
        try {
            $validatedData = $request->validated();

            if ($request->hasFile('image')) {
                $validatedData['image'] = self::compressImage($request->file('image'), 'CityImage');
            }

            City::create($validatedData);

            return response()->json(__('Data successfully created!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(City $city)
    {
        return view('city::edit', compact([
            'city'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(CityUpdateRequest $request, City $city)
    {
        try {
            $validatedData = $request->validated();

            if ($request->hasFile('image')) {
                if ($city->getAttribute('image')) {
                    File::delete('/storage/images/' . $city->getAttribute('image'));
                }
                $validatedData['image'] = self::compressImage($request->file('image'), 'CityImage');
            }

            $city->update($validatedData);

            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(City $city)
    {
        try {

            if ($city->getAttribute('image')) {
                File::delete('/storage/images/' . $city->getAttribute('image'));
            }
            $city->delete();

            return response()->json(__('Data successfully deleted!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
}
