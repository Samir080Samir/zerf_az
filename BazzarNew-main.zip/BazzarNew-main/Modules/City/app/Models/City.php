<?php

namespace Modules\City\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Ad\app\Models\Ad;
use Modules\City\Database\factories\CityFactory;
use Modules\Core\app\Traits\Data\Image;
use Modules\Core\app\Traits\Data\SlugWithId;
use Modules\Core\app\Traits\Data\Title;

class City extends Model
{
    use HasFactory, SlugWithId, Title, Image;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'slug',
        'title',
        'image'
    ];

    protected static function newFactory(): CityFactory
    {
        return CityFactory::new();
    }

    public function ads(): HasMany
    {
        return $this->hasMany(Ad::class)->where(function ($query) {
            $query->where('category_id', $this->id)
                ->where('moderation', '=', 'moderated')
                ->where('published', '=', true);
        });
    }
}
