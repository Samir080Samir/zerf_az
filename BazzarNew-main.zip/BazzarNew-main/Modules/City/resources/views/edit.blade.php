@extends('core::layouts.master')
@section('title',__('Edit city'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Cities') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:city.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
            <a href="{{route('admin:city.store')}}" class="btn btn-primary shadow-md mr-2">@lang('Add new')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form class="grid grid-col-12 gap-2 form-update" action="{{route('admin:city.update',$city->getAttribute('id'))}}" method="post" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="grid grid-cols-12 col-span-12 gap-2 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 p-4 mb-3">
                                <div class="col-span-12 lg:col-span-2">
                                    <div class="axios-image rounded-md p-5">
                                        <div class="h-40 relative image-fit cursor-pointer zoom-in mx-auto">
                                            <img class="rounded-md w-full" src="{{$city->image()}}" alt="{{$city->title()}}">
                                        </div>
                                        <div class="mx-auto cursor-pointer relative mt-5">
                                            <button type="button" class="btn btn-primary w-full">@lang('Change image')</button>
                                            <input type="file" name="image" class="w-full h-full top-0 left-0 absolute opacity-0" onchange="imagePreview(event)">
                                        </div>
                                    </div>
                                </div>

                                <x-core::form.input
                                    :label="__('Title')"
                                    name="title"
                                    div-class="lg:col-span-10"
                                    :value="old('title',$city->getAttribute('title'))"
                                    required/>
                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Update')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
            <!-- END: Form Validation -->
        </div>
    </div>
@endsection
