<tr class="intro-x">
    <td class="w-40">
        <div class="w-10 h-10 image-fit zoom-in">
            <img class="tooltip rounded-full" src="{{$city->image()}}" alt="{{$city->title()}}">
        </div>
    </td>
    <td>
        <a href="{{route('admin:city.edit',$city->getAttribute('id'))}}" class="font-medium whitespace-nowrap">{{$city->title()}}</a>
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
            'modelName' => 'city',
            'editUrl' => route('admin:city.edit',$city->getAttribute('id')),
            'deleteUrl' => route('admin:city.destroy',$city->getAttribute('id'))
        ])
    </td>
</tr>
