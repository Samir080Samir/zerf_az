@extends('core::layouts.master')
@section('title',__('Cities'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Cities') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <a href="{{route('admin:city.create')}}" class="btn btn-primary shadow-md mr-2">@lang('Add new')</a>
            @include('core::includes.header-filter',['models' => $cities])
        </div>
        <!-- BEGIN: Data List -->
        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <table class="table table-report -mt-2">
                <thead>
                <tr>
                    <th class="whitespace-nowrap">@lang('Image')</th>
                    <th class="hidden lg:table-cell whitespace-nowrap">@lang('Title')</th>
                    <th class="text-center whitespace-nowrap">@lang('Actions')</th>
                </tr>
                </thead>
                <tbody>
                @each('city::includes.city-tr',$cities,'city','core::includes.not-found-tr')
                </tbody>
            </table>
        </div>
        <!-- END: Data List -->
        <!-- BEGIN: Pagination -->
        {{$cities->links('core::includes.pagination')}}
        <!-- END: Pagination -->
    </div>
@endsection
