<?php

return [
    'name' => 'Shops',
    'icon' => 'map',
    'group_icon' => 'box',
    'group' => 'Ads management',
    'route_is' => 'admin:shop.*',
    'route' => route('admin:shop.index'),
    'permission' => ['view shops','edit shop'],
];

