<tr class="intro-x">
    <td class="w-40">
        <div class="flex">
            @if($shop->image())
                <div class="w-10 h-10 image-fit zoom-in rounded-full">
                    <img class="tooltip rounded-full" src="{{$shop->image()}}" alt="{{$shop->title()}}" title="@lang('Icon image')">
                </div>
            @endif
        </div>
    </td>
    <td>
        <a href="{{route('admin:user.edit',$shop->user->getAttribute('id'))}}" class="font-medium whitespace-nowrap">
            {{$shop->user->fullName()}}
        </a>
    </td>
    <td>
        <a href="{{route('admin:shop.edit',$shop->getAttribute('id'))}}" class="font-medium whitespace-nowrap">
            {{$shop->title()}} (<span class="font-bold">{{$shop->user->ads->count()}}</span>)
        </a>
    </td>
    <td>
        <a href="tel:{{CoreHelper::telCleaner($shop->getAttribute('phone'))}}" class="font-medium whitespace-nowrap">
            {{$shop->getAttribute('phone')}}
        </a>
    </td>
    <td>
        {{$shop->getAttribute('views')}}
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
            'modelName' => 'shop',
            'editUrl' => route('admin:shop.edit',$shop->getAttribute('id')),
            'deleteUrl' => route('admin:shop.destroy',$shop->getAttribute('id'))
        ])
    </td>
</tr>
