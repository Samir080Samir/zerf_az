@extends('core::layouts.master')
@section('title',__('Edit shop'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Edit Shop') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:shop.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form class="grid grid-cols-12 gap-2 form-update" novalidate action="{{route('admin:shop.update',$shop->getAttribute('id'))}}" method="post" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="grid grid-cols-12 col-span-12 gap-2 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 p-4 mb-3">
                                <div class="col-span-12 lg:col-span-2">
                                    <div class="axios-image rounded-md p-5">
                                        <div class="h-40 relative image-fit cursor-pointer zoom-in mx-auto">
                                            <img id="output" class="rounded-md w-full" src="{{$shop->image()}}" alt="{{$shop->title()}}">
                                        </div>
                                        <div class="mx-auto cursor-pointer relative mt-5">
                                            <button type="button" class="btn btn-primary w-full">@lang('Image')</button>
                                            <input type="file" name="image" class="w-full h-full top-0 left-0 absolute opacity-0" onchange="imagePreview(event)">
                                        </div>
                                    </div>
                                </div>
                                <div class="grid grid-cols-12 col-span-12 gap-2 lg:col-span-8 my-auto">

                                    <x-core::form.input
                                        :label="__('Title')"
                                        name="title"
                                        :value="old('title',$shop->getAttribute('title'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Slogan')"
                                        name="slogan"
                                        :value="old('slogan',$shop->getAttribute('slogan'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Phone')"
                                        name="phone"
                                        div-class="lg:col-span-6"
                                        :value="old('phone',$shop->getAttribute('phone'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Address')"
                                        name="address"
                                        div-class="lg:col-span-6"
                                        :value="old('address',$shop->getAttribute('address'))"
                                        required/>

                                </div>

                                <div class="col-span-12 lg:col-span-2">
                                    <div class="axios-image rounded-md p-5">
                                        <div class="h-40 relative image-fit cursor-pointer zoom-in mx-auto">
                                            <img id="output" class="rounded-md w-full" src="{{$shop->background()}}" alt="{{$shop->title()}}">
                                        </div>
                                        <div class="mx-auto cursor-pointer relative mt-5">
                                            <button type="button" class="btn btn-primary w-full">@lang('Background')</button>
                                            <input type="file" name="background" class="w-full h-full top-0 left-0 absolute opacity-0" onchange="imagePreview(event)">
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="grid grid-cols-12 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">

                                <div class="col-span-12 mb-3">
                                    <label class="form-label w-full flex flex-col sm:flex-row">@lang('Owner')</label>
                                    <select name="user_id" class="tom-select w-full">
                                        <option value=""> @lang('Select shop owner') </option>
                                        @foreach($users as $user)
                                            <option @selected(old('user_id',$shop->getAttribute('user_id')) == $user->getAttribute('id')) value="{{$user->getAttribute('id')}}">
                                                {{ $user->fullName() ($user->getAttribute('email')) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <x-core::form.input
                                    :label="__('Work days')"
                                    name="work_days"
                                    data-max-items="7"
                                    input-class="input-tags"
                                    :value="old('work_days', $shop->getAttribute('work_days') ? implode(',',json_decode($shop->getAttribute('work_days'))) : null)"/>
                            </div>

                            <div class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">

                                <x-core::form.textarea
                                    :label="__('Description')"
                                    name="description"
                                    input-class="editor"
                                    :value="old('description',$shop->getAttribute('description'))"/>

                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Update')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>
                        </form>
                        <!-- END: Validation Form -->

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
