@extends('core::layouts.master')
@section('title',__('Show shop'))
@section('content')

@endsection
