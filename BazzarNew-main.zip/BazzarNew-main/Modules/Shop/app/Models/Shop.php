<?php

namespace Modules\Shop\app\Models;

use App\Models\User;
use Illuminate\Contracts\Translation\Translator;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Modules\Core\app\Traits\Data\Background;
use Modules\Core\app\Traits\Data\Description;
use Modules\Core\app\Traits\Data\Image;
use Modules\Core\app\Traits\Data\SlugWithId;
use Modules\Core\app\Traits\Data\Title;
use Modules\Shop\Database\factories\ShopFactory;

class Shop extends Model
{
    use HasFactory, SlugWithId, Title, Description, Image, Background;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'user_id',
        'slug',
        'title',
        'phone',
        'address',
        'work_days',
        'slogan',
        'description',
        'image',
        'background',
        'views'
    ];

    protected static function newFactory(): ShopFactory
    {
        //return ShopFactory::new();
    }

    public function workDays(): string
    {
        return $this->getAttribute('work_days')
            ? implode($this->getAttribute('work_days')) . ' ' . __('days of the week')
            : __('Every day');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
