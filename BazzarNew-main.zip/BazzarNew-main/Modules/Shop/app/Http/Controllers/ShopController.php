<?php

namespace Modules\Shop\app\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\File;
use Modules\Core\app\Traits\Files\ImageCompressor;
use Modules\Shop\app\Http\Requests\ShopStoreRequest;
use Modules\Shop\app\Http\Requests\ShopUpdateRequest;
use Modules\Shop\app\Models\Shop;
use Nwidart\Modules\Facades\Module;

class ShopController extends Controller
{
    use ImageCompressor;

    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view shops')->only('index');
            $this->middleware('permission:create shop')->only('create');
            $this->middleware('permission:store shop')->only('store');
            $this->middleware('permission:edit shop')->only('edit');
            $this->middleware('permission:update shop')->only('update');
            $this->middleware('permission:destroy shop')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $shops = Shop::when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('title', 'LIKE', "%{$search}%");
            });
        })->paginate($pageCount)->withQueryString();

        return view('shop::index', compact([
            'shops'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $users = User::whereHas('permissions', function ($query) {
            $query->where('name', 'view dashboard');
        })->select(['id', 'first_name', 'last_name'])->get();

        return view('shop::create', compact([
            'users'
        ]));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ShopStoreRequest $request)
    {
        try {
            $validatedData = $request->validated();

            if ($request->hasFile('image')) {
                $validatedData['image'] = self::compressImage($request->file('image'), 'ShopImage');
            }

            if ($request->hasFile('background')) {
                $validatedData['background'] = self::compressImage($request->file('background'), 'ShopBackground');
            }

            Shop::create($validatedData);

            return response()->json(__('Data successfully created!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Show the specified resource.
     */
    public function show(Shop $shop)
    {
        return view('shop::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Shop $shop)
    {
        $users = User::whereHas('permissions', function ($query) {
            $query->where('name', 'view dashboard');
        })->select(['id', 'first_name', 'last_name'])->get();

        return view('shop::edit', compact([
            'shop',
            'users'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ShopUpdateRequest $request, Shop $shop)
    {
        try {
            $validatedData = $request->validated();

            if ($request->hasFile('image')) {
                if ($shop->getAttribute('image')) {
                    File::delete('/storage/images/' . $shop->getAttribute('image'));
                }
                $validatedData['image'] = self::compressImage($request->file('image'), 'ShopImage');
            } else {
                $validatedData['image'] = $shop->getAttribute('image');
            }

            if ($request->hasFile('background')) {
                if ($shop->getAttribute('background')) {
                    File::delete('/storage/images/' . $shop->getAttribute('background'));
                }
                $validatedData['background'] = self::compressImage($request->file('background'), 'ShopBackground');
            } else {
                $validatedData['background'] = $shop->getAttribute('background');
            }

            $shop->update($validatedData);

            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Shop $shop)
    {
        try {

            if ($shop->getAttribute('image')) {
                File::delete('/storage/images/' . $shop->getAttribute('image'));
            }

            if ($shop->getAttribute('background')) {
                File::delete('/storage/images/' . $shop->getAttribute('background'));
            }

            $shop->delete();

            return response()->json(__('Data successfully deleted!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
}
