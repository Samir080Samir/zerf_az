<?php

namespace Modules\Shop\app\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;

class ShopUpdateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'user_id' => ['required','exists:users,id'],
            'slug' => ['nullable'],
            'title' => ['required'],
            'phone' => ['required'],
            'address' => ['required'],
            'work_days' => ['required'],
            'slogan' => ['required'],
            'description' => ['required'],
            'image' => ['nullable','image','mimes:jpeg,png,jpg,gif,webp,svg'],
            'background' => ['nullable','image','mimes:jpeg,png,jpg,gif,webp,svg'],
        ];
    }

    /**
     * @return void
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'slug' => Str::slug($this->input('title')),
        ]);
    }

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
