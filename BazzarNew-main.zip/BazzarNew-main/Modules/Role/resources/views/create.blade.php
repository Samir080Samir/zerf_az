@extends('core::layouts.master')
@section('title',__('Create role'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Roles') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:role.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form class="grid grid-col-12 gap-2 form-store" action="{{route('admin:role.store')}}" method="post">
                            @csrf

                            <x-core::form.input
                                :label="__('Name')"
                                name="name"
                                :value="old('name')"
                                required/>

                            <div id="permissions-accordion-1" class="accordion accordion-boxed col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                @foreach($permissions as $group => $permissions)
                                    <div class="accordion-item rounded bg-gray-100 dark:bg-gray-900">
                                        <div id="permissions-accordion-content-{{$group}}" class="accordion-header">
                                            <button @class(['accordion-button border-slate-100 text-slate-700 rounded-t-1 group relative flex w-full cursor-pointer items-center border-b border-solid p-4 text-left font-semibold text-dark-500 transition-all ease-in','collapsed' => !$loop->first]) type="button" data-tw-toggle="collapse" data-tw-target="#permissions-accordion-collapse-{{$group}}" aria-expanded="{{$loop->first ? 'true' : 'false'}}" aria-controls="permissions-accordion-collapse-{{$group}}">
                                                <i data-lucide="chevron-down" class="absolute right-0 pt-1 text-base transition-transform group-[.collapsed]:rotate-180"></i>
                                                <span class="font-semibold">@lang(Str::ucfirst($group))</span>
                                            </button>
                                        </div>
                                        <div id="permissions-accordion-collapse-{{$group}}" @class(['accordion-collapse collapse','show' => $loop->first]) aria-labelledby="permissions-accordion-content-{{$group}}" data-tw-parent="#permissions-accordion-1">
                                            <div class="accordion-body text-slate-600 dark:text-slate-500 leading-relaxed">
                                                <table class="table">
                                                    <tbody>
                                                    @foreach ($permissions as $permission)
                                                        <tr class="border-bottom-secondary">
                                                            <td class="font-semibold">
                                                                @lang(Str::ucfirst(__($permission->getAttribute('name'))))
                                                            </td>
                                                            <td>
                                                                <div class="form-check form-switch d-flex justify-end">
                                                                    <input name="permissions[]" class="form-check-input" id="permission{{$permission->getAttribute('id')}}" type="checkbox" role="switch" value="{{$permission->getAttribute('name')}}" @checked(in_array($permission->getAttribute('name'),old('permissions',[])))>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Create')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
            <!-- END: Form Validation -->
        </div>
    </div>
@endsection
