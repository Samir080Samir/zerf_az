<tr class="intro-x">
    <td>
        <div class="font-medium whitespace-nowrap">@lang('Role'): <span class="font-bold">{{ucfirst($role->getAttribute('name'))}}</span></div>
        <div class="text-slate-500 text-xs font-medium whitespace-nowrap mt-0.5">@lang('Guard'): <span class="font-bold">{{ucfirst($role->getAttribute('guard_name'))}} </span></div>
    </td>
    <td class="hidden lg:table-cell">
        @include('role::includes.role-permissions',['role' => $role])
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
            'modelName' => 'role',
            'editUrl' => route('admin:role.edit',$role->getAttribute('id')),
            'deleteUrl' => route('admin:role.destroy',$role->getAttribute('id'))
        ])
    </td>
</tr>
