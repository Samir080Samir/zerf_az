<div class="text-slate-500 text-xs mt-0.5">
    @lang('Permissions'):@forelse($role->permissions as $permission)
        <span class="font-bold">{{ ucfirst(__($permission->getAttribute('name'))) }}</span>  @if(!$loop->last) | @endif
    @empty
        <span class="font-bold">@lang('Permissions not found')</span>
    @endforelse
</div>
