<?php

namespace Modules\Role\database\seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $adminUser = User::factory()->create([
            'first_name' => 'Admin',
            'last_name' => 'Npa',
            'email' => 'admin@admin.com',
            'password' => Hash::make('admin'),
        ]);

        $developerUser = User::factory()->create([
            'first_name' => 'Husein',
            'last_name' => 'JavaDLE',
            'email' => 'huseynjavadle@gmail.com',
            'password' => Hash::make('10072021'),
        ]);

        $developerRole = Role::create(['name' => 'Developer']);

        // Assign Developer role to the user
        $developerUser->assignRole($developerRole);
        $adminUser->assignRole($developerRole);

        $allPermissions = [
            'Global' => [
                'show dashboard'
            ],

            'Filters' => [
                'view filters',
                'create filter',
                'store filter',
                'edit filter',
                'update filter',
                'destroy filter',
            ],

            'Cities' => [
                'view cities',
                'create city',
                'store city',
                'edit city',
                'update city',
                'destroy city',
            ],

            'Categories' => [
                'view categories',
                'create category',
                'store category',
                'edit category',
                'update category',
                'destroy category',
            ],

            'Ads' => [
                'view ads',
                'create ad',
                'store ad',
                'edit ad',
                'update ad',
                'destroy ad',
            ],

            'Reports' => [
                'view reports',
                'edit report',
                'update report'
            ],

            'Shops' => [
                'view shops',
                'create shop',
                'store shop',
                'show shop',
                'edit shop',
                'update shop',
                'destroy shop',
            ],

            'Users' => [
                'view users',
                'create user',
                'store user',
                'edit user',
                'update user',
                'destroy user',
            ],

            'Translates' => [
                'view translates',
                'edit translate',
                'update translate'
            ],

            'Roles' => [
                'view roles',
                'create role',
                'store role',
                'edit role',
                'update role',
                'destroy role',
            ],

            'Tools' => [
                'clear cache',
                'optimize',
                'optimize clear',
                'storage link',
                'migrate',
                'generate sitemap',
                'view system-info'
            ],

            'Settings' => [
                'edit settings',
                'update settings',
            ]
        ];

        foreach ($allPermissions as $group => $groupPermissions) {
            foreach ($groupPermissions as $permission) {
                Permission::create([
                    'name' => $permission,
                    'group' => $group
                ]);

                $developerRole->givePermissionTo($permission);
            }
        }
    }
}
