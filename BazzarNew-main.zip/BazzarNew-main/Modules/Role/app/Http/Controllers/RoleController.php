<?php

namespace Modules\Role\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\Request;
use Modules\Role\app\Http\Requests\RoleStoreRequest;
use Modules\Role\app\Http\Requests\RoleUpdateRequest;
use Nwidart\Modules\Facades\Module;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view roles')->only('index');
            $this->middleware('permission:create role')->only('create');
            $this->middleware('permission:store role')->only('store');
            $this->middleware('permission:edit role')->only('edit');
            $this->middleware('permission:update role')->only('update');
            $this->middleware('permission:destroy role')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $roles = Role::when($search, function ($role) use ($search) {
            $role->where('name', 'LIKE', "%{$search}%")
                ->orWhereHas('permissions', function ($permission) use ($search) {
                    $permission->where('name', 'LIKE', "%{$search}%");
                });
        })->paginate($pageCount)->withQueryString();

        return view('role::index', compact(['roles']));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $permissions = Permission::all()->groupBy('group');
        return view('role::create', compact(['permissions']));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(RoleStoreRequest $request)
    {
        try {
            $role = Role::create(['name' => $request->input('name')]);
            $role->syncPermissions($request->input('permissions') ?? []);
            return response()->json(__('Data successfully created!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('role::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Role $role)
    {
        $permissions = Permission::all()->groupBy('group');
        return view('role::edit', compact([
            'role',
            'permissions'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(RoleUpdateRequest $request, Role $role)
    {
        try {
            $role->update(['name' => strtolower($request->input('name'))]);
            $role->syncPermissions($request->permissions ?? []);
            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Role $role)
    {
        try {
            $role->delete();
            return response()->json(__('Data successfully deleted!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
}
