<?php

namespace Modules\Role\app\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RoleUpdateRequest extends FormRequest
{
    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return string[]
     */
    public function rules(): array
    {
        $roleId = $this->route('role')?->getAttribute('id');

        return [
            'name' => "required|unique:roles,name,{$roleId}",
            'permissions' => 'array|min:0',
            'permissions.*' => 'exists:permissions,name',
        ];
    }
}
