<?php

return [
    'name' => 'Adversity',
    'icon' => 'box',
    'group_icon' => 'megaphone',
    'group' => 'Ads management',
    'route_is' => 'admin:adversity.*',
    'route' => route('admin:adversity.index'),
    'permission' => ['view adversities','edit adversity'],
];
