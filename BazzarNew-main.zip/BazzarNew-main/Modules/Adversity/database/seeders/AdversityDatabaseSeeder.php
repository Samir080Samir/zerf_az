<?php

namespace Modules\Adversity\database\seeders;

use Illuminate\Database\Seeder;

class AdversityDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
