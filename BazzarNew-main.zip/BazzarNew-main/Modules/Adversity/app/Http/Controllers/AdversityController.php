<?php

namespace Modules\Adversity\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Nwidart\Modules\Facades\Module;
use Modules\Adversity\app\Models\Adversity;
class AdversityController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            // $this->middleware('permission:view payments')->only('index');
            // $this->middleware('permission:create payment')->only('create');
            // $this->middleware('permission:store payment')->only('store');
            // $this->middleware('permission:edit payment')->only('edit');
            // $this->middleware('permission:update payment')->only('update');
            // $this->middleware('permission:destroy payment')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $adversities = Adversity::when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('type', 'LIKE', "%{$search}%");
            });
        })->paginate($pageCount)->withQueryString();

        return view('adversity::index',compact([
            'adversities'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('adversity::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        //
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('adversity::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('adversity::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id): RedirectResponse
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
    }
}
