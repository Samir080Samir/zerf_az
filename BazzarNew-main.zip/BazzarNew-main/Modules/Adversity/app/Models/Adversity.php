<?php

namespace Modules\Adversity\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Adversity\Database\factories\AdversityFactory;
use Modules\Core\app\Helpers\CoreHelper;
use Modules\Core\app\Traits\Data\Title;

class Adversity extends Model
{
    use HasFactory, Title;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'title',
        'price',
        'period',
        'is_cron',
        'expired',
        'type'
    ];

    public function price(): string
    {
        return CoreHelper::formatPrice($this->getAttribute('price'));
    }

    public function period(): string
    {
        return $this->getAttribute('period');
    }

    protected static function newFactory(): AdversityFactory
    {
        //return AdversityFactory::new();
    }
}
