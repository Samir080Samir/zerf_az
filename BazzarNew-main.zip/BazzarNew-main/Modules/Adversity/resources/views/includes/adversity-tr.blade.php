<tr class="intro-x">
    <td>
        {{ $adversity->title() }}
    </td>
    <td>
        {{ $adversity->getAttribute('type') }}
    </td>
    <td>
        {{ $adversity->period() }}
    </td>
    <td>
        {{$adversity->price()}}
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
        'modelName' => 'adversity',
        // 'editUrl' => route('admin:adversity.edit',$adversity->getAttribute('id')),
        // 'deleteUrl' => route('admin:adversity.destroy',$adversity->getAttribute('id'))
        ])
    </td>
</tr>