@extends('core::layouts.master')
@section('title',__('Ads'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Ads') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <a href="{{route('admin:category.create')}}" class="btn btn-primary shadow-md mr-2">@lang('Add new')</a>
            @include('ad::includes.header-filter-ad',['models' => $ads])
        </div>
        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <div class="flex justify-end">
                <div class="bg-gray-200 text-sm text-gray-500 leading-none border-2 border-gray-200 rounded-full inline-flex">
                    <form action="">
                        <button @class(['inline-flex items-center transition-colors duration-300 ease-in focus:outline-none hover:text-red-400 font-bold focus:text-red-400 rounded-l-full px-4 py-2','bg-white text-red-400' => (request()->input('layout','grid') == 'grid')]) id="grid" name="layout" value="grid">
                            <i class="w-4 h-4 mr-2" data-lucide="layout-grid"></i>
                            <span>@lang('Grid')</span>
                        </button>
                    </form>
                    <form action="">
                        <button @class(['inline-flex items-center transition-colors duration-300 ease-in focus:outline-none hover:text-red-400 font-bold focus:text-red-400 rounded-r-full px-4 py-2','bg-white text-red-400' => (request()->input('layout') == 'list')]) id="list" name="layout" value="list">
                            <i class="w-4 h-4 mr-2" data-lucide="list"></i>
                            <span>@lang('List')</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            @switch(request()->input('layout'))
                @case('list')
                    <!-- BEGIN: Data List -->
                    <table class="table table-report -mt-2">
                        <thead>
                        <tr>
                            <th class="whitespace-nowrap">@lang('Icon')</th>
                            <th class="hidden lg:table-cell whitespace-nowrap">@lang('Title')</th>
                            <th class="hidden lg:table-cell whitespace-nowrap">@lang('Price')</th>
                            <th class="hidden lg:table-cell whitespace-nowrap">@lang('Views')</th>
                            <th class="hidden lg:table-cell whitespace-nowrap">@lang('Published')</th>
                            <th class="hidden lg:table-cell whitespace-nowrap">@lang('Status')</th>
                            <th class="text-center whitespace-nowrap">@lang('Actions')</th>
                        </tr>
                        </thead>
                        <tbody>
                        @each('ad::includes.ad-tr',$ads,'ad','core::includes.not-found-tr')
                        </tbody>
                    </table>
                    <!-- END: Data List -->
                    <!-- BEGIN: Pagination -->
                    {{$ads->links('core::includes.pagination')}}
                    <!-- END: Pagination -->
                    @break
                @default
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        @each('ad::includes.ad-card',$ads,'ad','core::includes.not-found')
                    </div>
            @endswitch
        </div>
    </div>

@endsection
