@extends('core::layouts.master')
@section('title',__('Edit ad'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Edit ad') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:ad.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form class="grid grid-cols-12 gap-2 form-update" novalidate action="{{route('admin:ad.update',$ad->getAttribute('id'))}}" method="post" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <x-core::form.input
                                    :label="__('Title')"
                                    name="title"
                                    :value="old('title',$ad->getAttribute('title'))"
                                    required/>

                                <x-core::form.input
                                    :label="__('Price')"
                                    name="price"
                                    type="number"
                                    div-class="lg:col-span-1"
                                    :value="old('price',$ad->getAttribute('price'))"
                                    required/>

                                <x-core::form.select
                                    :label="__('Published')"
                                    name="published"
                                    div-class="lg:col-span-2"
                                    :options="[true => __('Active'),0 => __('Inactive')]"
                                    :selected="old('published',$ad->getAttribute('published'))"
                                    required/>

                                <x-core::form.select
                                    :label="__('Expired')"
                                    name="expired"
                                    div-class="lg:col-span-2"
                                    :options="[true => __('True'),0 => __('False')]"
                                    :selected="old('expired',$ad->getAttribute('expired'))"
                                    required/>

                                <x-core::form.select
                                    :label="__('Type')"
                                    name="type"
                                    div-class="lg:col-span-2"
                                    :options="['free' => __('Free'),'vip' => __('Vip'),'premium' => __('Premium')]"
                                    :selected="old('type',$ad->getAttribute('type'))"
                                    required/>

                                <x-core::form.select
                                    :label="__('Moderation')"
                                    name="moderation"
                                    div-class="lg:col-span-2"
                                    :options="['waiting' => __('Moderation'),'moderated' => __('Moderated'),'rejected' => __('Rejected')]"
                                    :selected="old('moderation',$ad->getAttribute('moderation'))"
                                    required/>
                            </div>

                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="mt-3 col-span-12">
                                    <label>@lang('Category')</label>
                                    <div class="mt-2 mb-3">
                                        <select id="category" name="category_id" class="w-full">
                                            <option value=""> @lang('Select category') </option>
                                            @foreach(CoreHelper::mainCategories() as $category)
                                                @if($category->children->isNotEmpty())
                                                    <optgroup label="{{$category->title()}}">
                                                        @foreach($category->children as $child)
                                                            <option @selected(old('category_id', $child->getAttribute('id')) == $ad->getAttribute('category_id')) value="{{$child->getAttribute('id')}}">{{$child->title()}}</option>
                                                        @endforeach
                                                    </optgroup>
                                                @else
                                                    <option @selected(old('category_id', $category->getAttribute('id')) == $ad->getAttribute('category_id')) value="{{$category->getAttribute('id')}}">{{$category->title()}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div id="filters" class="col-span-12"></div>
                            </div>

                            <div id="gallery" class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4 bg-gray-100 dark:bg-black/20"></div>

                            <div class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">

                                <x-core::form.textarea
                                    :label="__('Description')"
                                    name="description"
                                    input-class="editor"
                                    :value="old('description',$ad->getAttribute('description'))"/>

                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Update')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
            <!-- END: Form Validation -->
        </div>
    </div>
@endsection
@push('js')
    <script>
        const category = document.getElementById('category');

        function getCategoryFilters() {
            const ad_id = {{$ad->getAttribute('id')}};
            const category_id = category.value;
            const filters = {!! json_encode(old('filters', [])) !!};

            axios.post('{{ route('web:category.filters') }}', {
                category_id: category_id,
                ad_id: ad_id,
                filters: filters
            }).then(function (response) {
                document.getElementById('filters').innerHTML = response.data;
            }).catch(function (error) {
                document.getElementById('filters').innerHTML = '';
                console.error(error.response.data);
            });
        }

        category.addEventListener('change', getCategoryFilters);

        @if(old('category_id',$ad->getAttribute('category_id')))
            window.onload = (event) => {
            getCategoryFilters()
        };
        @endif
    </script>
    <script>
        window.preloadedImages = @json($gallery);
    </script>
@endpush
