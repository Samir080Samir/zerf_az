<div class="intro-y col-span-12 md:col-span-6 lg:col-span-4 xl:col-span-3">
    <div class="box">
        <div class="p-5">
            <div class="h-40 2xl:h-56 image-fit rounded-md overflow-hidden before:block before:absolute before:w-full before:h-full before:top-0 before:left-0 before:z-10 before:bg-gradient-to-t before:from-black before:to-black/10">
                <img alt="{{$ad->title()}}" class="rounded-md" src="{{$ad->firstImage()}}">
                <span @class(['absolute top-0 text-light px-2 py-1 rounded text-xs m-5 z-10','bg-info' => $ad->getAttribute('type') == 'free','bg-warning' => $ad->getAttribute('type') == 'vip','bg-danger' => $ad->getAttribute('type') == 'premium'])>
                    {{Str::upper($ad->getAttribute('type'))}}
                </span>
                <div class="absolute bottom-0 text-white px-5 pb-6 z-10">
                    <a href="" class="block font-medium text-base">{{$ad->title()}}</a>
                    <span class="text-white/90 text-xs mt-3">{{optional($ad->category)->title()}}</span>
                </div>
            </div>
            <div class="text-slate-600 dark:text-slate-500 mt-5">
                <div class="flex items-center">
                    <i data-lucide="link" class="w-4 h-4 mr-2"></i>
                    @lang('Price'): {{$ad->price()}} {{CoreHelper::settings()->getAttribute('app_currency')}}
                </div>
                <div class="flex items-center mt-2">
                    <i data-lucide="check-square" class="w-4 h-4 mr-2"></i>
                    <span class="mr-2">@lang('Status'):</span>
                    @switch($ad->getAttribute('published'))
                        @case(true)
                            <div class="flex items-center justify-center text-success">
                                @lang('Active')
                            </div>
                            @break
                        @case(false)
                            <div class="flex items-center justify-center text-warning">
                                @lang('Inactive')
                            </div>
                            @break
                    @endswitch
                </div>
            </div>
        </div>
        <div class="flex justify-center lg:justify-end items-center p-5 border-t border-slate-200/60 dark:border-darkmode-400">
            <a class="flex items-center text-primary mr-auto" href="{{route('web:categories.ads.category:slug.ad:id',['category' => $ad->category->getFullPathSlug(), $ad->getAttribute('id')])}}">
                <i data-lucide="eye" class="w-4 h-4 mr-1"></i>
                @lang('Preview')
            </a>
            @include('core::includes.table-elements.action-buttons',[
             'modelName' => 'ad',
             'editUrl' => route('admin:ad.edit',$ad->getAttribute('id')),
             'deleteUrl' => route('admin:ad.destroy',$ad->getAttribute('id'))
            ])
        </div>
    </div>
</div>
