<tr class="intro-x">
    <td class="w-40">
        <div class="flex">
            <div class="w-10 h-10 image-fit zoom-in">
                <img alt="{{$ad->title()}}" class="tooltip rounded-full" src="{{$ad->firstImage()}}">
            </div>
        </div>
    </td>
    <td>
        <a href="{{route('admin:ad.edit',$ad->getAttribute('id'))}}" class="font-medium whitespace-nowrap">{{$ad->title()}}</a>
        <div class="text-slate-500 text-xs whitespace-nowrap mt-0.5">{{optional($ad->category)->title()}}</div>
    </td>
    <td class="w-40">{{$ad->price()}} {{CoreHelper::settings()->getAttribute('app_currency')}}</td>
    <td class="w-40">{{$ad->getAttribute('views')}}</td>
    <td class="w-40">
        @switch($ad->getAttribute('published'))
            @case(true)
                <div class="flex items-center justify-center text-success">
                    <i data-lucide="check-square" class="w-4 h-4 mr-2"></i>
                    @lang('Published')
                </div>
                @break
            @case(false)
                <div class="flex items-center justify-center text-warning">
                    <i data-lucide="x" class="w-4 h-4 mr-2"></i>
                    @lang('Waiting')
                </div>
                @break
        @endswitch
    </td>
    <td class="w-40">
        @switch($ad->getAttribute('moderation'))
            @case('waiting')
                <span class="bg-warning text-light px-2 py-1 rounded">@lang('Moderate')</span>
                @break
            @case('moderated')
                <span class="bg-success text-light px-2 py-1 rounded">@lang('Moderated')</span>
                @break
            @case('rejected')
                <span class="bg-danger text-light px-2 py-1 rounded">@lang('Rejecte')</span>
                @break
        @endswitch
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
             'modelName' => 'ad',
             'editUrl' => route('admin:ad.edit',$ad->getAttribute('id')),
             'deleteUrl' => route('admin:ad.destroy',$ad->getAttribute('id'))
         ])
    </td>
</tr>
