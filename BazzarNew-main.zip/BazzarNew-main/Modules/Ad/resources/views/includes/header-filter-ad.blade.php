<div class="hidden md:block mx-auto text-slate-500">
    {{ __('pagination', [
    'firstItem' => strval($models->firstItem() ?? 0),
    'lastItem' => strval($models->lastItem() ?? 0),
    'total' => strval($models->total() ?? 0),
    ]) }}
</div>
<form action="" method="get" class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0 flex flex-wrap justify-between">
    <div class="w-full sm:w-56 relative text-slate-500 mb-2 sm:mr-2">
        <input type="search" class="form-control w-full sm:w-56 box pr-10" name="search" value="{{request()->input('search')}}" placeholder="@lang('Search')...">
        <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-lucide="search"></i>
    </div>
    <div class="w-20 sm:w-20 mb-2 sm:mb-0 sm:mr-2">
        <select onchange="this.form.submit()" name="page-count" class="w-full form-select box">
            <option @selected(request()->input('page-count') == 12)>12</option>
            <option @selected(request()->input('page-count') == 24)>24</option>
            <option @selected(request()->input('page-count') == 36)>36</option>
            <option @selected(request()->input('page-count') == 48)>48</option>
        </select>
    </div>
    <div class="w-20 sm:w-20">
        <select onchange="this.form.submit()" name="moderation" class="w-full form-select box">
            <option @selected(request()->input('moderation') == '')>@lang('All')</option>
            <option @selected(request()->input('moderation') == 'waiting') value="moderate">@lang('Moderate')</option>
            <option @selected(request()->input('moderation') == 'moderated') value="moderated">@lang('Moderated')</option>
            <option @selected(request()->input('moderation') == 'rejected') value="rejected">@lang('Rejected')</option>
        </select>
    </div>
</form>

