<?php

namespace Modules\Ad\database\seeders;

use Illuminate\Database\Seeder;

class AdDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
