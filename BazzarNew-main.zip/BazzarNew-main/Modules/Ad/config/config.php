<?php

return [
    'name' => 'Ad',
    'icon' => 'box',
    'group_icon' => 'megaphone',
    'group' => 'Ads management',
    'route_is' => 'admin:ad.*',
    'route' => route('admin:ad.index'),
    'permission' => ['view ads','edit ad'],
];
