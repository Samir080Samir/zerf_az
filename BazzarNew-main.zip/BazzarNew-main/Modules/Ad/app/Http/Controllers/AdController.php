<?php

namespace Modules\Ad\app\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Notifications\AdModerate;
use App\Notifications\AdModerated;
use App\Notifications\AdPublished;
use App\Notifications\AdRejected;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\File;
use Modules\Ad\app\Http\Requests\AdUpdateRequest;
use Modules\Ad\app\Models\Ad;
use Modules\Ad\app\Models\AdGallery;
use Modules\Core\app\Traits\Files\ImageCompressor;
use Nwidart\Modules\Facades\Module;

class AdController extends Controller
{

    use ImageCompressor;

    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view ads')->only('index');
            $this->middleware('permission:create ad')->only('create');
            $this->middleware('permission:store ad')->only('store');
            $this->middleware('permission:edit ad')->only('edit');
            $this->middleware('permission:update ad')->only('update');
            $this->middleware('permission:destroy ad')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $moderationStatus = $request->input('moderation');
        $pageCount = $request->input('page-count', 12);

        $ads = Ad::with(['category', 'gallery'])->when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('title', 'LIKE', "%{$search}%");
            });
        })->when($moderationStatus, function ($query) use ($moderationStatus, $search) {
            return $query->whereModeration($moderationStatus);
        })->paginate($pageCount)->withQueryString();

        return view('ad::index', compact([
            'ads',
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('ad::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('ad::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ad $ad)
    {
        $gallery = $ad->gallery->map(function ($gallery) {
            return [
                'id' => $gallery->getAttribute('id'),
                'src' => $gallery->image(),
            ];
        });

        return view('ad::edit', compact([
            'ad',
            'gallery',
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(AdUpdateRequest $request, Ad $ad)
    {
        try {
            $validatedData = $request->safe();

            $ad->fill($validatedData->except('gallery'));

            $filters = $validatedData['filters'] ?? [];

            $ad->filters()->sync($filters);

            if (!empty($request->input('preloaded'))) {
                $deleted = array_diff($ad->gallery->pluck('id')->toArray(), $request->input('preloaded'));
                if (!empty($deleted)) {
                    foreach ($deleted as $delete) {
                        $image = AdGallery::find($delete);
                        if ($image) {
                            File::delete('/storage/images/' . $image->getAttribute('image'));
                            $image->delete();
                        }
                    }
                }
            } else {
                foreach ($ad->gallery as $image) {
                    File::delete('/storage/images/' . $image->getAttribute('image'));
                    $image->delete();
                }
            }

            if ($request->hasFile('gallery')) {
                foreach ($request->file('gallery') as $image) {
                    AdGallery::create([
                        'ad_id' => $ad->getAttribute('id'),
                        'image' => self::compressImage($image, 'AdGallery'),
                    ]);
                }
            }

            if ($ad->isDirty('published')) {
                match ($request->input('published')) {
                    true => $ad->user?->notify(new AdPublished($ad)),
                    default => function () {

                    }
                };
            }

            if ($ad->isDirty('moderation')) {
                match ($request->input('moderation')) {
                    'waiting' => $ad->user?->notify(new AdModerate($ad)),
                    'moderated' => $ad->user?->notify(new AdModerated($ad)),
                    'rejected' => $ad->user?->notify(new AdRejected($ad))
                };
            }

            $ad->save();

            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage(), 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
    }
}
