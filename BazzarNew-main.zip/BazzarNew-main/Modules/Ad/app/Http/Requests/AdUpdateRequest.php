<?php

namespace Modules\Ad\app\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;

class AdUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'slug' => Str::slug($this->input('title')),
            'published' => $this->boolean('published'),
            'expired' => $this->boolean('expired')
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'category_id' => ['nullable', 'exists:categories,id'],
            'user_id' => ['nullable', 'exists:users,id'],
            'city_id' => ['nullable', 'exists:cities,id'],
            'district_id' => ['nullable', 'exists:districts,id'],

            'slug' => ['nullable', 'string', 'max:200'],
            'title' => ['required', 'string', 'max:200'],
            'description' => ['required', 'string'],
            'price' => ['required', 'numeric'],

            'type' => ['required', 'string', 'in:free,vip,premium'],
            'moderation' => ['required', 'string', 'in:waiting,moderated,rejected'],
            'published' => ['required', 'boolean'],
            'expired' => ['required', 'boolean'],

            'gallery' => ['nullable', 'array'],
            'gallery.*' => ['image', 'mimes:jpeg,png,jpg,gif,webp,svg'],
            'preloaded' => ['nullable'],

            'filters' => ['nullable', 'array']
        ];
    }
}
