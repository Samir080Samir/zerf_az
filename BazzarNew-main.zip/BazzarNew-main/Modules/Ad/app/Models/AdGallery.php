<?php

namespace Modules\Ad\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Modules\Ad\Database\factories\AdGalleryFactory;
use Modules\Core\app\Traits\Data\Image;

class AdGallery extends Model
{
    use HasFactory, Image;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'ad_id',
        'image',
        'storage'
    ];

    protected static function newFactory(): AdGalleryFactory
    {
        return AdGalleryFactory::new();
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }
}
