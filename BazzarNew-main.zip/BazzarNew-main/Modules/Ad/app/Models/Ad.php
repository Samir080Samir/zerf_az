<?php

namespace Modules\Ad\app\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Ad\app\Traits\AdScopes;
use Modules\Ad\app\Traits\Filters;
use Modules\Ad\Database\factories\AdFactory;
use Modules\Category\app\Models\Category;
use Modules\City\app\Models\City;
use Modules\Core\app\Traits\Data\Description;
use Modules\Core\app\Traits\Data\SlugWithId;
use Modules\Core\app\Traits\Data\Title;
use Modules\Filter\app\Models\Filter;
use Modules\Guest\app\Models\Guest;
use Modules\Payment\app\Models\Payment;
use Modules\Report\app\Traits\Reportable;

class Ad extends Model
{
    use HasFactory, SlugWithId, Title, Description, Reportable, Filters, AdScopes;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'guest_id',
        'user_id',

        'category_id',
        'subcategory_id',

        'city_id',

        'slug',
        'title',
        'description',

        'price',

        'published',
        'type',
        'moderation',
        
        'created_at'
    ];

    protected static function newFactory(): AdFactory
    {
        return AdFactory::new();
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function guest(): BelongsTo
    {
        return $this->belongsTo(Guest::class,'guest_id');
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    protected function getDescendantIds(Category $category): array
    {
        $descendantIds = [$category->id];

        foreach ($category->children as $child) {
            $descendantIds = array_merge($descendantIds, $this->getDescendantIds($child));
        }

        return $descendantIds;
    }

    public function gallery(): HasMany
    {
        return $this->hasMany(AdGallery::class);
    }

    public function firstImage(): string
    {
        return $this->gallery->first()?->image() ?? asset('/assets/templates/default/images/png/no-image.png');
    }

    public function price()
    {
        return $this->getAttribute('price');
    }

    public function type()
    {
        return $this->getAttribute('type') == 'free' ? 'free' : $this->getAttribute('type');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function filters(): BelongsToMany
    {
        return $this->belongsToMany(Filter::class, 'ad_filters')->withPivot('value');
    }

    public function favorites(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'ad_favorites', 'ad_id', 'user_id');
    }

    public function favorite(): bool
    {
        return $this->favorites()->where('user_id', $this->getAttribute('user_id'))->exists();
    }

    public function url(): string
    {
        return $this->category
            ? route('web:categories.ads.category:slug.ad:id',[optional($this->category)->getFullPathSlug(), $this->getAttribute('id')])
            : route('web:categories.ads.category:slug.ad:id',[$this->getAttribute('id')]);
    }
}
