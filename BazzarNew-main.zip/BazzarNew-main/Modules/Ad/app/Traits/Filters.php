<?php

namespace Modules\Ad\app\Traits;

trait Filters
{
    public function scopeFilterSearch($query, $request): void
    {
        $search = $request->input('search');
        $query->when($search, function ($q) use ($search) {
            return $q->where('ads.title', 'LIKE', '%' . $search . '%');
        });
    }

    public function scopeFilters($query, $request): void
    {
        $filters = $request->input('filters');

        $query->when($filters, function ($q) use ($filters) {
            $q->where(function ($q) use ($filters) {
                foreach ($filters as $filterId => $filterValue) {
                    $q->orWhere(function ($q) use ($filterId, $filterValue) {
                        $q->whereHas('filters', function ($q) use ($filterId, $filterValue) {
                            $q->where('filters.id', $filterId)->where('value', $filterValue);
                        });
                    });
                }
            });
        });
    }

    public function scopeFilterCity($query, $request): void
    {
        $slug = $request->input('city');
        $query->when($slug, function ($q) use ($slug) {
            return $q->whereHas('city', function ($cities) use ($slug) {
                return $cities->where('slug', '=', $slug);
            });
        });
    }

    public function scopeFilterPrice($query, $request): void
    {
        $min = $request->input('min');
        $max = $request->input('max');
        $query->when($min && $max, function ($q) use ($min, $max) {
            return $q->whereBetween('price', [$min, $max]);
        });
    }
}
