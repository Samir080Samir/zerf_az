<?php

namespace Modules\Ad\app\Traits;

use Modules\Category\app\Models\Category;

trait AdScopes
{
    public function scopeActive($query)
    {
        return $query->whereModeration('moderated')->wherePublished(true);
    }

    public function scopeActiveFree($query)
    {
        return $query->whereModeration('moderated')->wherePublished(true)->whereType('free');
    }

    public function scopeActiveVip($query)
    {
        return $query->whereModeration('moderated')->wherePublished(true)->whereType('vip');
    }

    public function scopeActivePremium($query)
    {
        return $query->whereModeration('moderated')->wherePublished(true)->whereType('premium');
    }

    public function scopeInCategoryAndDescendants($query, $categoryName)
    {
        $category = Category::where('name', $categoryName)->first();

        if (!$category) {
            return $query;
        }

        $categoryIds = $this->getDescendantIds($category);

        return $query->whereIn('category_id', $categoryIds);
    }
}
