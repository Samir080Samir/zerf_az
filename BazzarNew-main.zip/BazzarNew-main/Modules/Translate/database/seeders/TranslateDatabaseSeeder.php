<?php

namespace Modules\Translate\database\seeders;

use Illuminate\Database\Seeder;

class TranslateDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
