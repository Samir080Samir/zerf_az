<?php

use Illuminate\Support\Facades\Route;
use Modules\Translate\app\Http\Controllers\TranslateController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin')->name('admin:')->middleware(['auth', 'role_or_permission:show dashboard'])->group(function() {
    Route::controller(TranslateController::class)->name('translate.')->group(function (){
        Route::get('translate','index')->name('index');
        Route::get('translate/edit','edit')->name('edit');
        Route::put('translate/update','update')->name('update');
    });
});
