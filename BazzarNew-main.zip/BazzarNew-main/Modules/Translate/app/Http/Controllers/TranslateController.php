<?php

namespace Modules\Translate\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Modules\Core\app\Helpers\CoreHelper;
use Modules\Core\app\Http\Middleware\PrefixLocale;
use Nwidart\Modules\Facades\Module;

class TranslateController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view translates')->only('index');
            $this->middleware('permission:edit translate')->only('edit');
            $this->middleware('permission:update translate')->only('update');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $selectedLanguage = $request->input('locale', 'az');
        $langFiles = glob(lang_path("/templates/" . CoreHelper::settings()->getAttribute('template') . "/*.json"));

        $translations = PrefixLocale::$languages;

        $langData = [];

        foreach ($langFiles as $file) {
            $filename = basename($file, '.json');

            // Проверяем, соответствует ли текущий язык выбранному
            if ($filename === $selectedLanguage) {
                $translations = json_decode(file_get_contents($file), true);

                foreach ($translations as $key => $value) {
                    // Фильтруем данные на основе поискового запроса
                    if (empty($search) || stripos($key, $search) !== false || stripos($value, $search) !== false) {
                        $langData[] = [
                            'key' => $key,
                            'value' => $value,
                            'file' => $filename,
                        ];
                    }
                }
            }
        }
        return view('translate::index',compact([
            'langData',
            'translations'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('translate::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        //
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('translate::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        $key = $request->input('key');
        $filename = $request->input('file-name');

        $filePath = lang_path("/templates/" . CoreHelper::settings()->getAttribute('template') . "/{$filename}.json");

        if (file_exists($filePath)) {
            $fileData = json_decode(file_get_contents($filePath), true);
        } else {
            $fileData = [];
        }

        $value = $fileData[$key] ?? '';
        return view('translate::edit', compact([
            'key',
            'value',
            'filePath'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        try {
            $key = $request->input('key');
            $filename = $request->input('file-name');
            $value = $request->get('value');

            $filePath = $filename;

            if (file_exists($filePath)) {
                $fileData = json_decode(file_get_contents($filePath), true);

                // Проверка обязательных переменных в строке перевода
                $missingVariables = $this->checkMissingVariables($value, $fileData[$key]);

                if (!empty($missingVariables)) {
                    // Обработка ошибки - не все переменные были переданы
                    return response()->json(__('Missing variables in translation:') . ' ' . implode(', ', $missingVariables), 404);
                }

                $fileData[$key] = $value;
                file_put_contents($filePath, json_encode($fileData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            }

            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
    }

    private function checkMissingVariables($newValue, $originalValue)
    {
        preg_match_all('/:(\w+)/', $originalValue, $matches);

        $variables = $matches[1];

        $missingVariables = [];

        foreach ($variables as $variable) {
            // Проверяем наличие переменной в новом значении
            if (!str_contains($newValue, ":$variable")) {
                $missingVariables[] = $variable;
            }
        }

        return $missingVariables;
    }
}
