@extends('base::layouts.master')
@section('title',__('Edit translate'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Edit translate') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:productions.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form id="form-update" class="grid grid-cols-12 gap-2" novalidate action="{{route('admin:translates.update',['file-name' => $filePath, 'key' => $key])}}" method="post" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <x-base::form.input
                                :label="__('Key')"
                                name="title_az"
                                :value="old('key',$key)"
                                required/>

                            <x-base::form.input
                                :label="__('Value')"
                                name="value"
                                :value="old('value',$value)"
                                required/>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Update')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>
                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
            <!-- END: Form Validation -->
        </div>
    </div>
@endsection
@push('js')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let form = document.getElementById('form-update');
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                const formData = new FormData(this);
                axiosUpdate(this.action, form, formData)
            });
        })
    </script>
@endpush
