<tr class="intro-x">
    @php
        $flag = match ($lang['file']){
            'az' => 'az',
            'ru' => 'ru',
            'en' => 'us',
            'tr' => 'tr',
            'ar' => 'arab',
            'hi' => 'in',
            'zh_CN' => 'ch'
        }
    @endphp
    <td>
        <span class="fi fi-{{$flag}}"></span>
    </td>
    <td>
        {{Str::limit($lang['key'])}}
    </td>
    <td>
        <span @class(['text-success' => !empty($lang['value']),'text-danger' => empty($lang['value'])])>{{!empty($lang['value']) ? Str::limit($lang['value']) : 'Not have translation'}}</span>

    </td>
    <td class="table-report__action w-56">
        @include('base::includes.table-elements.action-buttons',[
            'modelName' => 'translate',
            'editUrl' => route('admin:translates.edit', ['file-name' => $lang['file'],'key' => $lang['key']])
        ])
    </td>
</tr>
