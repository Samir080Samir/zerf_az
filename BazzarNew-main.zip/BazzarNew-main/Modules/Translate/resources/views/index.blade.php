@extends('core::layouts.master')
@section('title',__('Translates'))
@section('content')
    <h2 class="intro-y text-lg font-medium mt-10">
        @lang('Translates')
    </h2>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <form action="" method="get" class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0 flex justify-between">
                <div class="w-56 relative text-slate-500 mr-2">
                    <input type="search" class="form-control w-56 box pr-10" name="search" value="{{request()->input('search')}}" placeholder="@lang('Search')...">
                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-lucide="search"></i>
                </div>
                <div class="flex align-items-center justify-between">
                    <select onchange="this.form.submit()" name="page-count" class="w-20 form-select box me-4">
                        <option @selected(request()->input('page-count') == 12)>12</option>
                        <option @selected(request()->input('page-count') == 24)>24</option>
                        <option @selected(request()->input('page-count') == 36)>36</option>
                        <option @selected(request()->input('page-count') == 48)>48</option>
                    </select>
                    <select onchange="this.form.submit()" name="locale" class="w-20 form-select box">
                        @foreach($translations as $translate)
                            <option @selected(request()->input('locale') == $translate) value="{{$translate}}">{{Str::ucfirst($translate)}}</option>
                        @endforeach
                    </select>
                </div>
            </form>
        </div>
        <div class="intro-y px-3 col-span-12 overflow-auto lg:overflow-visible">
            <!-- BEGIN: Data List -->
            <table class="table table-report -mt-2">
                <thead>
                <tr>
                    <th class="whitespace-nowrap">@lang('Flag')</th>
                    <th class="hidden lg:table-cell whitespace-nowrap">@lang('Key')</th>
                    <th class="hidden lg:table-cell whitespace-nowrap">@lang('Value')</th>
                    <th class="text-center whitespace-nowrap">@lang('Actions')</th>
                </tr>
                </thead>
                <tbody>
                @each('translate::includes.translate-tr',$langData,'lang','core::includes.not-found-tr')
                </tbody>
            </table>
            <!-- END: Data List -->
        </div>
    </div>
@endsection
