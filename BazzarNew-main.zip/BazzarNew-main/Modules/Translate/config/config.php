<?php

return [
    'name' => 'Translate',
];
