@extends('core::layouts.master')
@section('title',__('Create filter'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Filters') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:filter.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form class="grid grid-col-12 gap-2 form-store" action="{{route('admin:filter.store')}}" method="post">
                            @csrf

                            <div class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <x-core::form.input
                                    :label="__('Title')"
                                    name="title"
                                    :value="old('title')"
                                    required/>

                                <x-core::form.select
                                    id='type'
                                    :label="__('Type')"
                                    name="type"
                                    selected="input"
                                    :options="['input' => __('Normal input'),'boolean' => __('Boolean input'),'select' => __('Select input')]"
                                    required/>

                                <x-core::form.input
                                    :label="__('Options')"
                                    name="options"
                                    div-class="input-tags-hidden"
                                    input-class="input-tags"/>
                            </div>

                            <div class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="mt-3">
                                    <label>@lang('Categories')</label>
                                    <div class="mt-2 mb-3">
                                        <select name="categories[]" class="tom-select w-full" multiple>
                                            @foreach($categories as $title => $id)
                                                <option @selected(old('categories')) value="{{$id}}"> {{ $title }} </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Create')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
            <!-- END: Form Validation -->
        </div>
    </div>
@endsection
