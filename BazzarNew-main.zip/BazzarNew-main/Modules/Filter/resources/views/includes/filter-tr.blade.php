<tr class="intro-x">
    <td>
        <a href="{{route('admin:filter.edit',$filter->getAttribute('id'))}}" class="font-medium whitespace-nowrap">{{$filter->title()}}</a>
    </td>
    <td>
        {{$filter->getAttribute('categories_count')}}
    </td>
    <td>
        {{$filter->getAttribute('type')}}
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
            'modelName' => 'filter',
            'editUrl' => route('admin:filter.edit',$filter->getAttribute('id')),
            'deleteUrl' => route('admin:filter.destroy',$filter->getAttribute('id'))
        ])
    </td>
</tr>
