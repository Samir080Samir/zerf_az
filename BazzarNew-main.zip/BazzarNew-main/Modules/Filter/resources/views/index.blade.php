@extends('core::layouts.master')
@section('title',__('Filters'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Filters') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <a href="{{route('admin:filter.create')}}" class="btn btn-primary shadow-md mr-2">@lang('Add new')</a>
            @include('core::includes.header-filter',['models' => $filters])
        </div>
        <!-- BEGIN: Data List -->
        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
            <table class="table table-report -mt-2">
                <thead>
                    <tr>
                        <th class="whitespace-nowrap">@lang('Title')</th>
                        <th class="hidden lg:table-cell whitespace-nowrap">@lang('Used categories')</th>
                        <th class="hidden lg:table-cell whitespace-nowrap">@lang('Type')</th>
                        <th class="text-center whitespace-nowrap">@lang('Actions')</th>
                    </tr>
                </thead>
                <tbody>
                @each('filter::includes.filter-tr',$filters,'filter','core::includes.not-found-tr')
                </tbody>
            </table>
        </div>
        <!-- END: Data List -->
        <!-- BEGIN: Pagination -->
        {{$filters->links('core::includes.pagination')}}
        <!-- END: Pagination -->
    </div>
@endsection
