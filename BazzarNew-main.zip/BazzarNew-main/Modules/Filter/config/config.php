<?php

return [
    'name' => 'Filter',
    'icon' => 'map',
    'group_icon' => 'box',
    'group' => 'Site management',
    'route_is' => 'admin:filter.*',
    'route' => route('admin:filter.index'),
    'permission' => ['view filters','edit filter'],
];

