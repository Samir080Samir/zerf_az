<?php

namespace Modules\Filter\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Modules\Ad\app\Models\Ad;
use Modules\Category\app\Models\Category;
use Modules\Core\app\Traits\Data\Title;
use Modules\Filter\Database\factories\FilterFactory;

class Filter extends Model
{
    use HasFactory, Title;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'title',
        'type',
        'options'
    ];

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class,'category_filters');
    }

    public function ads(): BelongsToMany
    {
        return $this->belongsToMany(Ad::class, 'ad_filters')->withPivot('value');
    }

    protected static function newFactory(): FilterFactory
    {
        //return FilterFactory::new();
    }
}
