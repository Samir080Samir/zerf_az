<?php

namespace Modules\Filter\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Filter\Database\factories\AdFilterFactory;

class AdFilter extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'filter_id',
        'ad_id',
        'value'
    ];

    protected static function newFactory(): AdFilterFactory
    {
        //return AdFilterFactory::new();
    }
}
