<?php

namespace Modules\Filter\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Category\app\Models\Category;
use Modules\Filter\app\Http\Requests\FilterStoreRequest;
use Modules\Filter\app\Http\Requests\FilterUpdateRequest;
use Modules\Filter\app\Models\Filter;
use Nwidart\Modules\Facades\Module;

class FilterController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view filters')->only('index');
            $this->middleware('permission:create filter')->only('create');
            $this->middleware('permission:store filter')->only('store');
            $this->middleware('permission:edit filter')->only('edit');
            $this->middleware('permission:update filter')->only('update');
            $this->middleware('permission:destroy filter')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $filters = Filter::withCount('categories')->when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('title', 'LIKE', "%{$search}%");
            });
        })->paginate($pageCount)->withQueryString();

        return view('filter::index', compact([
            'filters'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::pluck('id','title');
        return view('filter::create',compact([
            'categories'
        ]));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(FilterStoreRequest $request)
    {
        try {
            $filter = Filter::create($request->validationData());

            $filter->categories()->sync($request->input('categories'));

            return response()->json(__('Data successfully created!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Filter $filter)
    {
        $categories = Category::pluck('id','title');
        return view('filter::edit', compact([
            'filter',
            'categories'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(FilterUpdateRequest $request, Filter $filter)
    {
        try {

            $filter->update($request->validationData());

            $filter->categories()->sync($request->input('categories'));

            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Filter $filter)
    {
        try {

            $filter->delete();

            return response()->json(__('Data successfully delete!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
}
