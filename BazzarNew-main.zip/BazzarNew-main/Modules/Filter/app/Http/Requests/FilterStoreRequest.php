<?php

namespace Modules\Filter\app\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FilterStoreRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:250'],
            'type' => ['required', 'string', 'in:input,boolean,select'],
            'options' => ['required_if:type,select', 'nullable'],
            'categories' => ['nullable', 'array'],
            'categories.*' => ['exists:categories,id']
        ];
    }

    /**
     * Handle a passed validation attempt.
     */
    protected function passedValidation(): void
    {
        $this->merge([
            'options' => $this->filled('options') ? json_encode(explode(',', $this->options), true) : null
        ]);
    }
}
