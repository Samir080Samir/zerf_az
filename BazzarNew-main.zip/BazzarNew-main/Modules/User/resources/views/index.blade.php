@extends('core::layouts.master')
@section('title',__('Users'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Users') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:user.index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
            <a href="{{route('admin:user.create')}}" class="btn btn-primary shadow-md mr-2">@lang('Add new')</a>
            @include('core::includes.header-filter',['models' => $users])
        </div>
        <!-- BEGIN: Data List -->
        <div class="col-span-12 grid grid-cols-12 gap-6 mt-5">
            @each('user::includes.user-cart',$users,'user','core::includes.not-found')
        </div>
        <!-- END: Data List -->
        <!-- BEGIN: Pagination -->
        {{$users->links('core::includes.pagination')}}
        <!-- END: Pagination -->
    </div>
@endsection
