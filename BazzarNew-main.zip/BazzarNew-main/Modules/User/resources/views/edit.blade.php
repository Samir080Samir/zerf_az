@extends('core::layouts.master')
@section('title',__('Edit user'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Edit user') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:user.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
            <a href="{{route('admin:user.store')}}" class="btn btn-primary shadow-md mr-2">@lang('Add new')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form id="form-update" class="grid grid-cols-12 gap-2" novalidate action="{{route('admin:user.update',$user->getAttribute('id'))}}" method="post" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="grid grid-cols-12 col-span-12 gap-2 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 p-4 mb-3">
                                <div class="col-span-12 lg:col-span-2">
                                    <div class="axios-image rounded-md p-5">
                                        <div class="h-40 relative image-fit cursor-pointer zoom-in mx-auto">
                                            <img class="rounded-md w-full" src="{{$user->avatar()}}" alt="{{$user->fullName()}}">
                                        </div>
                                        <div class="mx-auto cursor-pointer relative mt-5">
                                            <button type="button" class="btn btn-primary w-full">@lang('Change image')</button>
                                            <input type="file" name="image" class="w-full h-full top-0 left-0 absolute opacity-0" onchange="imagePreview(event)">
                                        </div>
                                    </div>
                                </div>
                                <div class="grid grid-cols-12 gap-2 col-span-12 lg:col-span-10 my-auto">
                                    <x-core::form.input
                                        :label="__('Name')"
                                        name="first_name"
                                        div-class="lg:col-span-3"
                                        :value="old('first_name',$user->getAttribute('first_name'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Surname')"
                                        name="last_name"
                                        div-class="lg:col-span-3"
                                        :value="old('last_name',$user->getAttribute('last_name'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Email')"
                                        name="email"
                                        div-class="lg:col-span-3"
                                        :value="old('email',$user->getAttribute('email'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Phone')"
                                        name="phone"
                                        input-class="phone"
                                        div-class="lg:col-span-3"
                                        :value="old('phone',$user->getAttribute('phone'))"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Password')"
                                        name="password"
                                        div-class="lg:col-span-3"
                                        :value="old('password')"
                                        required/>

                                    <x-core::form.input
                                        :label="__('Confirm Password')"
                                        name="password_confirmation"
                                        div-class="lg:col-span-3"
                                        :value="old('password_confirmation')"
                                        required/>

                                    <x-core::form.select
                                        :label="__('Role')"
                                        name="role"
                                        div-class="lg:col-span-3"
                                        :selected="old('role', $user->getRoleNames()->first())"
                                        :options="$roles"
                                        required/>

                                </div>
                            </div>

                            @if($user->hasAnyRole(['designer','Designer']))
                                <div class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                    <x-core::form.textarea
                                        :label="__('Biography')"
                                        name="bio"
                                        input-class="editor"
                                        :value="old('bio', $user->getAttribute('bio'))"/>
                                </div>
                            @endif

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Update')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
