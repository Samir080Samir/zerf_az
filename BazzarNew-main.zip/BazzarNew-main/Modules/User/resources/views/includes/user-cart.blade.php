<div class="intro-y col-span-12 md:col-span-6">
    <div class="box">
        <div class="flex flex-col lg:flex-row items-center p-5 border-b border-slate-200/60 dark:border-darkmode-400">
            <div class="w-24 h-24 lg:w-12 lg:h-12 image-fit lg:mr-1">
                <img class="rounded-full" src="{{$user->avatar()}}" alt="{{$user->fullName()}}">
            </div>
            <div class="lg:ml-2 lg:mr-auto text-center lg:text-left mt-3 lg:mt-0">
                <a href="{{route('admin:user.edit',$user->getAttribute('id'))}}" class="font-medium">{{$user->fullName()}}</a>
                <div class="text-slate-500 text-xs mt-0.5">{{$user->getRoleNames()->first()}}</div>
            </div>
            <div class="flex -ml-2 lg:ml-0 lg:justify-end mt-3 lg:mt-0">
                <a href="mailto:{{$user->getAttribute('email')}}" class="w-10 h-10 rounded-full flex items-center justify-center border dark:border-darkmode-400 ml-2 text-slate-400 zoom-in tooltip" title="@lang('Email')">
                    <i class="w-5 h-5 fill-primary" data-lucide="mail"></i>
                </a>
                <a href="tel:{{CoreHelper::telCleaner($user->getAttribute('phone'))}}" class="w-10 h-10 rounded-full flex items-center justify-center border dark:border-darkmode-400 ml-2 text-slate-400 zoom-in tooltip" title="@lang('Phone')">
                    <i class="w-5 h-5 fill-primary" data-lucide="phone"></i>
                </a>
            </div>
        </div>
        <div class="flex flex-wrap lg:flex-nowrap items-center justify-center p-5">
            @include('core::includes.table-elements.action-buttons',[
            'modelName' => 'user',
            'editUrl' => route('admin:user.edit',$user->getAttribute('id')),
            'deleteUrl' => route('admin:user.destroy',$user->getAttribute('id'))
        ])
        </div>
    </div>
</div>
