<?php

namespace Modules\User\app\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Modules\Core\app\Traits\Files\ImageCompressor;
use Modules\User\app\Http\Requests\UserStoreRequest;
use Nwidart\Modules\Facades\Module;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    use ImageCompressor;

    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view users')->only('index');
            $this->middleware('permission:create user')->only('create');
            $this->middleware('permission:store user')->only('store');
            $this->middleware('permission:edit user')->only('edit');
            $this->middleware('permission:update user')->only('update');
            $this->middleware('permission:destroy user')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count',12);

        $users = User::when($search, function ($product) use ($search) {
            return $product->where('name', 'LIKE', "%{$search}%")
                ->orWhere('surname', 'LIKE', "%{$search}%")
                ->orWhere('phone', 'LIKE', "%{$search}%")
                ->orWhere('email', 'LIKE', "%{$search}%");
        })->paginate($pageCount)->withQueryString();

        return view('user::index',compact([
            'users'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $roles = Role::pluck('name', 'name')->toArray();
        return view('user::create',compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(UserStoreRequest $request)
    {
        try {

            $validated = $request->all();

            $validated['password'] = Hash::make($request->input('password'));

            if ($request->hasFile('image')){
                $validated['image'] = self::compressImage($request->file('image'),'UserAvatar');
            }

            $user = User::create($validated);

            $user->assignRole($request->input('role'));

            return response()->json(__('Data successfully created!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Show the specified resource.
     */
    public function show(User $user)
    {
        return view('user::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        $roles = Role::pluck('name', 'name')->toArray();
        return view('user::edit',compact([
            'user',
            'roles'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        try {

            $validated = $request->all();

            if ($request->filled('password')) {
                $validated['password'] = Hash::make($request->input('password'));
            } else {
                unset($validated['password']);
            }

            if ($request->hasFile('image')){
                File::delete('/storage/images/' . $user->getAttribute('image'));
                $validated['image'] = self::compressImage($request->file('image'),'UserAvatar');
            }else{
                $validated['image'] = $user->getAttribute('image');
            }

            $user->update($validated);

            $user->syncRoles([$request->input('role')]);

            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(User $user)
    {
        try {

            if ($user->getAttribute('image')) {
                File::delete('/storage/images/' . $user->getAttribute('image'));
            }

            $user->delete();

            return response()->json(__('Data successfully deleted!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
}
