<?php

namespace Modules\Category\app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Support\Collection;
use Modules\Ad\app\Models\Ad;
use Modules\Category\Database\factories\CategoryFactory;
use Modules\Core\app\Traits\Data\Description;
use Modules\Core\app\Traits\Data\Image;
use Modules\Core\app\Traits\Data\SlugWithId;
use Modules\Core\app\Traits\Data\Title;
use Modules\Filter\app\Models\CategoryFilter;
use Modules\Filter\app\Models\Filter;

class Category extends Model
{
    use HasFactory, SlugWithId, Title, Description, Image;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'parent_id',
        'slug',
        'title',
        'description',
        'image'
    ];

    protected static function newFactory(): CategoryFactory
    {
        return CategoryFactory::new();
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(Category::class, 'parent_id')->withCount('ads');
    }

    public function ads(): HasManyThrough
    {
        return $this->hasManyThrough(Ad::class, Category::class, 'parent_id', 'category_id', 'id', 'id')
            ->where(function ($query) {
                $query->where('moderation', '=', 'moderated')
                    ->where('published', '=', true);
            })
            ->orWhere(function ($query) {
                $query->where('category_id', $this->id)
                    ->where('moderation', '=', 'moderated')
                    ->where('published', '=', true);
            });
    }


    public function getFullPathSlug(): string
    {
        if ($this->parent) {
            return $this->parent->getFullPathSlug() . '/' . $this->slug();
        }

        return $this->slug();
    }

    public function ancestors(): Collection
    {
        $ancestors = collect([$this]);

        $parent = $this->parent;

        while ($parent) {
            $ancestors->prepend($parent);
            $parent = $parent->parent;
        }

        return $ancestors;
    }

    public function filters(): BelongsToMany
    {
        return $this->belongsToMany(Filter::class, 'category_filters');
    }

    public function filtersWithValues(): HasManyThrough
    {
        return $this->hasManyThrough(
            Filter::class,
            CategoryFilter::class,
            'category_id',    // Внешний ключ в таблице `category_filters`
            'id',             // Внешний ключ в таблице `filters`
            'id',             // Локальный ключ в таблице `categories`
            'filter_id'       // Локальный ключ в таблице `category_filters`
        )->join('ad_filters', function ($join) {
            $join->on('filters.id', '=', 'ad_filters.filter_id');
            $join->on('category_filters.filter_id', '=', 'ad_filters.filter_id');
        })->select('filters.*', \DB::raw('GROUP_CONCAT(ad_filters.value) as filter_values'))
            ->groupBy('filters.id', 'category_filters.category_id');
    }


    public function scopeMainCategories($query)
    {
        return $query->whereNull('parent_id');
    }
}
