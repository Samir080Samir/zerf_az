<?php

namespace Modules\Category\app\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;

class CategoryUpdateRequest extends FormRequest
{
    /**
     * @return bool
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return void
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'slug' => Str::slug($this->input('title')),
            'parent_id' => $this->filled('parent_id') ? $this->input('parent_id') : null,
        ]);
    }

    /**
     * @return array
     */
    public function rules(): array
    {
        return [
            'parent_id' => ['nullable','exists:categories,id'],
            'slug' => ['nullable', 'string', 'max:200'],
            'title' => ['string','max:200'],
            'description' => ['nullable'],
            'image' => ['nullable','image','mimes:jpeg,png,jpg,gif,webp,svg']
        ];
    }
}
