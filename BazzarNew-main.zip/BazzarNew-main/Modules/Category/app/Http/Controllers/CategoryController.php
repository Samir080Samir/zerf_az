<?php

namespace Modules\Category\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\File;
use Modules\Category\app\Http\Requests\CategoryStoreRequest;
use Modules\Category\app\Http\Requests\CategoryUpdateRequest;
use Modules\Category\app\Models\Category;
use Modules\Core\app\Traits\Files\ImageCompressor;
use Nwidart\Modules\Facades\Module;

class CategoryController extends Controller
{
    use ImageCompressor;

    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view categories')->only('index');
            $this->middleware('permission:create category')->only('create');
            $this->middleware('permission:store category')->only('store');
            $this->middleware('permission:edit category')->only('edit');
            $this->middleware('permission:update category')->only('update');
            $this->middleware('permission:destroy category')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $categories = Category::with(['children', 'parent'])->when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('title', 'LIKE', "%{$search}%");
            });
        })->paginate($pageCount)->withQueryString();

        return view('category::index', compact([
            'categories'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('category::create',compact([
            'categories'
        ]));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CategoryStoreRequest $request)
    {
        try {
            $validatedData = $request->validated();

            if ($request->hasFile('image')) {
                $validatedData['image'] = self::compressImage($request->file('image'), 'CategoryImage');
            }

            Category::create($validatedData);

            self::clearCategoriesCache();
            return response()->json(__('Data successfully created!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category $category)
    {
        $categories = Category::all();
        return view('category::edit', compact([
            'category',
            'categories'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(CategoryUpdateRequest $request, Category $category)
    {
        try {
            $validatedData = $request->validated();

            if ($request->hasFile('image')) {
                if ($category->getAttribute('image')) {
                    File::delete('/storage/images/' . $category->getAttribute('image'));
                }
                $validatedData['image'] = self::compressImage($request->file('image'), 'CategoryImage');
            } else {
                $validatedData['image'] = $category->getAttribute('image');
            }

            $category->update($validatedData);

            self::clearCategoriesCache();
            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        try {

            if ($category->getAttribute('image')) {
                File::delete('/storage/images/' . $category->getAttribute('image'));
            }

            $category->delete();

            return response()->json(__('Data successfully deleted!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }

    protected function clearCategoriesCache()
    {
        Cache::forget('categories');
    }
}
