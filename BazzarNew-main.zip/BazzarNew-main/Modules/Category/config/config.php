<?php

return [
    'name' => 'Category',
    'icon' => 'layout-grid',
    'group_icon' => 'box',
    'group' => 'Ads management',
    'route_is' => 'admin:category.*',
    'route' => route('admin:category.index'),
    'permission' => ['view categories','edit category'],
];
