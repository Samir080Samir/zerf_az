<tr class="intro-x">
    <td class="w-40">
        <div class="flex">
            @if($category->image())
                <div class="w-10 h-10 image-fit zoom-in rounded-full">
                    <img class="tooltip rounded-full" src="{{$category->image()}}" alt="{{$category->title()}}" title="@lang('Icon image')">
                </div>
            @endif
        </div>
    </td>
    <td>
        <a href="{{route('admin:category.edit',$category->getAttribute('id'))}}" class="font-medium whitespace-nowrap">
            {{$category->title()}} (<span class="font-bold">{{$category->getAttribute('ads_count')}}</span>)
        </a>
        @if($category->parent)
            <div class="text-slate-500 text-xs font-medium whitespace-nowrap mt-0.5">
                @lang('Main category'):<span class="font-bold"> {{$category->parent->title()}}</span>
            </div>
        @endif
    </td>
    <td>
        <a class="text-slate-500 flex items-center" href="javascript:;">
            <i data-lucide="external-link" class="w-4 h-4 mr-2"></i>
            <span class="font-bold">{{Str::limit($category->getFullPathSlug(),50)}}</span>
        </a>
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
            'modelName' => 'category',
            'editUrl' => route('admin:category.edit',$category->getAttribute('id')),
            'deleteUrl' => route('admin:category.destroy',$category->getAttribute('id'))
        ])
    </td>
</tr>
