@extends('core::layouts.master')
@section('title',__('Create category'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Create category') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:category.index')}}" class="btn btn-primary shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <form class="grid grid-cols-12 gap-2 form-store" novalidate action="{{route('admin:category.store')}}" method="post" enctype="multipart/form-data">
                            @csrf
                            <div class="grid grid-cols-12 col-span-12 gap-2 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 p-4 mb-3">

                                <div class="col-span-12 lg:col-span-2">
                                    <div class="axios-image rounded-md p-5">
                                        <div class="h-40 relative image-fit cursor-pointer zoom-in mx-auto">
                                            <img id="output" class="rounded-md w-full" src="{{Vite::asset('resources/images/placeholders/no-image.webp')}}" alt="">
                                        </div>
                                        <div class="mx-auto cursor-pointer relative mt-5">
                                            <button type="button" class="btn btn-primary w-full">@lang('Image')</button>
                                            <input type="file" name="image" class="w-full h-full top-0 left-0 absolute opacity-0" onchange="imagePreview(event)">
                                        </div>
                                    </div>
                                </div>

                                <div class="grid grid-cols-12 col-span-12 gap-2 lg:col-span-10 my-auto">

                                    <x-core::form.input
                                        :label="__('Title')"
                                        name="title"
                                        :value="old('title')"
                                        required/>

                                    <div class="col-span-12">
                                        <div class="mt-3">
                                            <label>@lang('Main category')</label>
                                            <div class="mt-2 mb-3">
                                                <select name="parent_id" class="tom-select w-full">
                                                    <option value=""> @lang('Select main category') </option>
                                                    @foreach($categories as $category)
                                                        <option @selected(old('parent_id')) value="{{$category->getAttribute('id')}}"> {{ $category->title() }} </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>

                            <div class="col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">

                                <x-core::form.textarea
                                    :label="__('Description')"
                                    name="description"
                                    input-class="editor"
                                    :value="old('description')"/>


                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Create')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
