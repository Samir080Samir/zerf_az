<?php

namespace Modules\Payment\app\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Modules\Ad\app\Models\Ad;
use Modules\Core\app\Helpers\CoreHelper;
use Modules\Payment\Database\factories\PaymentFactory;

class Payment extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'transaction_id',
        'ad_id',
        'user_id',
        'amount',
        'status',
        'payment_type',
        'service_type',
        'service_period',
        'expired',
        'url'
    ];

    public function amount()
    {
        return CoreHelper::formatPrice($this->getAttribute('amount'));
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function scopePaid($query)
    {
        return $query->whereStatus('paid');
    }

    public function scopeNotExpired($query)
    {
        return $query->whereExpired(false);
    }

    public function scopeTypeUp($query)
    {
        return $query->whereServiceType('up');
    }

    public function scopeTypeVipPremium($query)
    {
        return $query->whereIn('service_type', ['vip', 'premium']);
    }

    protected static function newFactory(): PaymentFactory
    {
        //return PaymentFactory::new();
    }
}
