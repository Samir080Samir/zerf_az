<?php

namespace Modules\Payment\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Nwidart\Modules\Facades\Module;
use Modules\Payment\app\Models\Payment;

class PaymentController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            // $this->middleware('permission:view payments')->only('index');
            // $this->middleware('permission:create payment')->only('create');
            // $this->middleware('permission:store payment')->only('store');
            // $this->middleware('permission:edit payment')->only('edit');
            // $this->middleware('permission:update payment')->only('update');
            // $this->middleware('permission:destroy payment')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $search = $request->input('search');
        $pageCount = $request->input('page-count', 12);

        $payments = Payment::with(['ad', 'user'])->when($search, function ($query) use ($search) {
            return $query->where(function ($query) use ($search) {
                $query->where('transaction_id', 'LIKE', "%{$search}%")
                    ->orWhereHas('user', function ($q) use ($search) {
                        return $q->where('first_name', 'LIKE', "%{$search}%")
                            ->orWhere('last_name', 'LIKE', "%{$search}%")
                            ->orWhere('email', 'LIKE', "%{$search}%");
                    })->orWhereHas('ad', function ($q) use ($search) {
                        return $q->where('title', 'LIKE', "%{$search}%");
                    });
            });
        })->paginate($pageCount)->withQueryString();

        return view('payment::index', compact([
            'payments'
        ]));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('payment::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        //
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        return view('payment::show');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('payment::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id): RedirectResponse
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
    }
}
