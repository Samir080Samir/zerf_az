<?php

return [
    'name' => 'Payment',
    'icon' => 'box',
    'group_icon' => 'megaphone',
    'group' => 'Ads management',
    'route_is' => 'admin:payment.*',
    'route' => route('admin:payment.index'),
    'permission' => ['view payments','edit payment'],
];
