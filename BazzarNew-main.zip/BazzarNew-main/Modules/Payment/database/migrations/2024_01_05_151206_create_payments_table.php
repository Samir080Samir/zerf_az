<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();

            $table->string('transaction_id');

            $table->unsignedBigInteger('ad_id')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();

            $table->float('amount')->index();
            $table->enum('service_type', ['up', 'vip', 'premium', 'balance'])->default('up')->index();
            $table->integer('service_period')->nullable()->index();

            $table->enum('payment_type', ['online', 'balance'])->default('online')->index();
            $table->string('status')->default('waiting')->index();
            $table->boolean('expired')->default(false);
            $table->string('url')->nullable();

            $table->foreign('ad_id')->references('id')->on('ads')->cascadeOnUpdate()->cascadeOnDelete();
            $table->foreign('user_id')->references('id')->on('users')->cascadeOnUpdate()->cascadeOnDelete();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
