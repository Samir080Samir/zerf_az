<tr class="intro-x">
    <td>
        <a href="{{route('admin:payment.edit',$payment->getAttribute('id'))}}" class="font-medium whitespace-nowrap">
            {{$payment->getAttribute('transaction_id')}}
        </a>
    </td>
    <td>
        @if ($payment->user)
        <a href="{{ route('admin:user.edit',$payment->user->getAttribute('id')) }}">
            {{ Str::limit($payment->user->fullName()) }}
        </a>
        @else
            @lang('Not found')
        @endif
    </td>
    <td>
        @if ($payment->ad)
        <a href="{{ route('admin:ad.edit',$payment->ad->getAttribute('id')) }}">
            {{ Str::limit($payment->ad->title()) }}
        </a>
        @else
            @lang('Not found')
        @endif
    </td>
    <td>
        {{ $payment->getAttribute('payment_type') }}
    </td>
    <td>
        {{ $payment->getAttribute('service_type') }}
    </td>
    <td>
        {{CoreHelper::formatPrice($payment->getAttribute('amount'))}}
    </td>
    <td>
        {{$payment->getAttribute('status')}}
    </td>
    <td>
        {{$payment->getAttribute('created_at')->format('d.m.y H:i')}}
    </td>
    <td class="table-report__action w-56">
        @include('core::includes.table-elements.action-buttons',[
        'modelName' => 'payment',
        // 'editUrl' => route('admin:payment.edit',$payment->getAttribute('id')),
        // 'deleteUrl' => route('admin:payment.destroy',$payment->getAttribute('id'))
        ])
    </td>
</tr>