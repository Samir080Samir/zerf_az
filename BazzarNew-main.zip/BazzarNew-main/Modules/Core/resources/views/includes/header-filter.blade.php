<div class="hidden md:block mx-auto text-slate-500">
    {{ __('pagination', [
    'firstItem' => strval($models->firstItem() ?? 0),
    'lastItem' => strval($models->lastItem() ?? 0),
    'total' => strval($models->total() ?? 0),
    ]) }}
</div>
<form action="" method="get" class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0 flex justify-between">
    <div class="w-56 relative text-slate-500 mr-2">
        <input type="search" class="form-control w-56 box pr-10" name="search" value="{{request()->input('search')}}" placeholder="@lang('Search')...">
        <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-lucide="search"></i>
    </div>
    <select onchange="this.form.submit()" name="page-count" class="w-20 form-select box">
        <option @selected(request()->input('page-count') == 12)>12</option>
        <option @selected(request()->input('page-count') == 24)>24</option>
        <option @selected(request()->input('page-count') == 36)>36</option>
        <option @selected(request()->input('page-count') == 48)>48</option>
    </select>
</form>
