<tr class="intro-x">
    <td colspan="100" class="text-center">
        @lang('Hecbir məlumat tapılmadı')
    </td>
</tr>
