<div class="intro-x w-10 h-10 image-fit">
    <img alt="" class="rounded-full" src="{{$image}}">
</div>
