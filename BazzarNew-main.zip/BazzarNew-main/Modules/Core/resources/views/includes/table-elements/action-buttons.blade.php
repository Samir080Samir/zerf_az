<div class="text-center py-2">
    <div class="btn-group">
        @can("impersonate $modelName")
            @isset($userId)
                @if(auth()->user()->canImpersonate() && !auth()->user()->isImpersonating() ?? auth()->user()->getAttribute('id') !== $userId)
                    <a href="{{ route('admin:impersonation.start', $userId) }}" class="btn btn-success js-bs-tooltip-enabled">
                        <i data-lucide="login" class="block mx-auto"></i>
                    </a>
                @endif
                @if(auth()->user()->isImpersonating() && auth()->user()->getImpersonatedUser()->id === $userId)
                    <a href="{{ route('admin:impersonation.stop') }}" class="btn btn-danger js-bs-tooltip-enabled">
                        <i data-lucide="log-out" class="block mx-auto"></i>
                    </a>
                @endif
            @endisset
        @endcan
        @can("show $modelName")
            @isset($showUrl)
                <a href="{{$showUrl}}" class="btn btn-sm btn-dark">
                    <i data-lucide="eye" class="block mx-auto"></i>
                </a>
            @endisset
        @endcan
        @can("edit $modelName")
            @isset($editUrl)
                <a href="{{$editUrl}}" type="button" class="btn btn-sm btn-dark">
                    <i data-lucide="pencil" class="block mx-auto"></i>
                </a>
            @endisset
        @endcan
        @can("destroy $modelName")
            @isset($deleteUrl)
                <button onclick="deleteFunction(this)" data-delete-url="{{$deleteUrl}}" class="btn btn-sm btn-dark">
                    <i data-lucide="delete" class="block mx-auto"></i>
                </button>
            @endisset
        @endcan
    </div>
</div>
@can("destroy $modelName")
    @once
        @push('js')
            <script>
                function deleteFunction(element) {
                    SweetAlert.fire({
                        title: '{{__('Confirm deletion!')}}',
                        text: "{{__('It will be impossible to return the data!')}}",
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonText: '{{__('Delete')}}',
                        cancelButtonText: '{{__('Cancel')}}',
                    }).then((result) => {
                        if (result.isConfirmed) {

                            let deleteUrl = element.getAttribute('data-delete-url');

                            fetch(deleteUrl, {
                                method: 'POST',
                                headers: {
                                    'X-CSRF-TOKEN': "{{csrf_token()}}",
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    _method: 'DELETE',
                                })
                            }).then(response => {
                                if (!response.ok) {
                                    return response.text().then(text => {
                                        SweetAlert.fire({
                                            icon: 'error',
                                            text: text,
                                        });
                                    })
                                }else{
                                    location.reload()
                                }
                            }).catch(error => {
                                SweetAlert.fire({
                                    icon: 'error',
                                    text: error,
                                });
                            })
                        }
                    })
                }
            </script>
        @endpush
    @endonce
@endcan
