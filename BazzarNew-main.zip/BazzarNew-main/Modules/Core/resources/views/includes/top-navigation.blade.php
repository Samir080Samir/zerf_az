<nav class="top-nav">
    <ul>
        <li>
            <a href="javascript:;" @class(['top-menu','top-menu--active' => Route::is('admin:index')])>
                <div class="top-menu__icon">
                    <i data-lucide="home"></i>
                </div>
                <div class="top-menu__title">
                    @lang('Application')
                    <i data-lucide="refresh-cw" class="top-menu__sub-icon"></i>
                </div>
            </a>
            <ul @class(['top-menu__sub-open' => Route::is('admin:index')])>
                <li>
                    <a href="{{route('admin:index')}}" class="top-menu">
                        <div class="top-menu__icon"><i data-lucide="activity"></i></div>
                        <div class="top-menu__title"> @lang('Home') </div>
                    </a>
                </li>
                <li>
                    <a href="{{route('web:index')}}" class="top-menu" target="_blank">
                        <div class="top-menu__icon"><i data-lucide="activity"></i></div>
                        <div class="top-menu__title"> @lang('Web') </div>
                    </a>
                </li>
            </ul>
        </li>

        <li class="top-nav__devider my-6"></li>

        @foreach(CoreHelper::moduleGroups() as $group)
            <li>
                <a href="javascript:;" @class(['top-menu','top-menu--active' => Route::is($group['routes'])])>
                    <div class="top-menu__icon">
                        <i data-lucide="{{$group['icon']}}"></i>
                    </div>
                    <div class="top-menu__title">
                        @lang($group['name'])
                        <i data-lucide="refresh-cw" class="top-menu__sub-icon"></i>
                    </div>
                </a>
                <ul @class(['top-menu__sub-open' => Route::is($group['routes'])])>
                    @foreach($group['modules'] as $module)
                        @if(Module::find($module['name'])->isEnabled())
                            @can('view users')
                                <li>
                                    <a href="{{$module['route']}}" class="top-menu">
                                        <div class="top-menu__icon">
                                            <i data-lucide="{{$module['icon']}}"></i>
                                        </div>
                                        <div class="top-menu__title">{{__(Str::plural($module['name']))}}</div>
                                    </a>
                                </li>
                            @endcan
                        @endif
                    @endforeach
                </ul>
            </li>
        @endforeach

        <li>
            <a href="javascript:;" @class(['top-menu','top-menu--active' => Route::is(['admin:user.*', 'admin:role.*'])])>
                <div class="top-menu__icon"><i data-lucide="user-cog"></i></div>
                <div class="top-menu__title">
                    @lang('Users management')
                    <i data-lucide="refresh-cw" class="top-menu__sub-icon"></i>
                </div>
            </a>
            <ul @class(['top-menu__sub-open' => Route::is(['admin:user.*', 'admin:role.*'])])>

                @if(Module::find('User')->isEnabled())
                    @can('view users')
                        <li>
                            <a href="{{route('admin:user.index')}}" class="top-menu">
                                <div class="top-menu__icon">
                                    <i data-lucide="users"></i>
                                </div>
                                <div class="top-menu__title">@lang('Users')</div>
                            </a>
                        </li>
                    @endcan
                @endif

                @if(Module::find('Role')->isEnabled())
                    @can('view roles')
                        <li>
                            <a href="{{route('admin:role.index')}}" class="top-menu">
                                <div class="top-menu__icon">
                                    <i data-lucide="key"></i>
                                </div>
                                <div class="top-menu__title">@lang('Roles & Permissions')</div>
                            </a>
                        </li>
                    @endcan
                @endif

            </ul>
        </li>

        <li>
            <a href="javascript:;" @class(['top-menu','top-menu--active' => Route::is(['admin:tools.*', 'admin:settings.*', 'admin:translate.*'])])>
                <div class="top-menu__icon">
                    <i data-lucide="settings"></i>
                </div>
                <div class="top-menu__title">
                    @lang('Settings')
                    <i data-lucide="refresh-cw" class="top-menu__sub-icon"></i>
                </div>
            </a>
            <ul @class(['top-menu__sub-open' => Route::is(['admin:tools.*', 'admin:settings.*', 'admin:translate.*'])])>
                @canany(['clear cache', 'optimize', 'optimize clear', 'storage link', 'migrate', 'json language'])
                    <li>
                        <a href="{{route('admin:tools.index')}}" class="top-menu">
                            <div class="top-menu__icon">
                                <i data-lucide="command"></i>
                            </div>
                            <div class="top-menu__title"> @lang('Tools') </div>
                        </a>
                    </li>
                @endcanany
                @can('edit settings')
                    <li>
                        <a href="{{route('admin:settings.edit',1)}}" class="top-menu">
                            <div class="top-menu__icon">
                                <i data-lucide="settings"></i>
                            </div>
                            <div class="top-menu__title"> @lang('Settings') </div>
                        </a>
                    </li>
                @endcan
                @can('edit translate')
                    <li>
                        <a href="{{route('admin:translate.index')}}" class="top-menu">
                            <div class="top-menu__icon">
                                <i data-lucide="languages"></i>
                            </div>
                            <div class="top-menu__title"> @lang('Translates') </div>
                        </a>
                    </li>
                @endcan
                @can('view system-info')
                    <li>
                        <a href="{{route('admin:tools.system-information')}}" class="top-menu">
                            <div class="top-menu__icon">
                                <i data-lucide="info"></i>
                            </div>
                            <div class="top-menu__title"> @lang('System info') </div>
                        </a>
                    </li>
                @endcan
            </ul>
        </li>
    </ul>
</nav>
