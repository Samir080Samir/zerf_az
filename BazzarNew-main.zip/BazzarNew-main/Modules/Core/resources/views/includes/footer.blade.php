<footer class="bg-white rounded-lg shadow dark:bg-gray-900 my-4">
    <div class="grid grid-cols-12 mx-2">
        <div class="col-span-12 lg:col-span-6">
            <div class="flex flex-col align-items-flex-start p-4">
                <a href="https://npa.az" class="hover:underline">Npa Systems &copy; v 1</a>
                <p>All Rights Reserved.</p>
            </div>
        </div>

        <div class="col-span-12 lg:col-span-6 flex justify-end">
            <img class="h-10 w-auto my-auto footer-logo" src="{{asset('/npa/npa-logo-dark.png')}}" alt="{{CoreHelper::settings()->getAttribute('app_name')}}">
        </div>
    </div>
</footer>
