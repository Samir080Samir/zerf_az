<div class="mobile-menu md:hidden">
    <div class="mobile-menu-bar">
        <a href="{{route('admin:index')}}" class="flex mr-auto">
            <img alt="{{CoreHelper::settings()->getAttribute('app_name')}}" class="w-6"
                 src="{{ Vite::asset('resources/images/logo.svg') }}">
        </a>
        <a href="javascript:;" class="mobile-menu-toggler">
            <i data-lucide="bar-chart-2" class="w-8 h-8 text-white transform -rotate-90"></i>
        </a>
    </div>
    <div class="scrollable">
        <a href="javascript:;" class="mobile-menu-toggler">
            <i data-lucide="x-circle" class="w-8 h-8 text-white transform -rotate-90"></i>
        </a>
        <ul class="scrollable__content py-2">
            <li>
                <a href="javascript:;" @class(['menu','menu--active' => Route::is('admin:index')])>
                    <div class="menu__icon">
                        <i data-lucide="home"></i>
                    </div>
                    <div class="menu__title">
                        @lang('Application')
                        <i data-lucide="chevron-down" @class(['menu__sub-icon','transform rotate-180' => Route::is('admin:index')])></i>
                    </div>
                </a>
                <ul @class(['menu__sub-open' => Route::is('admin:index')])>

                    <li>
                        <a href="{{route('admin:index')}}" @class(['menu','menu--active' => Route::is('admin:index')])>
                            <div class="menu__icon"><i data-lucide="activity"></i></div>
                            <div class="menu__title"> @lang('Home') </div>
                        </a>
                    </li>

                    <li>
                        <a href="{{route('web:index')}}" class="menu" target="_blank">
                            <div class="menu__icon"><i data-lucide="activity"></i></div>
                            <div class="menu__title"> @lang('Web') </div>
                        </a>
                    </li>

                </ul>
            </li>
            @if(Module::find('User')->isEnabled())
                @can('view users')
                    <li>
                        <a href="{{route('admin:user.index')}}" @class(['menu','menu--active' => Route::is('admin:user.*')])>
                            <div class="menu__icon"><i data-lucide="key"></i></div>
                            <div class="menu__title"> @lang('Users') </div>
                        </a>
                    </li>
                @endcan
            @endif
            @if(Module::find('Role')->isEnabled())
                @can('view roles')
                    <li>
                        <a href="{{route('admin:role.index')}}" @class(['menu','menu--active' => Route::is('admin:role.*')])>
                            <div class="menu__icon"><i data-lucide="key"></i></div>
                            <div class="menu__title"> @lang('Roles & Permissions') </div>
                        </a>
                    </li>
                @endcan
            @endif
            <li>
                <a href="javascript:;" @class(['menu','menu--active' => Route::is('admin:tools') || Route::is('admin:admin:settings.*')])>
                    <div class="menu__icon">
                        <i data-lucide="filter"></i>
                    </div>
                    <div class="menu__title">
                        @lang('Settings')
                        <i data-lucide="chevron-down" @class(['menu__sub-icon','transform rotate-180' => Route::is('admin:tools') || Route::is('admin:admin:settings.*')])></i>
                    </div>
                </a>
                <ul @class(['menu__sub-open' => Route::is('admin:tools') || Route::is('admin:admin:settings.*')])>
                    @canany(['clear cache', 'optimize', 'optimize clear', 'storage link', 'migrate', 'json language'])
                        <li>
                            <a href="{{route('admin:tools.index')}}" @class(['menu','menu--active' => Route::is('admin:tools')])>
                                <div class="menu__icon"><i data-lucide="command"></i></div>
                                <div class="menu__title"> @lang('Tools') </div>
                            </a>
                        </li>
                    @endcanany
                    @can('edit settings')
                        <li>
                            <a href="{{route('admin:settings.edit',1)}}" @class(['menu','menu--active' => Route::is('admin:settings.*')])>
                                <div class="menu__icon"><i data-lucide="settings"></i></div>
                                <div class="menu__title"> @lang('System') </div>
                            </a>
                        </li>
                    @endcan
                </ul>
            </li>
        </ul>
    </div>
</div>
