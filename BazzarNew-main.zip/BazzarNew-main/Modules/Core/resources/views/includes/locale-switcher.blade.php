<div class="intro-x mr-4 sm:mr-6 flex flex-col items-center sm:flex-row">
    <form action="{{route('admin:tools.change-locale')}}" method="post">
        @csrf
        <select onchange="this.closest('form').submit()" name="locale" class="form-select form-select-sm" aria-label=".form-select-sm example">
            <option @selected(app()->getLocale() == 'az') value="az">Az</option>
            <option @selected(app()->getLocale() == 'ru') value="ru">Ru</option>
            <option @selected(app()->getLocale() == 'en') value="en">En</option>
        </select>
    </form>
</div>
