@if(config('updater.enable_jquery'))
    <script src="{{asset('/javadle/updater/jquery-3.7.0.min.js')}}"></script>
@endif
@if(config('updater.enable_sweet_alert2'))
    <script src="{{asset('/javadle/updater/sweetalert2.js')}}"></script>
@endif
<script>
    axios.get('updater.check')
        .then(response => {
            if (response.data !== '') {
                // Display the update information
                Swal.fire({
                    title: '@lang('updater.UPDATE_AVAILABLE')',
                    html:
                        `<h1>@lang('updater.Version'): ${response.data.version}</h1>` +
                        `<p>@lang('updater.Changes'): <br> ${response.data.description}</p>`,
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonText: '@lang('updater.UPDATE_NOW')',
                    cancelButtonText: `@lang('updater.Cancel')`,
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Make the second request for the update
                        axios.get('updater.update').then(response => {
                            if (response.data !== '') {
                                // Display update success
                                Swal.fire({
                                    title: '@lang('updater.UPDATED')',
                                    html: `<p>${response.data}</p>`,
                                    icon: 'info',
                                });
                            }
                        }).catch(error => {
                            // Handle update error
                            Swal.fire({
                                title: '@lang('updater.error_try_again')',
                                html: `<p>${error.response.data}</p>`,
                                icon: 'info',
                                showCancelButton: false,
                            });
                        });
                    }
                });
            }
        }).catch(error => {
        // Handle the initial request error
        console.error(error);
    });
</script>