<div class="col-span-12 min-h-[45vh] bg-white rounded-lg shadow dark:bg-gray-900 my-4 flex items-center justify-center">
    <h1 class="text-center">@lang('No information found')</h1>
</div>
