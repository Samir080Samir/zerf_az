@props([
    'id' => $id ?? Str::slug($name),
    'label' => '',
    'name' => '',
    'type' => 'text',
    'placeholder' => '',
    'inputClass' => null,
    'divClass' => null,
    'disabled' => false,
    'required' => false,
    'readOnly' => false,
    'selected' => '',
    'options' => [],
])

<div @class(['col-span-12 mb-3',$divClass => $divClass ])>
    @if ($label)
        <label class="form-label w-full flex flex-col sm:flex-row" for="{{ $id }}">
            {{ $label }} @if($required) <span class="ml-1 text-danger">*</span> @endif
            @if($placeholder)
                <span class="sm:ml-auto mt-1 sm:mt-0 text-xs text-slate-500">{{$placeholder}}</span>
            @endif
        </label>
    @endif
    <select {{$attributes}}
            @class(['form-select', $inputClass => $inputClass])
            id="{{ $id }}"
            type="{{ $type }}"
            name="{{ $name }}"
            placeholder="{{ $placeholder }}"
            @if ($disabled) disabled @endif
            @if ($required) required @endif
            @if ($readOnly) readonly @endif>
        <option selected readonly value="">@lang('Choose a value')</option>
        @foreach($options as $key => $value)
            <option @selected(($key ?? $value) == $selected) value="{{$key ?? $value}}">{{$value ?? $key}}</option>
        @endforeach
    </select>
</div>
