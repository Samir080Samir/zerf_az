<div class="intro-x relative mr-3 sm:mr-6">
    <div class="search hidden sm:block">
        <input wire:model.live="search" type="text" class="search__input form-control border-transparent" placeholder="@lang('Search')...">
        <i data-lucide="search" class="search__icon dark:text-slate-500"></i>
    </div>
    <div wire:ignore.self class="search-result">
        <div wire:ignore.self class="search-result__content">
            @if($users->isNotEmpty())
                <div class="search-result__content__title">@lang('Users')</div>
                @foreach($users as $user)
                    <div class="mb-5">
                        <a href="{{route('admin:user.edit',$user->getAttribute('id'))}}" class="flex items-center mt-2">
                            <div class="w-8 h-8 image-fit">
                                <img class="rounded-full" src="{{$user->avatar()}}" alt="{{$user->fullName()}}">
                            </div>
                            <div class="ml-3">{{$user->fullName()}}</div>
                            <div class="ml-auto w-48 truncate text-slate-500 text-xs text-right">{{$user->getAttribute('email')}}</div>
                        </a>
                    </div>
                @endforeach
            @endif
            @if($ads->isNotEmpty())
                <div class="search-result__content__title">@lang('Ads')</div>
                @foreach($ads as $ad)
                    <a href="{{route('admin:ad.edit',$ad->getAttribute('id'))}}" class="flex items-center mt-2">
                        <div class="w-8 h-8 image-fit">
                            <img class="rounded-full" src="{{$ad->firstImage()}}" alt="{{$ad->title()}}">
                        </div>
                        <div class="ml-3">{{$ad->title()}}</div>
                        @if($ad->category)
                            <div class="ml-auto w-48 truncate text-slate-500 text-xs text-right">{{$ad->category->title()}}</div>
                        @endif
                    </a>
                @endforeach
            @endif
            @if($users->isEmpty() && $ads->isEmpty())
                <div class="search-result__content__title">@lang('No search results found')</div>
            @endif
        </div>
    </div>
</div>
