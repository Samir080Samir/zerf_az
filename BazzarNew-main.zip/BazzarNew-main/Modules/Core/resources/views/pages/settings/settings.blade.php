@extends('core::layouts.master')
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Settings') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="preview">
                        <!-- BEGIN: Validation Form -->
                        <form class="grid grid-cols-12 gap-2 form-update" action="{{route('admin:settings.update',$setting->getAttribute('id'))}}" method="post">
                            @method('PUT')
                            @csrf
                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <x-core::form.input
                                    :label="__('App name')"
                                    name="app_name"
                                    :value="old('app_name',$setting->getAttribute('app_name'))"
                                    div-class="lg:col-span-3"
                                    :placeholder="__('Application title')"
                                    required/>

                                <x-core::form.input
                                    :label="__('App description')"
                                    name="app_description"
                                    :value="old('app_description',$setting->getAttribute('app_description'))"
                                    div-class="lg:col-span-3"
                                    :placeholder="__('Application description')"/>

                                <x-core::form.input
                                    :label="__('App keywords')"
                                    name="app_keywords"
                                    :value="old('app_keywords',$setting->getAttribute('app_keywords'))"
                                    div-class="lg:col-span-3"
                                    :placeholder="__('Application keywords')"/>

                                <x-core::form.select
                                    :label="__('Template')"
                                    name="template"
                                    :selected="old('template',$setting->getAttribute('template'))"
                                    :options="$templateFolders"
                                    div-class="lg:col-span-3"
                                    :placeholder="__('Current application template')"
                                    required/>

                                <x-core::form.input
                                    :label="__('App address')"
                                    name="app_address"
                                    :value="old('app_address',$setting->getAttribute('app_address'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Application address')"/>

                                <x-core::form.input
                                    :label="__('App phone')"
                                    name="app_phone"
                                    input-class="phone"
                                    :value="old('app_phone',$setting->getAttribute('app_phone'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Application phone')"/>

                                <x-core::form.input
                                    :label="__('App email')"
                                    name="app_email"
                                    :value="old('app_email',$setting->getAttribute('app_email'))"
                                    div-class="lg:col-span-3"
                                    :placeholder="__('Application email')"/>

                                <x-core::form.input
                                    :label="__('Currency')"
                                    name="app_currency"
                                    :value="old('app_currency',$setting->getAttribute('app_currency'))"
                                    div-class="lg:col-span-1"/>
                            </div>

                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="col-span-12">
                                    <h2 class="text-center text-lg font-medium mr-auto"> @lang('Social networks') </h2>
                                </div>
                                <x-core::form.input
                                    :label="__('Facebook')"
                                    name="facebook"
                                    :value="old('app_email',$setting->getAttribute('facebook'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Facebook address')"/>

                                <x-core::form.input
                                    :label="__('Instagram')"
                                    name="instagram"
                                    :value="old('instagram',$setting->getAttribute('instagram'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Instagram address')"/>

                                <x-core::form.input
                                    :label="__('Whatsapp')"
                                    name="whatsapp"
                                    :value="old('whatsapp',$setting->getAttribute('whatsapp'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Whatsapp address')"/>

                                <x-core::form.input
                                    :label="__('Telegram')"
                                    name="telegram"
                                    :value="old('telegram',$setting->getAttribute('telegram'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Telegram address')"/>

                                <x-core::form.input
                                    :label="__('Youtube')"
                                    name="youtube"
                                    :value="old('youtube',$setting->getAttribute('youtube'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Youtube address')"/>

                                <x-core::form.input
                                    :label="__('Linkedin')"
                                    name="linkedin"
                                    :value="old('linkedin',$setting->getAttribute('linkedin'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('Linkedin address')"/>
                            </div>

                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="col-span-12">
                                    <h2 class="text-center text-lg font-medium mr-auto"> @lang('Image upload configuration') </h2>
                                </div>
                                <x-core::form.select
                                    :label="__('Driver')"
                                    name="image_driver"
                                    :selected="old('image_driver',$setting->getAttribute('image_driver'))"
                                    :options="['gd' => 'GD','imagick' => 'Imagick']"
                                    div-class="lg:col-span-6"
                                    :placeholder="__('Image uploader driver')"
                                    required/>

                                <x-core::form.select
                                    :label="__('Compression')"
                                    name="compression_percent"
                                    :selected="old('compression_percent',$setting->getAttribute('compression_percent'))"
                                    :options="$compressionPercents"
                                    div-class="lg:col-span-6"
                                    :placeholder="__('Image compression percent')"
                                    required/>
                            </div>

                            {{-- <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="col-span-12">
                                    <h2 class="text-center text-lg font-medium mr-auto"> @lang('Pusher') </h2>
                                </div>

                                <x-core::form.input
                                        :label="__('App ID')"
                                        name="pusher_id"
                                        :value="old('pusher_id',$setting->getAttribute('pusher_id'))"
                                        div-class="lg:col-span-3"
                                        :placeholder="__('Pusher app id')"/>

                                <x-core::form.input
                                        :label="__('App Key')"
                                        name="pusher_key"
                                        :value="old('pusher_key',$setting->getAttribute('pusher_key'))"
                                        div-class="lg:col-span-3"
                                        :placeholder="__('Pusher app key')"/>

                                <x-core::form.input
                                        :label="__('App Secret')"
                                        name="pusher_secret"
                                        :value="old('pusher_secret',$setting->getAttribute('pusher_secret'))"
                                        div-class="lg:col-span-3"
                                        :placeholder="__('Pusher secret key')"/>

                                <x-core::form.input
                                        :label="__('App Cluster')"
                                        name="pusher_cluster"
                                        :value="old('pusher_cluster',$setting->getAttribute('pusher_cluster'))"
                                        div-class="lg:col-span-3"
                                        placeholder="https://pusher.com/docs/clusters"/>
                            </div> --}}

                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="col-span-12">
                                    <h2 class="text-center text-lg font-medium mr-auto"> @lang('Otp Service') </h2>
                                </div>
                                <x-core::form.input
                                    :label="__('Otp Login')"
                                    name="otp_login"
                                    :value="old('otp_login',$setting->getAttribute('otp_login'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('LSim Login')"/>

                                <x-core::form.input
                                    :label="__('Otp Password')"
                                    name="otp_password"
                                    :value="old('otp_password',$setting->getAttribute('otp_password'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('LSim Password')"/>

                                <x-core::form.input
                                    :label="__('Otp Sender')"
                                    name="otp_sender"
                                    :value="old('otp_sender',$setting->getAttribute('otp_sender'))"
                                    div-class="lg:col-span-4"
                                    :placeholder="__('LSim Sender Name')"/>
                            </div>


                            <div class="grid grid-cols-12 gap-2 col-span-12 border-2 border-dashed shadow-sm border-slate-200/60 dark:border-darkmode-400 mb-3 p-4">
                                <div class="col-span-12">
                                    <h2 class="text-center text-lg font-medium mr-auto"> @lang('Firebase notifications') </h2>
                                </div>
                                <x-core::form.input
                                    :label="__('Authorization')"
                                    name="firebase_authorization"
                                    :value="old('firebase_authorization',$setting->getAttribute('firebase_authorization'))"
                                    :placeholder="__('Firebase authorization token')"/>
                            </div>

                            <div class="col-span-12 mb-3">
                                <div class="form-switch mt-2">
                                    <label class="form-check-label ml-0" for="offline">@lang('Offline')</label>
                                    <input id="offline" @checked(old('offline',$setting->getAttribute('offline'))) class="show-code form-check-input mr-0 ml-3" name="offline" type="checkbox">
                                </div>
                            </div>

                            <div class="col-span-12">
                                <button class="btn btn-primary mr-1 mb-2">
                                    @lang('Update')
                                    <span class="loader-icon"></span>
                                </button>
                            </div>

                        </form>
                        <!-- END: Validation Form -->
                    </div>
                </div>
            </div>
            <!-- END: Form Validation -->
        </div>
    </div>
@endsection
