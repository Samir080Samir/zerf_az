@extends('core::layouts.master')
@section('title',__('Tools'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('Tools') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="p-5">
                    <div class="tab-content">
                        <div id="latest-tasks-new" class="tab-pane active" role="tabpanel" aria-labelledby="latest-tasks-new-tab">
                            @if(Module::has('Role') && auth()->user()->hasPermissionTo('clear cache'))
                                <div class="flex items-center bg-red-600 dark:bg-gray-900 rounded-lg p-2 mb-3">
                                    <div class="pl-4">
                                        <h2 class="font-bold text-light">@lang('Clear cache')</h2>
                                        <div class="text-light">@lang('Flush the application cache')</div>
                                    </div>
                                    <div class="form-check form-switch ml-auto">
                                        <form class="form-update" action="{{route('admin:tools.clear-cache')}}" method="post">
                                            @csrf
                                            <button class="btn btn-dark w-24">
                                                @lang('Run')
                                                <span class="loader-icon"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endif
                            @if(Module::has('Role') && auth()->user()->hasPermissionTo('optimize'))
                                <div class="flex items-center bg-red-600 dark:bg-gray-900 rounded-lg p-2 mb-3">
                                    <div class="pl-4">
                                        <h2 class="font-bold text-light">@lang('Optimize')</h2>
                                        <div class="text-light">@lang('Cache the framework bootstrap files')</div>
                                    </div>
                                    <div class="form-check form-switch ml-auto">
                                        <form class="form-update" action="{{route('admin:tools.optimize')}}" method="post">
                                            @csrf
                                            <button class="btn btn-dark w-24">
                                                @lang('Run')
                                                <span class="loader-icon"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endif
                            @if(Module::has('Role') && auth()->user()->hasPermissionTo('optimize clear'))
                                <div class="flex items-center bg-red-600 dark:bg-gray-900 rounded-lg p-2 mb-3">
                                    <div class="pl-4">
                                        <h2 class="font-bold text-light">@lang('Optimize clear')</h2>
                                        <div class="text-light">@lang('Remove the cached bootstrap files')</div>
                                    </div>
                                    <div class="form-check form-switch ml-auto">
                                        <form class="form-update" action="{{route('admin:tools.optimize-clear')}}" method="post">
                                            @csrf
                                            <button class="btn btn-dark w-24">
                                                @lang('Run')
                                                <span class="loader-icon"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endif
                            @if(Module::has('Role') && auth()->user()->hasPermissionTo('storage link'))
                                <div class="flex items-center bg-red-600 dark:bg-gray-900 rounded-lg p-2 mb-3">
                                    <div class="pl-4">
                                        <h2 class="font-bold text-light">@lang('Storage link')</h2>
                                        <div class="text-light">@lang('Create the symbolic links configured for the application')</div>
                                    </div>
                                    <div class="form-check form-switch ml-auto">
                                        <form class="form-update" action="{{route('admin:tools.storage-link')}}" method="post">
                                            @csrf
                                            <button class="btn btn-dark w-24">
                                                @lang('Run')
                                                <span class="loader-icon"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endif
                            @if(Module::has('Role') && auth()->user()->hasPermissionTo('migrate'))
                                <div class="flex items-center bg-red-600 dark:bg-gray-900 rounded-lg p-2 mb-3">
                                    <div class="pl-4">
                                        <h2 class="font-bold text-light">@lang('Migrate')</h2>
                                        <div class="text-light">@lang('Run the database migrations')</div>
                                    </div>
                                    <div class="form-check form-switch ml-auto">
                                        <form class="form-update" action="{{route('admin:tools.migrate')}}" method="post">
                                            @csrf
                                            <button class="btn btn-dark w-24">
                                                @lang('Run')
                                                <span class="loader-icon"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endif
                            @if(Module::has('Role') && auth()->user()->hasPermissionTo('generate sitemap'))
                                <div class="flex items-center bg-red-600 dark:bg-gray-900 rounded-lg p-2 mb-3">
                                    <div class="pl-4">
                                        <h2 class="font-bold text-light">@lang('Generate sitemap')</h2>
                                        <div class="text-light">@lang('Run the sitemap generation')</div>
                                    </div>
                                    <div class="form-check form-switch ml-auto">
                                        <form class="form-update" action="{{route('admin:tools.generate-sitemap')}}" method="post">
                                            @csrf
                                            <button class="btn btn-dark w-24">
                                                @lang('Run')
                                                <span class="loader-icon"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
