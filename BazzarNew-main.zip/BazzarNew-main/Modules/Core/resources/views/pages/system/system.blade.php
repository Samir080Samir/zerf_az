@extends('core::layouts.master')
@section('title',__('System information'))
@section('content')
    <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
        <h2 class="text-lg font-medium mr-auto"> @lang('System information') </h2>
        <div class="w-full sm:w-auto flex mt-4 sm:mt-0">
            <a href="{{route('admin:index')}}" class="btn btn-dark shadow-md mr-2">@lang('Back')</a>
            <form class="form-store" action="{{route('admin:tools.clear-cache')}}" method="post">
                @csrf
                <button class="btn btn-primary shadow-md mr-2">@lang('Clear cache') <span class="loader-icon"></span></button>
            </form>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12">
            <!-- BEGIN: Form Validation -->
            <div class="intro-y box">
                <div class="flex flex-col">
                    <div class="-m-1.5 overflow-x-auto">
                        <div class="p-1.5 min-w-full inline-block align-middle">
                            <div class="border rounded-lg overflow-hidden dark:border-gray-700">
                                <table class="table table-dark table-responsive table-bordered rounded-2">
                                    <tbody>
                                    <tr>
                                        <td>    @lang('Files size')</td>
                                        <td>{{SystemInfoHelper::formatSizeUnits(SystemInfoHelper::getDirectorySize('public'))}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Max upload size')</td>
                                        <td>{{SystemInfoHelper::maxUploadSize()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Free space')</td>
                                        <td>{{SystemInfoHelper::discFreeSpaceSize()}}</td>
                                    </tr>

                                    <!-- Переменованные блоки данных -->

                                    <tr>
                                        <td>@lang('Laravel version')</td>
                                        <td>{{SystemInfoHelper::laravelVersion()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Operation system')</td>
                                        <td>{{SystemInfoHelper::operationSystem()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Php version')</td>
                                        <td>{{SystemInfoHelper::phpVersion()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Mysql version')</td>
                                        <td>{{SystemInfoHelper::getMySQLVersion()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Database size')</td>
                                        <td>{{SystemInfoHelper::getMySQLDatabaseSize()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Cache size')</td>
                                        <td>{{SystemInfoHelper::getCacheSize()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Image driver')</td>
                                        <td>{{SystemInfoHelper::imageDriverVersion()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Available memory')</td>
                                        <td>{{SystemInfoHelper::getAvailableMemory()}}</td>
                                    </tr>
                                    <tr>
                                        <td>@lang('Disabled functions')</td>
                                        <td style="word-break: break-all;">{{SystemInfoHelper::disabledFunctions()}}</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
