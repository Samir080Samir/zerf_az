<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">

    <title>@lang('Offline')</title>

    <meta name="description" content="Biznesiniz üçün Ticarət sistemi.">
    <meta name="author" content="Projects of Azerbaijan">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="{{CoreHelper::settings()->getAttribute('app_description')}}">
    <meta name="keywords" content="NPA SYSTEMS">
    <meta name="author" content="Projects of Azerbaijan">

    <link href="{{ Vite::asset('resources/images/logo.svg') }}" rel="shortcut icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" id="css-main" href="{{asset('/npa/development.css')}}">
</head>
<body>
<section class="container-fluid">
    <div class="row">
        <img class="layout-background-earth position-absolute d-none d-md-block" src="{{asset('/npa/globe.png')}}" alt="Npa">
        <img class="layout-background position-absolute d-none d-md-block" src="{{asset('/npa/leaf-white.png')}}" alt="Npa">
        <div class="col-12">
            <div class="d-flex align-items-center justify-content-center text-center">
                <div class="sp-globe"></div>
                <h2 class="frame-1 h1">Hall hazırda texniki işlər aparılır</h2>
                <h2 class="frame-2 h1">Zəhmət olmasa bir az sonra yenə cəhd edin</h2>
                <h2 class="frame-3 h1">Müvəqqəti narahatlığa görə üzr istəyirik</h2>
                <h2 class="frame-4 h1">Hörmətlə Projects of Azerbaijan.</h2>
                <h2 class="frame-5 h1">
                    <span>Qabaqcıl həllər </span>
                    <span>sizin,digərlərindən </span>
                    <span>daha üstün olma şansınızdır.</span>
                </h2>
            </div>
        </div>
    </div>
</section>

@role('developer')
<div class="p-4">
    <form id="logout" action="{{route('logout')}}" method="post">
        @csrf
    </form>
    <div class="btn-group w-100" role="group" aria-label="Basic example">
        <a type="button" class="btn btn-dark" href="{{route('admin-index')}}">Admin panel</a>
        <a type="button" class="btn btn-dark" href="{{route('web-index')}}">Web</a>
        <button oncancel="document.getElementById('logout').submit()" type="button" class="btn btn-danger">Çıxış</button>
    </div>
</div>
@endrole
</body>
</html>
