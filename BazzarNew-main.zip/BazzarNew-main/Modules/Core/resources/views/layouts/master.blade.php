<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="theme-0">
<!-- BEGIN: Head -->
<head>
    <meta charset="utf-8">
    <link href="{{ Vite::asset('resources/images/logo.svg') }}" rel="shortcut icon">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="{{CoreHelper::settings()->getAttribute('app_description')}}">
    <meta name="keywords" content="NPA SYSTEMS">
    <meta name="author" content="Projects of Azerbaijan">
    <title>{{CoreHelper::settings()->getAttribute('app_name')}}
        » @yield('title',CoreHelper::settings()->getAttribute('app_name'))</title>

    <!--BEGIN: CSS Assets-->
    @vite('resources/css/app.css')
    <!--END: CSS Assets-->
    <script>
        // Проверяем состояние темы в localStorage при загрузке страницы
        const currentTheme = localStorage.getItem("theme");

        // Если значение существует, устанавливаем тему
        if (currentTheme) {
            if (currentTheme === 'dark') {
                document.documentElement.classList.add(currentTheme);
                const darkModeCheckbox = document.getElementById("dark-mode");
                if (darkModeCheckbox) {
                    darkModeCheckbox.checked = true;
                }
            } else if (currentTheme === 'light') {
                document.documentElement.classList.add(currentTheme);
                const darkModeCheckbox = document.getElementById("dark-mode");
                if (darkModeCheckbox) {
                    darkModeCheckbox.checked = false;
                }
            }
        } else {
            document.documentElement.classList.add('light');
        }
    </script>
    @stack('css')
</head>
<!-- END: Head -->
<body class="main">
<!-- BEGIN: Mobile Menu -->
@include('core::includes.mobile-navigation')
<!-- END: Mobile Menu -->
<!-- BEGIN: Top Bar -->
@include('core::includes.top-bar')
<!-- END: Top Bar -->
<!-- BEGIN: Top Menu -->
@include('core::includes.top-navigation')
<!-- END: Top Menu -->
<div class="wrapper wrapper--top-nav">
    <div class="wrapper-box">
        <!-- BEGIN: Content -->
        <div class="content">
            @yield('content')
            @include('core::includes.footer')
        </div>
        <!-- END: Content -->
    </div>
</div>
<!-- BEGIN: Dark Mode Switcher-->
<div
    class="dark-mode-switcher cursor-pointer shadow-md fixed bottom-0 right-0 box border rounded-full w-40 h-12 flex items-center justify-center z-50 mb-10 mr-10">
    <div class="form-switch">
        <label class="form-check-label ml-0" for="dark-mode">@lang('Dark mode')</label>
        <input id="dark-mode" class="show-code form-check-input mr-0 ml-3" type="checkbox">
    </div>
</div>
<!-- END: Dark Mode Switcher-->

<!-- BEGIN: JS Assets-->
@vite('resources/js/app.js')
@stack('js')
<!-- END: JS Assets-->
</body>
</html>
