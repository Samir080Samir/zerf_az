@extends('core::layouts.master')
@section('title',__('Dashboard'))
@section('content')
    <div class="grid grid-cols-12 gap-6">

        <!-- Левый блок -->
        <div class="col-span-12 2xl:col-span-9">
            <div class="grid grid-cols-12 gap-6">

                @if(CoreHelper::settings()->getAttribute('offline'))
                    <!-- Уведомление о выключенном сайте -->
                    <div class="col-span-12 mt-6 intro-y">
                        <div class="alert alert-dismissible show box bg-danger text-white flex items-center" role="alert">
                            <div>
                                @lang('The application is offline, to change go to')
                                <a href="{{route('admin:settings.edit',1)}}" class="underline ml-1" target="blank">@lang('Settings')</a>.
                            </div>
                        </div>
                    </div>
                @endif

                <!-- Общий отчет -->

                <!-- Активные продукты и категории -->
{{--                <div class="col-span-12">--}}
{{--                    <div class="report-box-3 mt-6 col-span-12">--}}
{{--                        <div class="grid grid-cols-12 gap-6 relative intro-y">--}}
{{--                            <div class="col-span-12 lg:col-span-4 px-0 lg:px-6 xl:px-0 2xl:px-6">--}}
{{--                                <div class="flex items-center flex-wrap lg:flex-nowrap gap-3">--}}
{{--                                    <div class="py-1 px-2.5 rounded-full text-xs bg-slate-300/50 dark:bg-darkmode-400 text-slate-600 dark:text-slate-300 cursor-pointer truncate">@lang('Products')</div>--}}
{{--                                </div>--}}
{{--                                <div class="px-10 sm:px-0">--}}
{{--                                    <div class="h-[110px]">--}}
{{--                                        <canvas class="products-chart -ml-1 mt-8 -mb-7"></canvas>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                            <div class="col-span-12 lg:col-span-4 px-0 lg:px-6 xl:px-0 2xl:px-6">--}}
{{--                                <div class="flex items-center flex-wrap lg:flex-nowrap gap-3">--}}
{{--                                    <div class="sm:w-full text-lg font-medium truncate text-center">@lang('Content')</div>--}}
{{--                                </div>--}}
{{--                                <div class="flex items-center justify-center mt-10">--}}
{{--                                    <div class="text-right">--}}
{{--                                        <div class="text-3xl font-medium">{{$productsCount}}</div>--}}
{{--                                        <div class="truncate mt-1 text-slate-500">@lang('Active products')</div>--}}
{{--                                    </div>--}}
{{--                                    <div class="w-px h-16 border border-r border-dashed border-slate-300 dark:border-darkmode-400 mx-4 xl:mx-6"></div>--}}
{{--                                    <div>--}}
{{--                                        <div class="text-3xl font-medium">{{$categoriesCount}}</div>--}}
{{--                                        <div class="truncate mt-1 text-slate-500">@lang('Active categories')</div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                            <div class="col-span-12 lg:col-span-4 px-0 lg:px-6 xl:px-0 2xl:px-6">--}}
{{--                                <div class="flex items-center flex-wrap lg:flex-nowrap gap-3">--}}
{{--                                    <div class="py-1 px-2.5 rounded-full text-xs bg-slate-300/50 dark:bg-darkmode-400 text-slate-600 dark:text-slate-300 cursor-pointer truncate">@lang('Categories')</div>--}}
{{--                                </div>--}}
{{--                                <div class="px-10 sm:px-0">--}}
{{--                                    <div class="h-[110px]">--}}
{{--                                        <canvas class="categories-chart -ml-1 mt-8 -mb-7"></canvas>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}

                <!-- Блоки -->
{{--                <div class="col-span-12">--}}
{{--                    <div class="grid grid-cols-12 gap-6">--}}

{{--                        <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">--}}
{{--                            <div class="report-box zoom-in">--}}
{{--                                <div class="box p-5">--}}
{{--                                    <div class="flex">--}}
{{--                                        <i data-lucide="shopping-cart" class="report-box__icon text-primary"></i>--}}
{{--                                    </div>--}}
{{--                                    <div class="text-3xl font-medium leading-8 mt-6">{{$paymentsTotal}}</div>--}}
{{--                                    <div class="text-base text-slate-500 mt-1">@lang('Payments')</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}

{{--                        <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">--}}
{{--                            <div class="report-box zoom-in">--}}
{{--                                <div class="box p-5">--}}
{{--                                    <div class="flex">--}}
{{--                                        <i data-lucide="wallet" class="report-box__icon text-primary"></i>--}}
{{--                                    </div>--}}
{{--                                    <div class="text-3xl font-medium leading-8 mt-6">{{$ordersTotal}}</div>--}}
{{--                                    <div class="text-base text-slate-500 mt-1">@lang('Orders')</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}

{{--                        <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">--}}
{{--                            <div class="report-box zoom-in">--}}
{{--                                <div class="box p-5">--}}
{{--                                    <div class="flex">--}}
{{--                                        <i data-lucide="user-check" class="report-box__icon text-primary"></i>--}}
{{--                                    </div>--}}
{{--                                    <div class="text-3xl font-medium leading-8 mt-6">{{$subscribersCount}}</div>--}}
{{--                                    <div class="text-base text-slate-500 mt-1">@lang('Subscribers')</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}

{{--                        <div class="col-span-12 sm:col-span-6 xl:col-span-2 intro-y">--}}
{{--                            <div class="report-box zoom-in">--}}
{{--                                <div class="box p-5">--}}
{{--                                    <div class="flex">--}}
{{--                                        <i data-lucide="user" class="report-box__icon text-primary"></i>--}}
{{--                                    </div>--}}
{{--                                    <div class="text-3xl font-medium leading-8 mt-6">{{number_format($ages['totalUsers'])}}</div>--}}
{{--                                    <div class="text-base text-slate-500 mt-1">@lang('Users')</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}

{{--                        <div class="col-span-12 lg:col-span-12 xl:col-span-4 intro-y">--}}
{{--                            <div class="report-box zoom-in">--}}
{{--                                <div class="box p-5">--}}
{{--                                    <div class="flex">--}}
{{--                                        <i data-lucide="mail" class="report-box__icon text-primary"></i>--}}
{{--                                    </div>--}}
{{--                                    <div class="text-3xl font-medium leading-8 mt-6">{{$otpBalance}}</div>--}}
{{--                                    <div class="text-base text-slate-500 mt-1">@lang('Remaining number of sms')</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}

{{--                    </div>--}}
{{--                </div>--}}

                <!-- Баннер добавление продукта -->
                <div class="col-span-12 lg:col-span-6 mt-6">
                    <div class="box p-8 relative overflow-hidden bg-primary intro-y min-h-[250px]">
                        <div class="leading-[2.15rem] w-full sm:w-72 text-white text-xl -mt-3">@lang('Add a new product')</div>
                        <div class="w-full sm:w-72 leading-relaxed text-white/70 dark:text-slate-500 mt-3">@lang('You can add a product by clicking the button below.')</div>
                        <a href="#" target="_blank" class="btn w-100 bg-white dark:bg-darkmode-800 dark:text-white mt-6 sm:mt-10">@lang('Add product')</a>
                        <img class="hidden sm:block absolute top-0 right-0 w-2/5 -mt-3 mr-2" alt="{{CoreHelper::settings()->getAttribute('app_name')}}" src="{{Vite::asset('resources/images/woman-illustration.svg')}}">
                    </div>
                </div>

                <!-- Баннер рассылки -->
                <div class="col-span-12 lg:col-span-6 mt-6">
                    <div class="box p-8 relative overflow-hidden intro-y min-h-[250px]">
                        <div class="leading-[2.15rem] w-full sm:w-52 text-primary dark:text-white text-xl -mt-3">@lang('Share with your friends!') </div>
                        <div class="w-full leading-relaxed text-slate-500 mt-2">@lang('You can copy the site link by clicking the button below.')</div>
                        <div class="w-60 relative mt-6 cursor-pointer tooltip" title="@lang('Copy site link')">
                            <input type="text" class="form-control" value="{{route('web:index')}}" readonly>
                            <i data-lucide="copy" data-url="{{route('web:index')}}" class="copy-code absolute right-0 top-0 bottom-0 my-auto mr-4 w-4 h-4"></i>
                        </div>
                        <img class="hidden sm:block absolute top-0 right-0 w-1/2 mt-1 -mr-12" alt="{{CoreHelper::settings()->getAttribute('app_name')}}" src="{{Vite::asset('resources/images/phone-illustration.svg')}}">
                    </div>
                </div>

                <!-- Отчет топ продукты недели -->
{{--                <div class="col-span-12 xl:col-span-6">--}}
{{--                    <div class="intro-y flex items-center h-10">--}}
{{--                        <h2 class="text-lg font-medium truncate mr-5">--}}
{{--                            @lang('Weekly Top Products')--}}
{{--                        </h2>--}}
{{--                    </div>--}}
{{--                    <div class="mt-5">--}}
{{--                        @foreach($topWeeklyProducts as $product)--}}
{{--                            <div class="intro-y">--}}
{{--                                <div class="box px-4 py-4 mb-3 flex items-center zoom-in">--}}
{{--                                    <div class="w-10 h-10 flex-none image-fit rounded-md overflow-hidden">--}}
{{--                                        <img src="{{$product->image()}}" alt="{{$product->title()}}">--}}
{{--                                    </div>--}}
{{--                                    <div class="ml-4 mr-auto">--}}
{{--                                        <div class="font-medium">{{$product->title()}}</div>--}}
{{--                                        <div class="text-slate-500 text-xs mt-0.5">{{Carbon\Carbon::parse($product->getAttribute('created_at'))->format('d F Y')}}</div>--}}
{{--                                    </div>--}}
{{--                                    <div class="py-1 px-2 rounded-full text-xs bg-success text-white cursor-pointer font-medium">@lang('Stock') {{$product->stockCount()}}</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        @endforeach--}}
{{--                        <a href="{{route('admin:products.index')}}" class="intro-y w-full block text-center rounded-md py-4 border border-dotted border-slate-400 dark:border-darkmode-300 text-slate-500">--}}
{{--                            @lang('View More')--}}
{{--                        </a>--}}
{{--                    </div>--}}
{{--                </div>--}}

                <!-- Отчет последние пользователи -->
{{--                <div class="col-span-12 xl:col-span-6">--}}
{{--                    <div class="intro-y flex items-center h-10">--}}
{{--                        <h2 class="text-lg font-medium truncate mr-5">--}}
{{--                            @lang('New Users')--}}
{{--                        </h2>--}}
{{--                    </div>--}}
{{--                    <div class="mt-5">--}}
{{--                        @foreach($latestUsers as $latestUser)--}}
{{--                            <div class="intro-y">--}}
{{--                                <div class="box px-4 py-4 mb-3 flex items-center zoom-in">--}}
{{--                                    <div class="w-10 h-10 flex-none image-fit rounded-md overflow-hidden">--}}
{{--                                        <img src="{{$latestUser->avatar()}}" alt="{{$latestUser->fullName()}}">--}}
{{--                                    </div>--}}
{{--                                    <div class="ml-4 mr-auto">--}}
{{--                                        <div class="font-medium">{{$latestUser->fullName()}}</div>--}}
{{--                                        <div class="text-slate-500 text-xs mt-0.5">{{Carbon\Carbon::parse($latestUser->getAttribute('created_at'))->format('d F Y')}}</div>--}}
{{--                                    </div>--}}
{{--                                    <div class="py-1 px-2 rounded-full text-xs bg-success text-white cursor-pointer font-medium">@lang('Payments') {{$latestUser->payments->count()}}</div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        @endforeach--}}
{{--                        <a href="{{route('admin:user.index')}}" class="intro-y w-full block text-center rounded-md py-4 border border-dotted border-slate-400 dark:border-darkmode-300 text-slate-500">--}}
{{--                            @lang('View More')--}}
{{--                        </a>--}}
{{--                    </div>--}}
{{--                </div>--}}
            </div>
        </div>

        <!-- Правый блок -->
        <div class="col-span-12 2xl:col-span-3">
            <div class="2xl:border-l -mb-10 pb-10">
                <div class="2xl:pl-6 grid grid-cols-12 gap-x-6 2xl:gap-x-0 gap-y-6">

                    <!-- Отчет гостей -->
                    <div class="col-span-12 md:col-span-6 xl:col-span-4 2xl:col-span-12 mt-3">
                        <div class="intro-y flex items-center h-10">
                            <h2 class="text-lg font-medium truncate mr-5">
                                @lang('Visitors')
                            </h2>
                        </div>
                        <div class="report-box-2 intro-y mt-5">
                            <div class="box p-5">
                                <div class="flex items-center">
                                    @lang('Realtime active users')
                                </div>
                                <div id="real-users-count" class="text-2xl font-medium mt-2">0</div>
                                <div class="border-b border-slate-200 flex pb-2 mt-4">
                                    <div class="text-slate-500 text-xs">@lang('Page views per second')</div>
                                </div>
                                <div class="mt-2 border-b broder-slate-200">
                                    <div class="-mb-1.5 -ml-2.5">
                                        <div class="h-[79px]">
                                            <canvas id="real-time-users"></canvas>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-slate-500 text-xs border-b border-slate-200 flex mb-2 pb-2 mt-4">
                                    <div>@lang('Top Active Pages')</div>
                                    <div class="ml-auto">@lang('Active Users')</div>
                                </div>
                                <div id="users-url"></div>
                            </div>
                        </div>
                    </div>

{{--                    @if($blogs->isNotEmpty())--}}
{{--                        <!-- Отчет последние блоги -->--}}
{{--                        <div class="col-span-12 md:col-span-6 xl:col-span-12 mt-3 2xl:mt-8">--}}
{{--                            <div class="intro-x flex items-center h-10">--}}
{{--                                <h2 class="text-lg font-medium truncate mr-auto">--}}
{{--                                    @lang('Latest blogs')--}}
{{--                                </h2>--}}
{{--                                <a href="{{route('admin:blogs.index')}}" class="ml-auto text-primary truncate">@lang('Show More')</a>--}}
{{--                            </div>--}}
{{--                            <div class="mt-5 intro-x">--}}
{{--                                <div class="zoom-in">--}}
{{--                                    @foreach($blogs as $blog)--}}
{{--                                        <div class="intro-x">--}}
{{--                                            <div class="box px-5 py-3 mb-3 flex items-center zoom-in">--}}
{{--                                                <div class="w-10 h-10 flex-none image-fit rounded-full overflow-hidden">--}}
{{--                                                    <img alt="{{CoreHelper::settings()->getAttribute('app_name')}}" src="{{$blog->image()}}">--}}
{{--                                                </div>--}}
{{--                                                <div class="ml-4 mr-auto">--}}
{{--                                                    <div class="font-medium">{{Str::limit($blog->title(),50)}}</div>--}}
{{--                                                    <div class="text-slate-500 text-xs mt-0.5">{{$blog->getAttribute('created_at')->diffForHumans()}}</div>--}}
{{--                                                </div>--}}
{{--                                                <div class="text-danger"><a href="{{route('admin:blogs.edit',$blog->getAttribute('id'))}}" class="btn btn-secondary py-1 px-2">@lang('Edit')</a></div>--}}
{{--                                            </div>--}}
{{--                                        </div>--}}
{{--                                    @endforeach--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    @endif--}}

                    <!-- Отчет пользователей по возрасту -->
{{--                    <div class="col-span-12 md:col-span-6 xl:col-span-12 mt-3 2xl:mt-8">--}}
{{--                        <div class="intro-y flex items-center h-10">--}}
{{--                            <h2 class="text-lg font-medium truncate mr-5">--}}
{{--                                @lang('Users By Age')--}}
{{--                            </h2>--}}
{{--                        </div>--}}
{{--                        <div class="report-box-2 intro-y mt-5">--}}
{{--                            <div class="box p-5">--}}
{{--                                <div class="relative">--}}
{{--                                    <div class="h-[208px]">--}}
{{--                                        <canvas class="mt-3" id="report-donut-chart"></canvas>--}}
{{--                                    </div>--}}
{{--                                    <div class="flex flex-col justify-center items-center absolute w-full h-full top-0 left-0">--}}
{{--                                        <div class="text-2xl font-medium">{{number_format($ages['totalUsers'])}}</div>--}}
{{--                                        <div class="text-slate-500 mt-0.5">@lang('Users')</div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                                <div class="w-52 sm:w-auto mx-auto mt-5 mb-2">--}}
{{--                                    @foreach($ages['ages'] as $key => $age)--}}
{{--                                        <div class="flex items-center mt-4">--}}
{{--                                            <div class="w-3 h-3 bg-primary rounded-full mr-3"></div>--}}
{{--                                            <div class="truncate">--}}
{{--                                                @if($loop->last)--}}
{{--                                                    @lang('Undefined')--}}
{{--                                                @else--}}
{{--                                                    {{$key}} @lang('Years old')--}}
{{--                                                @endif--}}
{{--                                            </div>--}}
{{--                                            <span class="font-medium ml-auto">{{$age['percent']}}%</span>--}}
{{--                                        </div>--}}
{{--                                    @endforeach--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}

                    <!-- Отчет последние заказы -->
{{--                    <div class="col-span-12 md:col-span-6 xl:col-span-4 2xl:col-span-12 mt-3">--}}
{{--                        <div class="intro-x flex items-center h-10">--}}
{{--                            <h2 class="text-lg font-medium truncate mr-5">--}}
{{--                                @lang('Latest orders')--}}
{{--                            </h2>--}}
{{--                        </div>--}}
{{--                        <div class="mt-5">--}}

{{--                            @foreach($orders as $order)--}}
{{--                                <div class="intro-x">--}}
{{--                                    <div class="box px-5 py-3 mb-3 flex items-center zoom-in">--}}
{{--                                        <div class="w-10 h-10 flex-none image-fit rounded-full overflow-hidden">--}}
{{--                                            <img alt="{{$order->getAttribute('name')}}" src="{{optional($order->payment)->user->avatar()}}">--}}
{{--                                        </div>--}}
{{--                                        <div class="ml-4 mr-auto">--}}
{{--                                            <div class="font-medium">{{optional($order->payment)->fullName()}}</div>--}}
{{--                                            <div class="text-slate-500 text-xs mt-0.5">{{$order->getAttribute('created_at')->format('d-m-Y')}}</div>--}}
{{--                                        </div>--}}
{{--                                        <div class="text-success">{{$order->getAttribute('grand_total')}} ₼</div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            @endforeach--}}

{{--                        </div>--}}
{{--                    </div>--}}
                </div>
            </div>
        </div>
    </div>
@endsection
@push('js')
{{--    <script>--}}
{{--        window.usersByAgeData = {--}}
{{--            labels: [--}}
{{--                "17 - 30 @lang('Years old')",--}}
{{--                "31 - 50 @lang('Years old')",--}}
{{--                ">= 50 @lang('Years old')",--}}
{{--                "@lang('Undefined')"--}}
{{--            ],--}}
{{--            data: [--}}
{{--                {{$ages['ages']['17-30']['count']}},--}}
{{--                {{$ages['ages']['31-50']['count']}},--}}
{{--                {{$ages['ages']['>=50']['count']}},--}}
{{--                {{$ages['ages']['Undefined']['count']}}--}}
{{--            ]--}}
{{--        }--}}
{{--        window.productsData = {--}}
{{--            labels: [--}}
{{--                '@lang('Jan')',--}}
{{--                '@lang('Feb')',--}}
{{--                '@lang('Mar')',--}}
{{--                '@lang('Apr')',--}}
{{--                '@lang('May')',--}}
{{--                '@lang('Jun')',--}}
{{--                '@lang('Jul')',--}}
{{--                '@lang('Aug')',--}}
{{--                '@lang('Sep')',--}}
{{--                '@lang('Oct')',--}}
{{--                '@lang('Nov')',--}}
{{--                '@lang('Dec')',--}}
{{--            ],--}}
{{--            allData: @js(array_values($productsTotalArray)),--}}
{{--            activeData: @js(array_values($activeProductsTotalArray))--}}
{{--        }--}}
{{--        window.categoriesData = {--}}
{{--            labels: [--}}
{{--                '@lang('Jan')',--}}
{{--                '@lang('Feb')',--}}
{{--                '@lang('Mar')',--}}
{{--                '@lang('Apr')',--}}
{{--                '@lang('May')',--}}
{{--                '@lang('Jun')',--}}
{{--                '@lang('Jul')',--}}
{{--                '@lang('Aug')',--}}
{{--                '@lang('Sep')',--}}
{{--                '@lang('Oct')',--}}
{{--                '@lang('Nov')',--}}
{{--                '@lang('Dec')',--}}
{{--            ],--}}
{{--            allData: @js(array_values($categoriesWithProductsArray)),--}}
{{--            activeData: @js(array_values($activeCategoriesWithProductsArray))--}}
{{--        }--}}
{{--    </script>--}}
@endpush
