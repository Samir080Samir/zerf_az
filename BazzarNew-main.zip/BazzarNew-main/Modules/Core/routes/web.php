<?php

use Illuminate\Support\Facades\Route;
use Modules\Core\app\Http\Controllers\CoreController;
use Modules\Core\app\Http\Controllers\SettingController;
use Modules\Core\app\Http\Controllers\ToolController;
use Modules\Core\app\Http\Middleware\PrefixLocale;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix(PrefixLocale::getLocale() . '/admin')->name('admin:')->middleware(['auth', 'permission:show dashboard'])->group(function () {
    //Home
    Route::get('/', [CoreController::class, 'index'])->name('index');

    //Tools
    Route::view('/tools', 'core::pages.tools.tools')->name('tools.index');
    Route::post('/tools/migrate', [ToolController::class, 'migrate'])->name('tools.migrate');
    Route::post('/tools/optimize', [ToolController::class, 'optimize'])->name('tools.optimize');
    Route::post('/tools/clear-cache', [ToolController::class, 'clearCache'])->name('tools.clear-cache');
    Route::post('/tools/storage-link', [ToolController::class, 'storageLink'])->name('tools.storage-link');
    Route::post('/tools/optimize-clear', [ToolController::class, 'optimizeClear'])->name('tools.optimize-clear');
    Route::post('/tools/generate-sitemap', [ToolController::class, 'generateSitemap'])->name('tools.generate-sitemap');
    Route::view('/tools/system-information', 'core::pages.system.system')->name('tools.system-information');
    Route::post('/tools/change-locale', [ToolController::class, 'changeLanguage'])->name('tools.change-locale');

    //Settings
    Route::resource('/settings', SettingController::class)->only('edit', 'update');
});
