<?php

namespace Modules\Core\database\factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Modules\Core\app\Models\Setting;

class SettingFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     */
    protected $model = Setting::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [
            'app_name' => config('app.name'),
            'app_description' => "Projects of Azerbaijan Idarəetmə sistemləri",
            'app_keywords' => "Crm,Erp,Korporativ saytlarin hazirlanmasi,Elektron ticatet",
            'template' => "default",

            'app_address' => "156a Əhməd Rəcəbli / 4 H.Əliyev Pr, Çinar Plaza / 21",
            'app_phone' => "077 711 22 44",
            'app_email' => "info@npa.az",

            'facebook' => null,
            'instagram' => null,
            'whatsapp' => null,
            'telegram' => null,
            'linkedin' => null,
            'youtube' => null,

            'image_driver' => 'gd',
            'compression_percent' => 50,

            'otp_login' => null,
            'otp_password' => null,
            'otp_sender' => null,

            'firebase_authorization' => null,

            'offline' => true,
        ];
    }
}

