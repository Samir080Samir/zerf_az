<?php

namespace Modules\Core\app\Http\Requests\Setting;

use Illuminate\Foundation\Http\FormRequest;

class SettingUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return void
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'offline' => $this->has('offline'),
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'app_name' => ['required', 'string', 'max:70'],
            'app_description' => ['nullable', 'string', 'max:300'],
            'app_keywords' => ['nullable', 'string', 'max:300'],

            'template' => ['required', 'string'],

            'app_address' => ['nullable', 'string'],
            'app_phone' => ['nullable', 'string'],
            'app_email' => ['nullable', 'string'],
            'app_currency' => ['nullable', 'string'],

            'facebook' => ['nullable', 'url'],
            'instagram' => ['nullable', 'url'],
            'whatsapp' => ['nullable', 'url'],
            'telegram' => ['nullable', 'url'],
            'youtube' => ['nullable', 'url'],
            'linkedin' => ['nullable', 'url'],

            'image_driver' => ['required', 'string'],
            'compression_percent' => ['required', 'integer'],

            'otp_login' => ['nullable', 'string'],
            'otp_password' => ['nullable', 'string'],
            'otp_sender' => ['nullable', 'string'],

            'firebase_authorization' => ['nullable', 'string'],

            'offline' => ['nullable', 'boolean']
        ];
    }
}
