<?php

namespace Modules\Core\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\File;
use Modules\Core\app\Helpers\CoreHelper;
use Modules\Core\app\Http\Middleware\PrefixLocale;
use Nwidart\Modules\Facades\Module;

class ToolController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:clear cache')->only('clearCache');
            $this->middleware('permission:optimize')->only('optimize');
            $this->middleware('permission:optimize clear')->only('optimizeClear');
            $this->middleware('permission:storage link')->only('storageLink');
            $this->middleware('permission:migrate')->only('migrate');
            $this->middleware('permission:generate sitemap')->only('generateSitemap');
        }
    }

    public function clearCache()
    {
        try {
            Artisan::call('cache:clear');
            return Artisan::output();
        } catch (Exception $e) {
            return "Error clearing cache: " . $e->getMessage();
        }
    }

    public function optimize()
    {
        try {
            Artisan::call('optimize');
            Artisan::output();
            return "Application optimized successfully.";
        } catch (Exception $e) {
            return __("Error optimizing application:") . ' ' . $e->getMessage();
        }
    }

    public function optimizeClear()
    {
        try {
            Artisan::call('optimize:clear');
            return Artisan::output();
        } catch (Exception $e) {
            return __("Error clearing optimization cache:") . ' ' . $e->getMessage();
        }
    }

    public function storageLink()
    {
        try {
            if (!File::exists(public_path('storage'))) {
                Artisan::call('storage:link');
                return Artisan::output();
            } else {
                return response()->json(__("Symbolic link already exists."), 500);
            }
        } catch (Exception $e) {
            return __("Error creating symbolic link:") . ' ' . $e->getMessage();
        }
    }

    public function migrate()
    {
        try {
            Artisan::call('migrate');
            return Artisan::output();
        } catch (Exception $e) {
            return __("Error migrating database:") . ' ' . $e->getMessage();
        }
    }

    public function generateSitemap()
    {
        try {
            Artisan::call('generate:sitemap');
            return Artisan::output();
        } catch (Exception $e) {
            return __("Error migrating database:") . ' ' . $e->getMessage();
        }
    }

    public function changeLanguage()
    {
        try {
            return CoreHelper::changeLocale();
        } catch (Exception $e) {
            return  $e->getMessage();
        }
    }
}
