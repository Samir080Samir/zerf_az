<?php

namespace Modules\Core\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Support\Facades\Cache;
use Modules\Core\app\Helpers\TemplateHelper;
use Modules\Core\app\Http\Requests\Setting\SettingUpdateRequest;
use Modules\Core\app\Models\Setting;

class SettingController extends Controller
{
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Setting $setting)
    {
        try {
            $templateFolders = TemplateHelper::getAllTemplates();
        } catch (Exception $exception) {
            return redirect()->route('admin:home')->withErrors([$exception->getMessage()]);
        }

        $compressionPercents = [
            20 => 20,
            25 => 25,
            30 => 30,
            35 => 35,
            40 => 40,
            45 => 45,
            50 => 50,
            55 => 55,
            60 => 60,
            65 => 65,
            70 => 70,
            75 => 75,
            80 => 80,
            85 => 85,
            90 => 90,
            95 => 95,
            100 => 100,
        ];

        return view('core::pages.settings.settings', compact([
            'setting',
            'templateFolders',
            'compressionPercents'
        ]));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(SettingUpdateRequest $request, Setting $setting)
    {
        try {
            $setting->update($request->validated());

            Cache::forget('settings');
            return response()->json(__('Data successfully updated!'));
        } catch (Exception $e) {
            return response()->json($e->getMessage());
        }
    }
}
