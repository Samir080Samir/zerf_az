<?php

namespace Modules\Core\app\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;

class PrefixLocale
{
    public static string $mainLanguage = 'en';

    public static array $languages = ['en', 'fr','az','ru'];

    public static function getLocale(): ?string
    {
        $uri = app('request')->path();

        $segmentsURI = explode('/', $uri);

        // Check for the language tag among the available languages
        if (!empty($segmentsURI[0]) && in_array($segmentsURI[0], self::$languages)) {
            if ($segmentsURI[0] != self::$mainLanguage) {
                return $segmentsURI[0];
            }
        }

        return null;
    }

    public function handle($request, Closure $next)
    {
        $locale = self::getLocale();

        if ($locale) App::setLocale($locale);
        else App::setLocale(self::$mainLanguage);

        return $next($request);
    }
}
