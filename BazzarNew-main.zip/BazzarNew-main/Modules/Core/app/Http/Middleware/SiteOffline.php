<?php

namespace Modules\Core\app\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\Core\app\Helpers\CoreHelper;

class SiteOffline
{
    /**
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next): mixed
    {
        if (CoreHelper::settings()->getAttribute('offline')) {
            $user = Auth::user();

            if ($user) {
                if ($user->hasAnyRole(['admin', 'developer'])) {
                    return $next($request);
                }
                if ($user->hasPermissionTo('show dashboard')) {
                    return $next($request);
                }
            }
            \Debugbar::disable();
            return response()->view('core::offline');
        }
        return $next($request);
    }
}
