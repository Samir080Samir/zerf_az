<?php

namespace Modules\Core\app\Traits\Files;

use CoreHelper;
use Exception;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Intervention\Image\ImageManager;

trait  ImageCompressor
{
    /**
     * @throws Exception
     */
    public function compressImage($image, $fileName): string
    {
        $directory = 'storage/images/';

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0777, true);
        }

        $imageFormat = strtolower(pathinfo($image->getClientOriginalName(), PATHINFO_EXTENSION));

        $driver = CoreHelper::settings()->getAttribute('image_driver');
        $compressionPercent = CoreHelper::settings()->getAttribute('image_compression_percent');

        if (!in_array($driver, ['gd', 'imagick'])) {
            throw new Exception("The driver \"$driver\" is not a valid Intervention driver.");
        }

        $imagePath = $this->generateImagePath($fileName, $imageFormat);

        if (in_array($imageFormat, ['webp', 'svg'])) {
            $image->move(public_path($directory), $imagePath);
        } else {
            $this->compressWebp($image, $directory, $imagePath, $driver, $compressionPercent);
        }

        return $imagePath;
    }

    private function generateImagePath($fileName, $imageFormat): string
    {
        return $fileName . '-' . Str::uuid() . ($imageFormat === 'webp' || $imageFormat === 'svg' ? '.' . $imageFormat : '.webp');
    }

    private function compressWebp($image, $directory, &$imagePath, $driver, $compressionPercent): void
    {
        $imageManager = new ImageManager(['driver' => $driver]);

        // Using getRealPath() to get the correct path of the image.
        $processedImage = $imageManager->make($image->getRealPath())->orientate()->save(
            public_path($directory . $imagePath),
            $compressionPercent ?? 80
        );

        // Add directory to the image path.
        $imagePath = $processedImage->basename;
    }
}
