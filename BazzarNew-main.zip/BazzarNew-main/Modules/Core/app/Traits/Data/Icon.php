<?php

namespace Modules\Core\app\Traits\Data;

trait Icon
{
    public function icon() :?string
    {
        return $this->getAttribute("icon");
    }
}
