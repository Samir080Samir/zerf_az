<?php

namespace Modules\Core\app\Traits\Data;

trait Title
{
    public function title() :?string
    {
//        return $this->getAttribute("title_" . str_replace('_', '-', app()->getLocale())) ?? $this->getAttribute('title_az');
        return $this->getAttribute("title");
    }
}
