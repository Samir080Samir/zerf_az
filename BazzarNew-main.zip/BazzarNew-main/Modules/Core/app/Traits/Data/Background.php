<?php

namespace Modules\Core\app\Traits\Data;

use Illuminate\Support\Facades\Vite;

trait Background
{
    public function background() :?string
    {
        return $this->getAttribute("background")
            ? asset('/storage/images/' . $this->getAttribute("background"))
            : Vite::asset('resources/images/placeholders/no-image.webp');
    }
}
