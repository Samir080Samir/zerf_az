<?php

namespace Modules\Core\app\Traits\Data;

trait Description
{
    public function description() :?string
    {
//        return $this->getAttribute("description_" . str_replace('_', '-', app()->getLocale())) ?? $this->getAttribute('description_az');
        return $this->getAttribute("description");
    }
}
