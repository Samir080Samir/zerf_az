<?php

namespace Modules\Core\app\Traits\Data;

use Illuminate\Support\Str;

trait SlugWithId
{
//    protected static function boot()
//    {
//        parent::boot();
//
//        static::saving(function ($model) {
//            $id = $model->id ?: (static::max('id') + 1);
//            $title = $model->getAttribute('title');
//
//            // Handle the case where the title is empty
//            if (empty($title)) {
//                // You may want to add a default title or handle this case based on your requirements
//                $title = 'default-title';
//            }
//
//            $model->slug = Str::slug($id . '-' . $title);
//        });
//    }

    public function slug() :?string
    {
        return $this->getAttribute('slug');
    }
}
