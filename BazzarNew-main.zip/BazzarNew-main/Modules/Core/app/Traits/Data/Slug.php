<?php

namespace Modules\Core\app\Traits\Data;

trait Slug
{
    public function slug() :?string
    {
        return $this->getAttribute('slug');
    }
}
