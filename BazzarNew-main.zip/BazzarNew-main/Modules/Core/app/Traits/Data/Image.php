<?php

namespace Modules\Core\app\Traits\Data;

use Illuminate\Support\Facades\Vite;

trait Image
{
    public function image() :?string
    {
        return $this->getAttribute("image")
            ? asset('/storage/images/' . $this->getAttribute("image"))
            : Vite::asset('resources/images/placeholders/no-image.webp');
    }
}
