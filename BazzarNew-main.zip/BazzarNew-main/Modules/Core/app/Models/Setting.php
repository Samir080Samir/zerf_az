<?php

namespace Modules\Core\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Core\Database\factories\SettingFactory;

class Setting extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'app_name',
        'app_description',
        'app_keywords',
        'template',

        'app_address',
        'app_phone',
        'app_email',
        'app_currency',

        'facebook',
        'instagram',
        'whatsapp',
        'telegram',
        'youtube',
        'linkedin',

        'image_driver',
        'compression_percent',

        'pusher_id',
        'pusher_key',
        'pusher_secret',
        'pusher_cluster',

        'otp_login',
        'otp_password',
        'otp_sender',

        'pay_riff_merchant',
        'pay_riff_secret',

        'firebase_authorization',

        'product_types',
        'experience',
        'happy_customers',

        'offline'
    ];

    protected static function newFactory(): SettingFactory
    {
        return SettingFactory::new();
    }
}
