<?php

namespace Modules\Core\app\Services;

use Exception;
use Illuminate\Support\Facades\Http;
use Modules\Core\app\Helpers\CoreHelper;

class TelegramSdk
{
    public mixed $settings;

    public function __construct()
    {
        $this->settings = CoreHelper::settings();

    }

    public function sendMessage($data): bool|string
    {
        try {
            $message = $data['message'];
            $buttonText = $data['button_text'] ?? null;
            $buttonUrl = $data['button_url'] ?? null;

            $params = [
                'chat_id' => $this->settings->getAttribute('telegram_chat_id'),
                'text' => $message
            ];

            if ($this->settings->getAttribute('telegram_reply_to_message_id')) {
                $params['reply_to_message_id'] = $this->settings->getAttribute('telegram_reply_to_message_id');
            }

            if ($buttonText && $buttonUrl) {
                $params['reply_markup'] = json_encode([
                    'inline_keyboard' => [[
                        [
                            'text' => $buttonText,
                            'url' => $buttonUrl,
                        ]
                    ]]
                ]);
            }

            $url = 'https://api.telegram.org/bot' . $this->settings->getAttribute('telegram_bot_token') . '/sendMessage';

            $response = Http::post($url, $params);
            if ($response->ok()) {
                return true;
            } else {
                if ($response->status() === 400 && isset($response['parameters']['migrate_to_chat_id'])) {
                    // Групповой чат был обновлен до супергруппы
                    $this->settings->setAttribute('telegram_chat_id', $response['parameters']['migrate_to_chat_id']);
                    $this->settings->save();
                    // Повторная попытка отправить сообщение с новым chat_id
                    $response = Http::post($url, $params);
                    if ($response->ok()) {
                        return true;
                    } else {
                        return $response->status();
                    }
                } else {
                    return $response->status();
                }
            }
        } catch (Exception $exception) {
            return $exception->getMessage();
        }
    }

}
