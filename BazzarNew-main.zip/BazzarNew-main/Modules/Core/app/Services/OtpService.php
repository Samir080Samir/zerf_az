<?php

namespace Modules\Core\app\Services;

use Illuminate\Support\Facades\Http;
use Exception;
use Modules\Core\app\Helpers\CoreHelper;

class OtpService
{
    public ?string $login;
    public ?string $password;
    public ?string $sender;

    protected string $apiUrl = 'https://apps.lsim.az/quicksms/v1/send';
    protected string $balanceUrl = 'https://apps.lsim.az/quicksms/v1/balance';
    protected string $checkNumberUrl = 'https://apps.lsim.az/lsimrest/mnp/api/get';

    public function __construct()
    {
        $settings = CoreHelper::settings();
        $this->login = $settings->getAttribute('otp_login');
        $this->password = $settings->getAttribute('otp_password');
        $this->sender = $settings->getAttribute('otp_sender');
    }

    protected function calculateKey($login, $password): string
    {
        $md5Password = md5($password);
        return md5($md5Password . $login);
    }

    public function sendSms($msisdn, $text, $unicode = false): string
    {
        if ($this->login && $this->password && $this->sender) {
            $md5Password = md5($this->password);
            $key = md5($md5Password . $this->login . $text . $msisdn . $this->sender);

            $params = [
                'login' => $this->login,
                'msisdn' => $msisdn,
                'text' => $text,
                'sender' => $this->sender,
                'key' => $key,
                'unicode' => $unicode,
            ];

            try {
                $response = Http::get($this->apiUrl, $params);

                if ($response->successful()) {
                    return $response->body();
                } else {
                    return $this->getResponseErrorMessage($response);
                }

            } catch (Exception $exception) {
                return $exception->getMessage();
            }
        } else {
            return __('Otp not configured!');
        }

    }

    public function checkBalance(): string|array
    {
        if ($this->login && $this->password && $this->sender) {
            $key = $this->calculateKey($this->login, $this->password);

            $params = [
                'login' => $this->login,
                'key' => $key,
            ];

            try {
                $response = Http::get($this->balanceUrl, $params);

                if ($response->successful()) {
                    // Преобразовываем JSON-ответ в массив
                    $data = $response->json();

                    // Возвращаем данные как ассоциативный массив
                    return $data;
                } else {
                    // В случае ошибки возвращаем ассоциативный массив с информацией об ошибке
                    return $this->getResponseErrorMessage($response);
                }

            } catch (Exception $exception) {
                // Возвращаем ассоциативный массив с информацией об ошибке в случае исключения
                return [
                    'error' => true,
                    'message' => $exception->getMessage(),
                ];
            }
        } else {
            return __('Otp not configured!');
        }
    }


    public function checkNumber($msisdn): string
    {
        if ($this->login && $this->password && $this->sender) {
            $params = [
                'username' => $this->login,
                'password' => $this->password,
                'msisdn' => $msisdn,
            ];

            try {
                $response = Http::get($this->checkNumberUrl, $params);

                if ($response->successful()) {
                    return $response->body();
                } else {
                    return $this->getResponseErrorMessage($response);
                }
            } catch (Exception $exception) {
                return $exception->getMessage();
            }
        } else {
            return __('Otp not configured!');
        }
    }

    protected function getResponseErrorMessage($response): string
    {
        if ($this->login && $this->password && $this->sender) {
            $statusCode = $response->status();
            $body = $response->body();

            return "HTTP {$statusCode} - {$body}";
        } else {
            return __('Otp not configured!');
        }
    }
}
