<?php

namespace Modules\Core\app\Helpers;

use Illuminate\Foundation\Application;
use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Facade;
use Illuminate\Support\Facades\File;
use Modules\Adversity\app\Models\Adversity;
use Modules\Category\app\Models\Category;
use Modules\Core\app\Http\Middleware\PrefixLocale;
use Modules\Core\app\Models\Setting;
use Nwidart\Modules\Facades\Module;

abstract class CoreHelper extends Facade
{
    public static final function settings()
    {
        return Cache::rememberForever('settings', function () {
            return Setting::first();
        });
    }

    public static final function mainCategories()
    {
        return Cache::rememberForever('categories', function () {
            return Category::mainCategories()->with('children', 'parent')->get();
        });
    }

    public static function getAdversitiesByType($type)
    {
        return Cache::rememberForever("$type-adversities", function () use ($type) {
            return Adversity::whereType($type)->orderBy('price')->get();
        });
    }

    public static function upAdversities()
    {
        return self::getAdversitiesByType('up');
    }

    public static function vipAdversities()
    {
        return self::getAdversitiesByType('vip');
    }

    public static function premiumAdversities()
    {
        return self::getAdversitiesByType('premium');
    }


    protected static function getFacadeAccessor(): string
    {
        return 'CoreHelper';
    }

    public static final function localeFlag(): string
    {
        $locale = (!empty(session('locale')) ? session('locale') : strtolower(app()->getLocale())) . '.svg';
        return asset('/assets/templates/default/images/svg/' . $locale);
    }

    public static final function telCleaner($tel): string
    {
        return str_replace(['+', '(', ')', ' '], '', $tel);
    }

    public static function formatLargeNumber($number): string
    {
        $suffix = '';
        if ($number >= 1000) {
            $divisors = array('K', 'M', 'B', 'T');
            $suffix = $divisors[$divisor = floor(log($number, 1000))];
            $number /= pow(1000, $divisor);
        }

        return $number . $suffix;
    }

    public static final function isExpired(string $date): bool
    {
        return Carbon::parse($date)->isPast();
    }

    public static final function isNew($model): bool
    {
        if ($model->created_at->diffInDays(Carbon::now()) > 7) {
            return false;
        } else {
            return true;
        }
    }

    public static final function formatPrice($price): string
    {
        return number_format($price, 2);
    }

    public static final function moduleGroups()
    {
        $allModules = Module::all();

        return collect($allModules)->reduce(function ($groupedModules, $module) {
            $groupName = config("{$module->getLowerName()}.group");

            // Проверка наличия обязательных параметров в конфигурации модуля
            $icon = config("{$module->getLowerName()}.icon");
            $groupIcon = config("{$module->getLowerName()}.group_icon");
            $routeIs = config("{$module->getLowerName()}.route_is");
            $route = config("{$module->getLowerName()}.route");
            $permission = config("{$module->getLowerName()}.permission");

            if ($groupName && $icon && $groupIcon && $route && $permission) {
                // Пересоздаем подмассив, если он еще не существует
                if (!isset($groupedModules[$groupName])) {
                    $groupedModules[$groupName] = [
                        'routes' => [],
                        'modules' => [],
                    ];
                }

                $groupedModules[$groupName]['name'] = $groupName;
                $groupedModules[$groupName]['icon'] = $groupIcon;

                // Преобразовываем строку в массив, используя запятые в качестве разделителя
                $routeIsArray = explode(' ', $routeIs);

                // Добавляем $routeIs в массив routes
                $groupedModules[$groupName]['routes'] = array_merge($groupedModules[$groupName]['routes'], $routeIsArray);

                $groupedModules[$groupName]['modules'][] = [
                    'name' => $module->getName(),
                    'icon' => $icon,
                    'group_icon' => $groupIcon,
                    'route' => $route,
                    'permission' => $permission,
                ];
            }

            return $groupedModules;
        }, []);
    }

    public static final function dateFormat($createdAt)
    {
        $currentDate = Carbon::now();

        $diffInDays = $createdAt->diffInDays($currentDate);

        if ($diffInDays == 0) {
            $formattedDate = trans('Today');
        } elseif ($diffInDays == 1) {
            $formattedDate = trans('Yesterday');
        } else {
            $formattedDate = $createdAt->format('d F Y');
        }

        return $formattedDate;
    }

    public static function changeLocale(): Application|Redirector|RedirectResponse|\Illuminate\Contracts\Foundation\Application
    {
        $lang = request()->input('locale');

        $referer = url()->previous(); // URL предыдущей страницы

        // разбиваем на массив по разделителю
        $segments = explode('/', parse_url($referer, PHP_URL_PATH));

        // Если URL (где нажали на переключение языка) содержал корректную метку языка
        if (in_array($segments[1], PrefixLocale::$languages)) {
            unset($segments[1]); // удаляем метку
        }

        // Добавляем метку языка в URL (если выбран не язык по умолчанию)
        if ($lang != PrefixLocale::$mainLanguage) {
            array_splice($segments, 1, 0, $lang);
        }

        // формируем полный URL
        $url = url(implode("/", $segments));

        // если были еще GET-параметры - добавляем их
        if (parse_url($referer, PHP_URL_QUERY)) {
            $url = $url . '?' . parse_url($referer, PHP_URL_QUERY);
        }
        //Перенаправляем назад на ту же страницу
        return redirect($url);
    }

    public static function createLangFile($langArray): string
    {
        $langFolderPath = resource_path('lang/templates');
        $langFilePath = $langFolderPath.'/root.json';

        // Проверяем наличие директории, и создаем её, если она не существует
        if (! File::isDirectory($langFolderPath)) {
            File::makeDirectory($langFolderPath, 0755, true, true);
        }

        $langData = [];

        // Заполняем массив значениями из предоставленного массива
        foreach ($langArray as $word) {
            $langData[$word] = '';
        }

        // Преобразуем массив в JSON
        $jsonContent = json_encode($langData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        // Записываем JSON в файл
        File::put($langFilePath, $jsonContent);

        return $langFilePath;
    }

    public static function findLangStringsInBlade($subFolderPath): array
    {
        // Путь к директории views в Laravel
        $viewsPath = resource_path('views');

        // Полный путь к указанной поддиректории внутри views
        $folderPath = $viewsPath.DIRECTORY_SEPARATOR.$subFolderPath;

        $langStrings = [];

        $files = File::allFiles($folderPath);

        foreach ($files as $file) {
            $content = file_get_contents($file);
            preg_match_all('/@lang\(\'(.*?)\'\)/', $content, $matches);

            if (! empty($matches[1])) {
                $langStrings = array_merge($langStrings, $matches[1]);
            }
        }

        // Убираем возможные дубликаты
        return array_unique($langStrings);
    }

    public static final function currencies()
    {
        return array(
            'AED' => 'United Arab Emirates dirham',
            'AFN' => 'Afghan afghani',
            'ALL' => 'Albanian lek',
            'AMD' => 'Armenian dram',
            'ANG' => 'Netherlands Antillean guilder',
            'AOA' => 'Angolan kwanza',
            'ARS' => 'Argentine peso',
            'AUD' => 'Australian dollar',
            'AWG' => 'Aruban florin',
            'AZN' => 'Azerbaijani manat',
            'BAM' => 'Bosnia and Herzegovina convertible mark',
            'BBD' => 'Barbadian dollar',
            'BDT' => 'Bangladeshi taka',
            'BGN' => 'Bulgarian lev',
            'BHD' => 'Bahraini dinar',
            'BIF' => 'Burundian franc',
            'BMD' => 'Bermudian dollar',
            'BND' => 'Brunei dollar',
            'BOB' => 'Bolivian boliviano',
            'BRL' => 'Brazilian real',
            'BSD' => 'Bahamian dollar',
            'BTC' => 'Bitcoin',
            'BTN' => 'Bhutanese ngultrum',
            'BWP' => 'Botswana pula',
            'BYR' => 'Belarusian ruble',
            'BZD' => 'Belize dollar',
            'CAD' => 'Canadian dollar',
            'CDF' => 'Congolese franc',
            'CHF' => 'Swiss franc',
            'CLP' => 'Chilean peso',
            'CNY' => 'Chinese yuan',
            'COP' => 'Colombian peso',
            'CRC' => 'Costa Rican col&oacute;n',
            'CUC' => 'Cuban convertible peso',
            'CUP' => 'Cuban peso',
            'CVE' => 'Cape Verdean escudo',
            'CZK' => 'Czech koruna',
            'DJF' => 'Djiboutian franc',
            'DKK' => 'Danish krone',
            'DOP' => 'Dominican peso',
            'DZD' => 'Algerian dinar',
            'EGP' => 'Egyptian pound',
            'ERN' => 'Eritrean nakfa',
            'ETB' => 'Ethiopian birr',
            'EUR' => 'Euro',
            'FJD' => 'Fijian dollar',
            'FKP' => 'Falkland Islands pound',
            'GBP' => 'Pound sterling',
            'GEL' => 'Georgian lari',
            'GGP' => 'Guernsey pound',
            'GHS' => 'Ghana cedi',
            'GIP' => 'Gibraltar pound',
            'GMD' => 'Gambian dalasi',
            'GNF' => 'Guinean franc',
            'GTQ' => 'Guatemalan quetzal',
            'GYD' => 'Guyanese dollar',
            'HKD' => 'Hong Kong dollar',
            'HNL' => 'Honduran lempira',
            'HRK' => 'Croatian kuna',
            'HTG' => 'Haitian gourde',
            'HUF' => 'Hungarian forint',
            'IDR' => 'Indonesian rupiah',
            'ILS' => 'Israeli new shekel',
            'IMP' => 'Manx pound',
            'INR' => 'Indian rupee',
            'IQD' => 'Iraqi dinar',
            'IRR' => 'Iranian rial',
            'ISK' => 'Icelandic kr&oacute;na',
            'JEP' => 'Jersey pound',
            'JMD' => 'Jamaican dollar',
            'JOD' => 'Jordanian dinar',
            'JPY' => 'Japanese yen',
            'KES' => 'Kenyan shilling',
            'KGS' => 'Kyrgyzstani som',
            'KHR' => 'Cambodian riel',
            'KMF' => 'Comorian franc',
            'KPW' => 'North Korean won',
            'KRW' => 'South Korean won',
            'KWD' => 'Kuwaiti dinar',
            'KYD' => 'Cayman Islands dollar',
            'KZT' => 'Kazakhstani tenge',
            'LAK' => 'Lao kip',
            'LBP' => 'Lebanese pound',
            'LKR' => 'Sri Lankan rupee',
            'LRD' => 'Liberian dollar',
            'LSL' => 'Lesotho loti',
            'LYD' => 'Libyan dinar',
            'MAD' => 'Moroccan dirham',
            'MDL' => 'Moldovan leu',
            'MGA' => 'Malagasy ariary',
            'MKD' => 'Macedonian denar',
            'MMK' => 'Burmese kyat',
            'MNT' => 'Mongolian t&ouml;gr&ouml;g',
            'MOP' => 'Macanese pataca',
            'MRO' => 'Mauritanian ouguiya',
            'MUR' => 'Mauritian rupee',
            'MVR' => 'Maldivian rufiyaa',
            'MWK' => 'Malawian kwacha',
            'MXN' => 'Mexican peso',
            'MYR' => 'Malaysian ringgit',
            'MZN' => 'Mozambican metical',
            'NAD' => 'Namibian dollar',
            'NGN' => 'Nigerian naira',
            'NIO' => 'Nicaraguan c&oacute;rdoba',
            'NOK' => 'Norwegian krone',
            'NPR' => 'Nepalese rupee',
            'NZD' => 'New Zealand dollar',
            'OMR' => 'Omani rial',
            'PAB' => 'Panamanian balboa',
            'PEN' => 'Peruvian nuevo sol',
            'PGK' => 'Papua New Guinean kina',
            'PHP' => 'Philippine peso',
            'PKR' => 'Pakistani rupee',
            'PLN' => 'Polish z&#x142;oty',
            'PRB' => 'Transnistrian ruble',
            'PYG' => 'Paraguayan guaran&iacute;',
            'QAR' => 'Qatari riyal',
            'RON' => 'Romanian leu',
            'RSD' => 'Serbian dinar',
            'RUB' => 'Russian ruble',
            'RWF' => 'Rwandan franc',
            'SAR' => 'Saudi riyal',
            'SBD' => 'Solomon Islands dollar',
            'SCR' => 'Seychellois rupee',
            'SDG' => 'Sudanese pound',
            'SEK' => 'Swedish krona',
            'SGD' => 'Singapore dollar',
            'SHP' => 'Saint Helena pound',
            'SLL' => 'Sierra Leonean leone',
            'SOS' => 'Somali shilling',
            'SRD' => 'Surinamese dollar',
            'SSP' => 'South Sudanese pound',
            'STD' => 'S&atilde;o Tom&eacute; and Pr&iacute;ncipe dobra',
            'SYP' => 'Syrian pound',
            'SZL' => 'Swazi lilangeni',
            'THB' => 'Thai baht',
            'TJS' => 'Tajikistani somoni',
            'TMT' => 'Turkmenistan manat',
            'TND' => 'Tunisian dinar',
            'TOP' => 'Tongan pa&#x2bb;anga',
            'TRY' => 'Turkish lira',
            'TTD' => 'Trinidad and Tobago dollar',
            'TWD' => 'New Taiwan dollar',
            'TZS' => 'Tanzanian shilling',
            'UAH' => 'Ukrainian hryvnia',
            'UGX' => 'Ugandan shilling',
            'USD' => 'United States dollar',
            'UYU' => 'Uruguayan peso',
            'UZS' => 'Uzbekistani som',
            'VEF' => 'Venezuelan bol&iacute;var',
            'VND' => 'Vietnamese &#x111;&#x1ed3;ng',
            'VUV' => 'Vanuatu vatu',
            'WST' => 'Samoan t&#x101;l&#x101;',
            'XAF' => 'Central African CFA franc',
            'XCD' => 'East Caribbean dollar',
            'XOF' => 'West African CFA franc',
            'XPF' => 'CFP franc',
            'YER' => 'Yemeni rial',
            'ZAR' => 'South African rand',
            'ZMW' => 'Zambian kwacha',
        );
    }
}
