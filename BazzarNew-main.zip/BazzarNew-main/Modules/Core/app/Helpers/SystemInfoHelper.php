<?php

namespace Modules\Core\app\Helpers;


use Illuminate\Contracts\Translation\Translator;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Facade;
use Illuminate\Support\Facades\Storage;

class SystemInfoHelper extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return 'SystemInfoHelper';
    }

    public static function getDirectorySize($directory): int
    {
        $size = 0;

        $files = Storage::allFiles($directory);

        foreach ($files as $file) {
            $size += Storage::size($file);
        }

        return $size;
    }

    public static function laravelVersion(): string
    {
        return app()->version();
    }

    public static function operationSystem(): string
    {
        return @php_uname("s") . " " . @php_uname("r");
    }

    public static function phpVersion(): bool|string
    {
        return phpversion();
    }

    public static function moduleRewrite()
    {
        if (function_exists('apache_get_modules')) {
            if (in_array('mod_rewrite', apache_get_modules())) {
                $modRewrite = trans('Enabled');
            } else {
                $modRewrite = trans('Disabled');
            }
        } else {
            $modRewrite = trans('Undefined');
        }
        return $modRewrite;
    }

    public static function disabledFunctions(): Application|bool|array|string|Translator|\Illuminate\Contracts\Foundation\Application|null
    {
        return (strlen(ini_get('disable_functions')) > 1) ? ini_get('disable_functions') : __('Undefined');
    }

    public static function maxUploadSize(): array|string
    {
        $maxUpload = str_replace(array('M', 'm',), '', @ini_get('upload_max_filesize'));
        return in_array($maxUpload, ['1g', '1G']) ? str_replace(array('g', 'G'), 'Gb', $maxUpload) : self::formatSizeUnits($maxUpload * 1024 * 1024);
    }

    public static function discFreeSpaceSize(): string
    {
        $dfs = @disk_free_space(".");
        return self::formatSizeUnits($dfs);
    }

    public static function formatSizeUnits($fileSize): array|string
    {

        if (!$fileSize or $fileSize < 1) return '0 B';

        $prefix = array("B", "Kb", "Mb", "Gb", "Tb");
        $exp = floor(log($fileSize, 1024)) | 0;

        $fileSize = round($fileSize / (pow(1024, $exp)), 2) . ' ' . $prefix[$exp];
        return str_replace(",", ".", $fileSize);
    }

    public static function getMySQLVersion()
    {
        return DB::select('select version()')[0]->{'version()'};
    }

    public static function imageDriverVersion()
    {
        $driver = CoreHelper::settings()->getAttribute('image_driver');
        if ($driver != "gd") {
            if (extension_loaded('imagick') && class_exists('Imagick')) {
                $driverVersion = 'imagick';
                if (!\Imagick::queryFormats('WEBP') and function_exists('imagewebp') and $driver != "imagick") {
                    $driverVersion = 'gd';
                }
            } elseif (function_exists('gd_info')) {
                $driverVersion = 'gd';
            }
        } elseif (function_exists('gd_info')) {
            $driverVersion = 'gd';
        }
        if ($driverVersion == 'imagick') {
            $v = \Imagick::getVersion();
            $driverVersion = $v['versionString'];
        } elseif ($driverVersion == 'gd') {
            $array = gd_info();
            $driverVersion = '';

            foreach ($array as $key => $val) {
                if ($val === true) {
                    $val = "Enabled";
                }
                if ($val === false) {
                    $val = "Disabled";
                }
                $driverVersion .= $key . ":&nbsp;{$val}, ";

            }
        } else {
            $driverVersion = __('Undefined image driver');
        }

        return html_entity_decode($driverVersion);
    }

    public static function getAvailableMemory(): Application|bool|array|string|Translator|\Illuminate\Contracts\Foundation\Application|null
    {
        return (ini_get('memory_limit') != '') ? ini_get('memory_limit') : __('Undefined');
    }

    public static function getCacheSize(): string
    {
        $fileSystem = new Filesystem();
        $cachePath = storage_path('framework/cache/data');

        $cacheSize = 0;

        if ($fileSystem->isDirectory($cachePath)) {
            $files = $fileSystem->allFiles($cachePath);

            foreach ($files as $file) {
                $cacheSize += $fileSystem->size($file);
            }
        }

        return self::formatSizeUnits($cacheSize);
    }

    public static function getMySQLDatabaseSize()
    {
        $databaseName = config('database.connections.mysql.database');

        $query = "SELECT table_schema AS database_name, SUM(data_length + index_length) AS size_in_bytes
              FROM information_schema.tables
              WHERE table_schema = :databaseName
              GROUP BY table_schema";

        $result = DB::select($query, ['databaseName' => $databaseName]);

        if (!empty($result)) {
            $sizeInBytes = $result[0]->size_in_bytes;
            return self::formatSizeUnits($sizeInBytes);
        }

        return __('Undefined');
    }
}
