<?php

namespace Modules\Core\app\Helpers;

use Illuminate\Support\Facades\Facade;
use Illuminate\Support\Facades\File;
use Str;

class TemplateHelper extends Facade
{
    protected static function getFacadeAccessor(): string
    {
        return 'TemplateHelper';
    }

    protected string $base_path = 'views/templates';

    /**
     * Получить все названия шаблонов
     */
    public static function getAllTemplates(): bool|array
    {
        $path = resource_path('views/templates');
        $templates = array_diff(scandir($path), array('.', '..'));

        if (empty($templates)) {
            return false;
        }

        return array_combine($templates, $templates);
    }


    /**
     * Получить файлы внутри определенного шаблона
     */
    public function getTemplateFiles($template): array
    {
        $path = resource_path($this->base_path . '/' . $template);
        $files = File::allFiles($path);

        return array_map(function ($file) use ($path) {
            return [
                'filename' => $file->getFilename(),
                'folder' => $file->getRelativePathname()
            ];
        }, $files);
    }

    public function getTemplateFilesTree($template): array
    {
        $absolutePath = resource_path($this->base_path . '/' . $template);
        return $this->getDirectoryFilesTree($absolutePath, '');
    }

    private function getDirectoryFilesTree($absolutePath, $relativePath): array
    {
        $files = File::files($absolutePath);
        $directories = File::directories($absolutePath);
        $tree = [];

        foreach ($directories as $dir) {
            $dirName = Str::afterLast($dir, '/');
            $tree[] = [
                'type' => 'folder',
                'name' => $dirName,
                'children' => $this->getDirectoryFilesTree($dir, $relativePath . '/' . $dirName),
            ];
        }

        foreach ($files as $file) {
            $fileName = $file->getFilename();
            $tree[] = [
                'type' => 'file',
                'name' => pathinfo($fileName, PATHINFO_FILENAME),
                'folder' => Str::replaceFirst($relativePath, '', $file->getRelativePathname()),
            ];
        }

        return $tree;
    }

    /**
     * Получить контент определенного файла шаблона
     */
    public function getTemplateFileContent($template, $fileName): ?string
    {
        $templatePath = resource_path('views/templates');

        // Проверяем, существует ли директория шаблона
        $path = $templatePath . '/' . $template;
        if (!File::isDirectory($path)) {
            return false;
        }

        // Ищем файл внутри шаблона
        $files = File::allFiles($path);

        foreach ($files as $file) {
            if ($file->getFilename() === $fileName) {
                // Возвращаем путь к найденному файлу
                return File::get($file->getPathname());
            }
        }
        return false;
    }


    /**
     * Сохранить контент определенного файла шаблона
     */
    public function saveTemplateFileContent($template, $fileName, $content): bool
    {

        $templatePath = resource_path('views/templates/' . $template);

        // Проверяем, существует ли директория шаблона
        if (!File::isDirectory($templatePath)) {
            return false;
        }

        // Ищем файл внутри шаблона
        $files = File::allFiles($templatePath);
        foreach ($files as $file) {
            if ($file->getFilename() === $fileName) {

                $filePath = $file->getPath() . '/' . $fileName;

                if (!File::isReadable($filePath)) {
                    return false;
                } else {
                    // Возвращаем путь к найденному файлу
                    File::put($filePath, $content);
                    return true;
                }
            }
        }
        return false;
    }
}
