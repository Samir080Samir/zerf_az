<?php

namespace Modules\Core\Livewire;

use App\Models\User;
use Livewire\Component;
use Modules\Ad\app\Models\Ad;

class Search extends Component
{
    public $search = '';

    public function render()
    {
        return view('core::livewire.search', [
            'users' => User::where('first_name', 'LIKE', '%' . $this->search . '%')
                ->orWhere('last_name', 'LIKE', '%' . $this->search . '%')
                ->orWhere('email', 'LIKE', '%' . $this->search . '%')->limit(5)->get(),
            'ads' => Ad::where('title', 'LIKE', '%' . $this->search . '%')
                ->withWherehas('category', function ($q) {
                    return $q->where('title', 'LIKE', '%' . $this->search . '%');
                })->limit(5)->get()
        ]);
    }
}
