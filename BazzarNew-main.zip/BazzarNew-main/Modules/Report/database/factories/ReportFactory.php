<?php

namespace Modules\Report\database\factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ReportFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     */
    protected $model = \Modules\Report\app\Models\Report::class;

    /**
     * Define the model's default state.
     */
    public function definition(): array
    {
        return [];
    }
}

