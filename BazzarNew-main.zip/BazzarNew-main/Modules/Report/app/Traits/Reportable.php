<?php

namespace Modules\Report\app\Traits;

use Modules\Report\app\Models\Report;

trait Reportable
{
    public function reports()
    {
        return $this->morphMany(Report::class, 'reportable');
    }

    public function sendReport($reason_id,$message): void
    {
        $this->reports()->create([
            'reason_id' => $reason_id,
            'user_id' => auth()->id(),
            'message' => $message,
        ]);
    }
}
