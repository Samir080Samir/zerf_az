<?php

namespace Modules\Report\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Report\app\Models\Report;
use Nwidart\Modules\Facades\Module;

class ReportController extends Controller
{
    public function __construct()
    {
        if (Module::find('Role')->isEnabled()) {
            $this->middleware('permission:view reports')->only('index');
            $this->middleware('permission:show report')->only('show');
            $this->middleware('permission:destroy report')->only('destroy');
        }
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('report::index');
    }

    /**
     * Show the specified resource.
     */
    public function show(Report $report)
    {
        return view('report::show');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
    }
}
