<?php

namespace Modules\Report\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Report\Database\factories\ReasonFactory;

class Reason extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'title'
    ];

    protected static function newFactory(): ReasonFactory
    {
        return ReasonFactory::new();
    }

    public function reports(): HasMany
    {
        return $this->hasMany(Report::class);
    }
}
