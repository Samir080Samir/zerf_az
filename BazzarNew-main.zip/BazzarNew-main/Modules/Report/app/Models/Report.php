<?php

namespace Modules\Report\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Modules\Report\Database\factories\ReportFactory;

class Report extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'user_id',
        'message'
    ];

    public function reportable(): MorphTo
    {
        return $this->morphTo();
    }

    public function reason(): BelongsTo
    {
        return $this->belongsTo(Reason::class);
    }

    protected static function newFactory(): ReportFactory
    {
        return ReportFactory::new();
    }
}
