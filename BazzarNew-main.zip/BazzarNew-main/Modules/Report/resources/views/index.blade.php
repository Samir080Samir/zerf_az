@extends('report::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('report.name') !!}</p>
@endsection
