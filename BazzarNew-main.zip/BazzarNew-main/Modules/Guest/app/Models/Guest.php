<?php

namespace Modules\Guest\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Guest\Database\factories\GuestFactory;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\Ad\app\Models\Ad;
class Guest extends Model
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'phone',
        'email'
    ];

    /**
     * @return string
     */
    public function avatar(): string
    {
        $size = 200;
        $default = 'mp';
        $rating = 'g';
        $url = 'https://www.gravatar.com/avatar/';
        $url .= md5(strtolower(trim($this->email)));
        $url .= "?s=$size&d=$default&r=$rating";

        foreach ([] as $key => $val) {
            $url .= ' ' . $key . '="' . $val . '"';
        }

        return $url;
    }

    /**
     * @return string
     */
    public function fullName(): string
    {
        return "{$this->getAttribute('first_name')} {$this->getAttribute('last_name')}";
    }

    public function hiddenPhone(): string
    {
        return Str::of($this->getAttribute('phone'))->mask('X', -2,'2');
    }

    public function ads(): HasMany
    {
        return $this->hasMany(Ad::class);
    }

    protected static function newFactory(): GuestFactory
    {
        //return GuestFactory::new();
    }
}
