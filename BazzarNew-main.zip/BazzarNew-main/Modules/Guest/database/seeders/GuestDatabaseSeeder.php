<?php

namespace Modules\Guest\database\seeders;

use Illuminate\Database\Seeder;

class GuestDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
