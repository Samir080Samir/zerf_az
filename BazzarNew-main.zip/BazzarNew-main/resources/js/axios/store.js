import $ from "jquery";
import Swal from "sweetalert2";

async function axiosStore(action, form, formData) {
    "use strict";

    const loader = $(form).find('.loader-icon');
    const button = loader.closest('button');
    console.log(button)
    loader.html('<i data-loading-icon="three-dots" data-color="white" class="ml-2 w-5 h-5 mx-auto"></i');
    button.prop('disabled', true);
    tailwind.svgLoader();

    try {
        const response = await axios.post(action, formData, {responseType: 'json'});
        handleSuccess(response);
    } catch (error) {
        handleError(error);
    } finally {
        loader.empty();
        button.prop('disabled', false);
    }

    function handleSuccess(response) {
        if (response.status === 200) {
            Swal.fire({
                icon: 'success',
                text: response.data,
            }).then((result) => {
                if (result.dismiss === Swal.DismissReason.backdrop) {
                    location.reload();
                } else if (result.isConfirmed) {
                    location.reload();
                }
            });
        } else {
            console.error("Unexpected Response Status:", response.status);
        }
    }

    function handleError(error) {
        if (error.response && error.response.status === 422) {
            let errorMessages = Object.values(error.response.data.errors);
            let errorMessageString = errorMessages.map(error => error.join('<br>')).join('<br>');

            Swal.fire({
                icon: 'error',
                html: errorMessageString
            });
        } else {
            const message = error.response ? error.response.data : error.message;

            Swal.fire({
                icon: 'error',
                text: message,
            });
        }
    }
}

let forms = document.querySelectorAll('.form-store');

forms.forEach(function (form) {
    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        await axiosStore(this.action, this, formData);
    });
});
