import $ from "jquery";
import Swal from "sweetalert2";

document.addEventListener('DOMContentLoaded', function () {
    const form = $('#excel-import-form');

    let loader;

    if (form.length) {
        loader = form.find('.loader-icon');

        form.get(0).addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            uploadExcel(this.action, form, formData);
        });
    }

    function setupFormListeners(form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            uploadExcel(this.action, form, formData);
        });
    }

    function uploadExcel(action, form, formData) {
        setLoaderHtml(loader);
        tailwind.svgLoader();
        axios.post(action, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            responseType: 'json'
        }).then((response) => handleSuccess(response, form)).catch((error) => handleError(error));
    }

    function importExcel(action, form, formData) {
        setLoaderHtml(loader);
        tailwind.svgLoader();
        axios.post(action, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            responseType: 'json'
        }).then((response) => handleImportSuccess(response, form)).catch((error) => handleError(error));
    }

    function setLoaderHtml(loader) {
        loader.html('<i data-loading-icon="three-dots" data-color="white" class="ml-2 w-5 h-5 mx-auto"></i>');
    }

    function handleSuccess(response, form) {
        try {
            if (response.status === 200) {
                Swal.fire({
                    html: response.data,
                    confirmButtonText:'Ok <span class="loader-icon"></span>',
                    allowOutsideClick: false,
                    showCancelButton:true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        const productsForm = document.getElementById('products-excel-import');
                        const productsLoader = $(productsForm).find('.loader-icon');
                        setupFormListeners(productsForm);
                        setLoaderHtml(productsLoader);
                        importExcel(productsForm.action, productsForm, new FormData(productsForm));
                    }
                });
            } else {
                console.error("Unexpected Response Status:", response.status);
            }
        } catch (error) {
            console.error("Error in handleSuccess:", error);
        } finally {
            loader.empty();
        }
    }

    function handleImportSuccess(response, form) {
        try {
            if (response.status === 200) {
                Swal.fire({
                    icon: 'success',
                    text: response.data,
                }).then((result) => {
                    if (result.dismiss === Swal.DismissReason.backdrop) {
                        location.reload();
                    } else if (result.isConfirmed) {
                        location.reload();
                    }
                })
            } else {
                console.error("Unexpected Response Status:", response.status);
            }
        } catch (error) {
            console.error("Error in handleSuccess:", error);
        } finally {
            loader.empty();
        }
    }

    function handleError(error) {
        try {
            if (error.response && error.response.status === 422) {
                const errorMessages = Object.values(error.response.data.errors);
                const errorMessageString = errorMessages.map(error => error.join('<br>')).join('<br>');
                Swal.fire({
                    icon: 'error',
                    html: errorMessageString
                });
            } else {
                const message = error.response ? error.response.data : error.message;
                Swal.fire({
                    icon: 'error',
                    text: message,
                });
            }
            loader.empty();
        } catch (error) {
            console.error("Error in handleError:", error);
            Swal.fire({
                icon: 'error',
                text: "Error in handleError: " + error,
            });
        } finally {
            loader.empty();
        }
    }
});
