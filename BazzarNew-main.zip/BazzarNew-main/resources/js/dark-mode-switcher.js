(function () {
    "use strict";

    // Функция для установки темы
    function setTheme(theme) {
        document.documentElement.classList.remove("light", "dark");
        document.documentElement.classList.add(theme);
        localStorage.setItem("theme", theme);
    }

    function setFooterLogo(theme) {
        let footerLog = document.querySelector('.footer-logo');
        if(theme === 'light'){
            footerLog.src = '/npa/npa-logo-dark.png'
        }else if(theme === 'dark'){
            footerLog.src = '/npa/npa-logo-white.png'
        }
    }


    // Проверяем значение из localStorage и устанавливаем тему
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) {
        setTheme(savedTheme);
        setFooterLogo(savedTheme);
        if (savedTheme === "dark") {
            document.getElementById("dark-mode").checked = true;
        }
    }

    // Обработчик изменения состояния чекбокса
    document.getElementById("dark-mode").addEventListener("change", () => {
        if (document.getElementById("dark-mode").checked) {
            setTheme("dark");
            setFooterLogo('dark');
        } else {
            setTheme("light");
            setFooterLogo('light');
        }
    });

})();
