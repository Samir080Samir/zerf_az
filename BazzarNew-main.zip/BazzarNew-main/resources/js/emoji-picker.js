import 'emoji-picker-element';

(function () {
    const emojiPickerButton = document.getElementById('emoji-picker-button');
    const emojiPicker = document.getElementById('emoji-picker');

    if (emojiPicker && emojiPickerButton) {
        emojiPicker.style.display = 'none';

        emojiPickerButton.addEventListener('click', () => {
            if (emojiPicker.style.display === 'none') {
                emojiPicker.style.display = 'block';
            } else {
                emojiPicker.style.display = 'none';
            }
        });

        // Handle emoji selection
        emojiPicker.addEventListener('emoji-click', (event) => {
            const emoji = event.detail.emoji;
            const input = document.querySelector('input[name="title"]');
            if (input) {
                input.value += emoji.unicode;
            }
        });
    }
})();
