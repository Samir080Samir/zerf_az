import colors from "./colors";
import Chart from 'chart.js/auto';

(function () {
    "use strict";

    if ($("#report-donut-chart").length) {

        const usersByAgeData = window.usersByAgeData || null;
        let ctx = $("#report-donut-chart")[0].getContext("2d");

        new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: usersByAgeData.labels,
                datasets: [
                    {
                        data: usersByAgeData.data,
                        backgroundColor: [
                            colors.pending(0.9),
                            colors.warning(0.9),
                            colors.primary(0.9),
                        ],
                        hoverBackgroundColor: [
                            colors.pending(0.9),
                            colors.warning(0.9),
                            colors.primary(0.9),
                        ],
                        borderWidth: 5,
                        borderColor: $("html").hasClass("dark")
                            ? colors.darkmode[700]()
                            : colors.white,
                    },
                ],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false,
                    },
                },
                cutout: "80%",
            },
        });
    }

    if ($(".products-chart").length) {
        const productsChartData = window.productsData || null;

        let ctx = $(".products-chart")[0].getContext("2d");
        new Chart(ctx, {
            type: "line",
            data: {
                labels: productsChartData.labels,
                datasets: [
                    {
                        label: "#",
                        data: productsChartData.activeData,
                        borderWidth: 2,
                        borderColor: colors.primary(0.8),
                        backgroundColor: "transparent",
                        pointBorderColor: "transparent",
                        tension: 0.4,
                    },
                    {
                        label: "#",
                        data: productsChartData.allData,
                        borderWidth: 2,
                        borderDash: [2, 2],
                        borderColor: $("html").hasClass("dark")
                            ? colors.darkmode["100"]()
                            : colors.slate["400"](),
                        backgroundColor: "transparent",
                        pointBorderColor: "transparent",
                        tension: 0.4,
                    }
                ],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false,
                    },
                },
                scales: {
                    x: {
                        ticks: {
                            display: false,
                        },
                        grid: {
                            display: false,
                            drawBorder: false,
                        },
                    },
                    y: {
                        ticks: {
                            display: false,
                        },
                        grid: {
                            display: false,
                            drawBorder: false,
                        },
                    },
                },
            },
        });
    }

    if ($(".categories-chart").length) {
        const categoriesChartData = window.categoriesData || null;

        let ctx = $(".categories-chart")[0].getContext("2d");
        new Chart(ctx, {
            type: "line",
            data: {
                labels: categoriesChartData.labels,
                datasets: [
                    {
                        label: "#",
                        data: categoriesChartData.activeData,
                        borderWidth: 2,
                        borderColor: colors.primary(0.8),
                        backgroundColor: "transparent",
                        pointBorderColor: "transparent",
                        tension: 0.4,
                    },
                    {
                        label: "#",
                        data: categoriesChartData.allData,
                        borderWidth: 2,
                        borderDash: [2, 2],
                        borderColor: $("html").hasClass("dark")
                            ? colors.darkmode["100"]()
                            : colors.slate["400"](),
                        backgroundColor: "transparent",
                        pointBorderColor: "transparent",
                        tension: 0.4,
                    },
                ],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false,
                    },
                },
                scales: {
                    x: {
                        ticks: {
                            display: false,
                        },
                        grid: {
                            display: false,
                            drawBorder: false,
                        },
                    },
                    y: {
                        ticks: {
                            display: false,
                        },
                        grid: {
                            display: false,
                            drawBorder: false,
                        },
                    },
                },
            },
        });
    }

})();
