import "./bootstrap";

import "@left4code/tw-starter/dist/js/svg-loader";
import "@left4code/tw-starter/dist/js/accordion";
import "@left4code/tw-starter/dist/js/dropdown";
import "@left4code/tw-starter/dist/js/modal";
import "@left4code/tw-starter/dist/js/alert";
import "@left4code/tw-starter/dist/js/tab";

// ----------------------------------------------------------------------

import "./tom-select";
import "./validation";
import "./lucide";
import "./chart";
import "./tippy";
import "./zoom";


// import "./notification";
// import "./tiny-slider";
// import "./datepicker";
// import "./highlight";
// import "./tabulator";
// import "./calendar";
// import "./dropzone";

// ----------------------------------------------------------------------

import "./online-visitors/socket-visitors";
import "./uploader/multiple-uploader";
import "./ckeditor/ckeditor-classic"

import "./axios/import-excel";
import "./dark-mode-switcher";
import "./side-menu-tooltip";
import "./phone-mask.blade";
import "./batches/batches";
import "./show-dropdown";
import "./axios/update";
import "./axios/store";
import "./emoji-picker";
import "./mobile-menu";
import "./show-modal";
import "./side-menu";
import "./copy-code";
import "./search";
import "./maps";
import "./chat";

// import "./show-slide-over";
// import "./show-code";
