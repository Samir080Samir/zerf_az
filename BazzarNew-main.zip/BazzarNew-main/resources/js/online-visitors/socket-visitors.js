import Chart from 'chart.js/auto';
import colors from "../colors";

(function () {
    "use strict";

    // Массив посетителей
    let visitors = [];
    let myBarChart;

    // Подключение к каналу "online" с использованием Laravel Echo
    Echo.join('online')
        .here(users => {
            // Обработка события при подключении пользователей
            visitors = users.map(user => ({ label: user.name, value: user.id, url: window.location.pathname }));
            updateChart();
        })
        .joining(user => {
            // Обработка события при подключении нового пользователя
            visitors.push({ label: user.name, value: user.id, url: window.location.pathname });
            updateChart();
        })
        .leaving(user => {
            // Обработка события при отключении пользователя
            visitors = visitors.filter(visitor => visitor.label !== user.name);
            updateChart();
        });

    // Инициализация графика, если элемент с id "real-time-users" существует
    if ($("#real-time-users").length) {
        let ctx = $("#real-time-users")[0].getContext("2d");
        myBarChart = new Chart(ctx, {
            type: "bar",
            data: {
                labels: visitors.map(visitor => visitor.label),
                datasets: [
                    {
                        label: visitors.map(visitor => visitor.label),
                        barThickness: 6,
                        data: visitors.map(visitor => visitor.value),
                        backgroundColor: [
                            colors.pending(0.9),
                            colors.warning(0.9),
                            colors.primary(0.9),
                        ],
                        hoverBackgroundColor: [
                            colors.pending(0.9),
                            colors.warning(0.9),
                            colors.primary(0.9),
                        ],
                        borderWidth: 5,
                        borderColor: $("html").hasClass("dark")
                            ? colors.darkmode[700]()
                            : colors.white,
                    },
                ],
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false,
                    },
                },
                scales: {
                    x: {
                        ticks: {
                            display: false,
                        },
                        grid: {
                            display: false,
                        },
                    },
                    y: {
                        ticks: {
                            display: false,
                        },
                        grid: {
                            display: false,
                            drawBorder: false,
                        },
                    },
                },
            },
        });
    }

    // Функция для получения цвета столбца на графике
    function getBarColor(data) {
        // Ваша логика определения цвета на основе данных пользователя
        return $("html").hasClass("dark") ? "#2E51BBA6" : colors.primary(0.65);
    }

    // Обновление данных графика и вставка информации о пользователях
    function updateChart() {
        $('#real-users-count').text(visitors.length);
        if (myBarChart) {
            myBarChart.data.labels = visitors.map(visitor => visitor.label);
            myBarChart.data.datasets[0].data = visitors.map(visitor => visitor.value);
            myBarChart.update();
            const urlUserPairs = getUrlUserPairs();
            // Вызов функции для вставки при загрузке страницы (или в нужный момент)
            insertTopUsersInfo();
        }
    }

    // Функция для извлечения пар URL-пользователь
    function getUrlUserPairs() {
        const urlCounts = {};

        visitors.forEach(visitor => {
            const { url, value } = visitor;
            if (urlCounts[url]) {
                urlCounts[url] += 1;
            } else {
                urlCounts[url] = 1;
            }
        });

        return Object.keys(urlCounts).map(url => ({ url, count: urlCounts[url] }));
    }

    // Вставка информации о топовых пользователях
    function insertTopUsersInfo() {
        // Получение массива пар URL-пользователь
        const urlUserPairs = getUrlUserPairs();

        // Сортировка массива по убыванию количества пользователей
        const sortedPairs = urlUserPairs.sort((a, b) => b.count - a.count);

        // Взятие топ 5 элементов
        const topFour = sortedPairs.slice(0, 5);

        // Получение контейнера
        const container = document.getElementById('users-url');

        // Очистка контейнера
        container.innerHTML = '';

        // Вставка новых элементов
        topFour.forEach(pair => {
            const div = document.createElement('div');
            div.classList.add('flex');

            const urlDiv = document.createElement('div');
            urlDiv.textContent = pair.url;

            const countDiv = document.createElement('div');
            countDiv.classList.add('ml-auto');
            countDiv.textContent = pair.count;

            div.appendChild(urlDiv);
            div.appendChild(countDiv);

            container.appendChild(div);
        });
    }
})();
