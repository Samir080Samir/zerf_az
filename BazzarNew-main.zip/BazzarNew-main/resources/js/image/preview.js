function imagePreview(event) {
    const inputElement = event.target;
    const outputElement = inputElement.closest('.axios-image').querySelector('img');

    outputElement.src = URL.createObjectURL(inputElement.files[0]);

    outputElement.onload = function() {
        URL.revokeObjectURL(outputElement.src); // free memory
    }
}
export default imagePreview;
