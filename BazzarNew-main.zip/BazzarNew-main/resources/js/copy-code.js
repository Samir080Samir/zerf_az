import Toastify from "toastify-js";
import $ from "jquery";

(function () {
    "use strict";
    // Copy original code
    document.querySelectorAll(".copy-code").forEach(function(element) {
        // Добавляем обработчик события для кнопки
        element.addEventListener('click', function() {
            // Получаем значение атрибута data-url
            const dataUrlValue = element.getAttribute('data-url');


            // Создаем временный элемент input, чтобы скопировать значение в буфер обмена
            const tempInput = document.createElement('input');
            tempInput.value = dataUrlValue;
            document.body.appendChild(tempInput);

            // Выделяем текст в input
            tempInput.select();

            // Копируем выделенный текст в буфер обмена
            document.execCommand('copy');

            // Удаляем временный элемент input
            document.body.removeChild(tempInput);

            const successContent = $("#copy-url-notification-content").clone().removeClass("hidden")[0];

            // Опционально, можно вывести сообщение об успешном копировании
            Toastify({
                node: successContent,
                duration: 1500,
                newWindow: true,
                close: true,
                gravity: "top",
                position: "right",
                stopOnFocus: true,
            }).showToast();
        });
    });

})();
