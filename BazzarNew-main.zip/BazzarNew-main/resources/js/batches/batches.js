(function () {
    "use strict";

    const branches = document.querySelectorAll('.branch');

    branches.forEach(branch => {
        branch.addEventListener('click', function () {
            const branchInput = document.getElementById('branch');
            if (branchInput.value === this.getAttribute('data-branch')) {
                // Если элемент уже выбран, снимаем выбор
                branchInput.value = '';
                this.querySelector('.zoom-in').classList.remove('bg-success/20');
            } else {
                // В противном случае устанавливаем выбор
                branchInput.value = this.getAttribute('data-branch');
                handleBranchClick(this);
            }
        });

        // Проверка на уже выбранный элемент
        if (branch.getAttribute('data-branch') === window.batchId || null) {
            document.getElementById('branch').value = branch.getAttribute('data-branch');
            handleBranchClick(branch);
        }
    });

    function handleBranchClick(element) {
        // Удалить bg-success у всех элементов с классом 'branch'
        branches.forEach(el => {
            el.querySelector('.zoom-in').classList.remove('bg-success/20');
        });

        // Добавить bg-success ближайшему предку с классом 'zoom-in'
        element.querySelector('.zoom-in').classList.add('bg-success/20');
    }
})();
