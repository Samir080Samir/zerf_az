import Inputmask from "inputmask/lib/inputmask";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";

$(".phone").each(function () {
    const el = this;
    Inputmask({
        mask: "0xx xxx xx xx",
        definitions: {
            'x': {
                validator: "[0-9]",
                cardinality: 1
            }
        }
    }).mask(el);
});
