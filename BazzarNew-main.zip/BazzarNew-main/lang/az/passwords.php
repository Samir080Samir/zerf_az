<?php

declare(strict_types=1);

return [
    'reset'     => 'Şifrə yeniləndi',
    'sent'      => 'Şifrə yeniləmə adresi sizə email olaraq göndərildi',
    'throttled' => 'Yenidən cəhd əvvəl gözləyin edin.',
    'token'     => 'Bu şifrə yeniləmə kodu yanlışdır',
    'user'      => 'Bu email\'ə uyğun istifadəçi tapılmadı',
];
