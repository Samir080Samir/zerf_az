<?php

declare(strict_types=1);

return [
    'next'     => 'Sonra &raquo;',
    'previous' => '&laquo; Əvvəl',
];
