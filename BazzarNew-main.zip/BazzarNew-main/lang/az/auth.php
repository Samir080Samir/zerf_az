<?php

declare(strict_types=1);

return [
    'failed'   => 'İstifadəçi adı və ya şifrə səhvdir',
    'password' => 'Şifrə yanlışdır.',
    'throttle' => ':Seconds saniyə ərzində yenidən cəhd edin',
];
